# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest

from unittest.mock import patch
from kubernetes import client


@patch("pframe.get_api_client")
class MyTestCase(unittest.TestCase):
    def test_generate_envs(self, api_mock):
        from pframe.utils.netdata import generate_envs

        pod_name = client.V1EnvVar(
            name="MY_POD_NAME",
            value_from=client.V1EnvVarSource(
                field_ref=client.V1ObjectFieldSelector(field_path="metadata.name")
            ),
        )
        pod_namespace = client.V1EnvVar(
            name="MY_POD_NAMESPACE",
            value_from=client.V1EnvVarSource(
                field_ref=client.V1ObjectFieldSelector(field_path="metadata.namespace")
            ),
        )

        self.assertListEqual(generate_envs(), [pod_name, pod_namespace])

    def test_get_netdata_contiainer(self, api_mock):
        from pframe.utils.netdata import get_netdata_container, generate_envs

        container = client.V1Container(
            name="name",
            image="image",
            image_pull_policy="Always",
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/netdata/.opt-out-from-anonymous-statistics",
                    name="config_cm",
                    sub_path="optout",
                ),
                *["mount"],
            ],
            env=generate_envs(),
            lifecycle=client.V1Lifecycle(
                post_start=client.V1Handler(
                    _exec=client.V1ExecAction(
                        command=[
                            "/bin/sh",
                            "-c",
                            "python -c 'import uuid; import socket; print(uuid.uuid3(uuid.NAMESPACE_DNS, socket.gethostname()))' > /var/lib/netdata/registry/netdata.public.unique.id",
                        ]
                    )
                ),
                pre_stop=client.V1Handler(
                    _exec=client.V1ExecAction(
                        command=[
                            "/bin/sh",
                            "-c",
                            "killall netdata; while killall -0 netdata; do sleep 1; done",
                        ]
                    )
                ),
            ),
            ports=[
                client.V1ContainerPort(protocol="TCP", name="http", container_port=1)
            ],
            security_context=client.V1SecurityContext(privileged=True),
            resources=client.V1ResourceRequirements(
                limits={"cpu": "2", "memory": "4Gi"},
                requests={"cpu": "2", "memory": "4Gi"},
            ),
            liveness_probe=client.V1Probe(
                http_get=client.V1HTTPGetAction(path="/api/v1/info", port="http"),
                timeout_seconds=1,
                period_seconds=30,
                success_threshold=1,
                failure_threshold=3,
            ),
            readiness_probe=client.V1Probe(
                http_get=client.V1HTTPGetAction(path="/api/v1/info", port="http"),
                timeout_seconds=1,
                period_seconds=30,
                success_threshold=1,
                failure_threshold=3,
            ),
        )
        self.assertEqual(
            get_netdata_container("name", "image", "config_cm", 1, ["mount"]), container
        )

    def test_create_netdata_cm(self, api_mock):
        from pframe.utils.netdata import create_netdata_cm

        self.assertTrue(
            create_netdata_cm("namespace", "name", "config", "stream").called_once
        )

    def test_get_master_affinity(self, api_mock):
        from pframe.utils.netdata import get_master_affinity

        affinity = client.V1Affinity(
            node_affinity=client.V1NodeAffinity(
                required_during_scheduling_ignored_during_execution=client.V1NodeSelector(
                    [
                        client.V1NodeSelectorTerm(
                            [
                                client.V1NodeSelectorRequirement(
                                    key="node-role.kubernetes.io/master",
                                    operator="In",
                                    values=["true"],
                                )
                            ]
                        )
                    ]
                )
            )
        )
        self.assertEqual(get_master_affinity(), affinity)

    def test_get_minion_nodes_affinity(self, api_mock):
        from pframe.utils.netdata import get_minion_nodes_affinity

        affinity = client.V1Affinity(
            node_affinity=client.V1NodeAffinity(
                required_during_scheduling_ignored_during_execution=client.V1NodeSelector(
                    [
                        client.V1NodeSelectorTerm(
                            [
                                client.V1NodeSelectorRequirement(
                                    key="kubernetes.io/hostname",
                                    operator="In",
                                    values=["node"],
                                )
                            ]
                        )
                    ]
                )
            )
        )
        self.assertEqual(get_minion_nodes_affinity(["node"]), affinity)

    def test_get_minion_roles_affinity(self, api_mock):
        from pframe.utils.netdata import get_minion_roles_affinity

        affinity = client.V1Affinity(
            node_affinity=client.V1NodeAffinity(
                required_during_scheduling_ignored_during_execution=client.V1NodeSelector(
                    [
                        client.V1NodeSelectorTerm(
                            [
                                client.V1NodeSelectorRequirement(
                                    key="role", operator="In", values=["true"]
                                )
                            ]
                        )
                    ]
                )
            )
        )
        self.assertEqual(get_minion_roles_affinity(["role"]), affinity)

    def test_deploy_netdata_servce(self, api_mock):
        from pframe.utils.netdata import deploy_netdata_service

        self.assertTrue(
            deploy_netdata_service("namespace", {"label": "value"}, 1).called_once
        )

    @patch("kubernetes.client.CoreV1Api")
    @patch("kubernetes.client.ExtensionsV1beta1Api")
    def test_purge_netdata_minion(self, extensions_mock, core_mock, api_mock):
        from pframe.utils.netdata import purge_netdata_minion

        purge_netdata_minion("namespace", "name", "cm")
        self.assertEqual(extensions_mock.call_count, 1)
        self.assertEqual(core_mock.call_count, 1)

    def test_get_netdata_minio_template(self, api_mock):
        from pframe.utils.netdata import (
            get_netdata_container,
            get_netdata_minio_template,
            get_minion_roles_affinity,
            create_netdata_cm,
        )

        netdata_cm = create_netdata_cm("namespace", "cm", "config", "stream")
        ds = client.V1DaemonSet(
            kind="DaemonSet",
            metadata=client.V1ObjectMeta(name="minion_name"),
            spec=client.V1DaemonSetSpec(
                selector=client.V1LabelSelector(
                    match_labels={"app.kubernetes.io/name": "netdata-minion"}
                ),
                template=client.V1PodTemplateSpec(
                    metadata=client.V1ObjectMeta(
                        labels={"app.kubernetes.io/name": "netdata-minion"}
                    ),
                    spec=client.V1PodSpec(
                        containers=[
                            get_netdata_container(
                                "minion_name",
                                "image",
                                netdata_cm,
                                19999,
                                volume_mounts=[
                                    client.V1VolumeMount(
                                        mount_path="/host/proc",
                                        read_only=True,
                                        name="proc",
                                    ),
                                    client.V1VolumeMount(
                                        mount_path="/var/run/docker.sock",
                                        read_only=True,
                                        name="run",
                                    ),
                                    client.V1VolumeMount(
                                        mount_path="/host/sys",
                                        read_only=True,
                                        name="sys",
                                    ),
                                    client.V1VolumeMount(
                                        mount_path="/etc/netdata/netdata.conf",
                                        name=netdata_cm,
                                        sub_path="netdata",
                                    ),
                                    client.V1VolumeMount(
                                        mount_path="/etc/netdata/stream.conf",
                                        name=netdata_cm,
                                        sub_path="stream",
                                    ),
                                ],
                            )
                        ],
                        affinity=get_minion_roles_affinity(
                            [
                                "node-role.kubernetes.io/compute",
                                "node-role.kubernetes.io/storage",
                            ]
                        ),
                        volumes=[
                            client.V1Volume(
                                name=netdata_cm,
                                config_map=client.V1ConfigMapVolumeSource(
                                    name=netdata_cm
                                ),
                            ),
                            client.V1Volume(
                                name="proc",
                                host_path=client.V1HostPathVolumeSource(path="/proc"),
                            ),
                            client.V1Volume(
                                name="run",
                                host_path=client.V1HostPathVolumeSource(
                                    path="/var/run/docker.sock"
                                ),
                            ),
                            client.V1Volume(
                                name="sys",
                                host_path=client.V1HostPathVolumeSource(path="sys"),
                            ),
                        ],
                        host_pid=True,
                        host_network=True,
                        host_ipc=True,
                        dns_policy="ClusterFirstWithHostNet",
                    ),
                ),
            ),
        )
        self.assertEqual(
            get_netdata_minio_template(
                "namespace", "image", "config", "stream", "minion_name", "cm", ["node"]
            ),
            ds,
        )

    @patch("kubernetes.client.ExtensionsV1beta1Api")
    def test_deploy_netdata_minion(self, extension_mock, api_mock):
        from pframe.utils.netdata import deploy_netdata_minion

        self.assertTrue(
            deploy_netdata_minion(
                "namespace",
                "image",
                "netdata_config",
                "stream_config",
                "minion_name",
                "cm",
                ["node"],
            ).called_once
        )
        self.assertTrue(extension_mock.called_once)

    @patch("kubernetes.client.AppsV1Api")
    @patch("kubernetes.client.CoreV1Api")
    def test_purge_netdata_master(self, core_mock, apps_mock, api_mock):
        from pframe.utils.netdata import purge_netdata_master

        purge_netdata_master("namespace", "name", "cm")
        self.assertTrue(apps_mock.called_once)
        self.assertEqual(core_mock.call_count, 2)

    def test_get_netdata_master_template(self, api_mock):
        from pframe.utils.netdata import (
            get_netdata_container,
            create_netdata_cm,
            get_netdata_master_template,
            get_master_affinity,
        )

        netdata_cm = create_netdata_cm(
            "namespace", "netdata_cm", "netdata_config", "stream_config"
        )
        sts = client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(
                name="netdata_master_name",
                labels={"app.kubernetes.io/name": "netdata-master"},
            ),
            spec=client.V1StatefulSetSpec(
                pod_management_policy="Parallel",
                replicas=1,
                template=client.V1PodTemplateSpec(
                    metadata=client.V1ObjectMeta(
                        labels={"app.kubernetes.io/name": "netdata-master"}
                    ),
                    spec=client.V1PodSpec(
                        containers=[
                            get_netdata_container(
                                "netdata_master_name",
                                "netdata_image",
                                netdata_cm,
                                19999,
                                [
                                    client.V1VolumeMount(
                                        mount_path="/etc/netdata/netdata.conf",
                                        name=netdata_cm,
                                        sub_path="netdata",
                                    ),
                                    client.V1VolumeMount(
                                        mount_path="/etc/netdata/stream.conf",
                                        name=netdata_cm,
                                        sub_path="stream",
                                    ),
                                ],
                            )
                        ],
                        affinity=get_master_affinity(),
                        volumes=[
                            client.V1Volume(
                                name=netdata_cm,
                                config_map=client.V1ConfigMapVolumeSource(
                                    name=netdata_cm
                                ),
                            )
                        ],
                    ),
                ),
                selector=client.V1LabelSelector(
                    match_labels={"app.kubernetes.io/name": "netdata-master"}
                ),
                service_name="netdata_master_name",
            ),
        )
        self.assertEqual(
            get_netdata_master_template(
                "namespace",
                "netdata_image",
                "netdata_config",
                "stream_config",
                "netdata_master_name",
                "netdata_cm",
            ),
            sts,
        )

    def test_deploy_netdata_master(self, api_mock):
        from pframe.utils.netdata import deploy_netdata_master

        deploy_netdata_master(
            "namespace",
            "netdata_image",
            "netdata_config",
            "stream_config",
            "netdata_master_name",
            "netdata_cm",
        )
        self.assertTrue(api_mock.called_once)


if __name__ == "__main__":
    unittest.main()
