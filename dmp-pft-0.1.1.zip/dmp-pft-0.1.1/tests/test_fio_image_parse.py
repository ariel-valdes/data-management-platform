# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from io import StringIO
from images.fio.scripts.parse import main
from unittest.mock import patch


def side_effect(env_name):
    if env_name == "RW":
        return "randread"
    elif env_name == "PMEM":
        return False
    return env_name


class TestCase(unittest.TestCase):
    @patch("builtins.open")
    @patch("json.load")
    @patch("os.getenv")
    def test_parse(self, getenv_mock, json_mock, open_mock):
        json_mock.return_value = {
            "jobs": [
                {"read": {"bw_mean": 1024, "iops_mean": 2, "lat_ns": {"mean": 3000}}}
            ]
        }
        expected = "HOSTNAME,NODE_NAME,STORAGE_NODE,STORAGE_POOL,1.05,2,3.0\n"
        getenv_mock.side_effect = side_effect
        with patch("sys.stdout", new=StringIO()) as output:
            main()
            self.assertEqual(output.getvalue(), expected)
