# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from unittest.mock import patch
from images.build_images import (
    get_folders_containing_dockerfile,
    build_and_push_dockerimage,
    dry_run,
)
from io import StringIO
from pathlib import Path


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.client_mock = unittest.mock.MagicMock()
        self.client_mock.return_value = unittest.mock.MagicMock()
        self.client_mock.images.build.return_value = (
            unittest.mock.MagicMock(),
            unittest.mock.MagicMock(),
        )
        self.image_object = build_and_push_dockerimage(
            "name", "tag", "url", "namespace", self.client_mock
        )

    @patch("pathlib.Path.is_dir")
    @patch("pathlib.Path.is_file")
    @patch("pathlib.Path.exists")
    @patch("pathlib.Path.iterdir")
    def test_get_folders_containing_dockerfile(
        self, iterdir_mock, exists_mock, isfile_mock, isdir_mock
    ):

        iterdir_mock.return_value = [
            Path("fio"),
            Path("minio-bench"),
            Path("pframe-gateway"),
        ]

        isdir_mock.return_value = True
        isfile_mock.return_value = True
        exists_mock.return_value = False

        self.assertListEqual(
            get_folders_containing_dockerfile("abc"),
            ["fio", "minio-bench", "pframe-gateway"],
        )

    def test_build_image(self):

        self.assertTrue(
            self.client_mock.images.build.called_wth(path="name", tag="name:tag")
        )

    def test_push_image(self):
        self.assertTrue(
            self.client_mock.images.push.called_with(
                "url/namespace/name", stream=True, decode=True, tag="tag"
            )
        )

    @patch("os.path.isdir")
    @patch("os.path.exists")
    @patch("os.listdir")
    def test_dry_run(self, listdir_mock, isdir_mock, exists_mock):
        listdir_mock.return_value = ["fio", "minio-bench", "pframe-gateway"]
        isdir_mock.return_value = True
        exists_mock.return_value = True

        with patch("sys.stdout", new=StringIO()) as output:
            dry_run(["fio", "minio-bench", "pframe-gateway"], "url", "namespace", "tag")

            self.assertListEqual(
                output.getvalue().split("\n")[:-1],
                [
                    "Images that would be build:",
                    "Image fio will be pushed as url/namespace/fio:tag",
                    "Image minio-bench will be pushed as url/namespace/minio-bench:tag",
                    "Image pframe-gateway will be pushed as url/namespace/pframe-gateway:tag",
                ],
            )


if __name__ == "__main__":
    unittest.main()
