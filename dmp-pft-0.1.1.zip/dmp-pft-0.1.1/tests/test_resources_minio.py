# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.
import datetime
import json
import unittest
from io import StringIO
from minio import Minio

from minio.error import BucketAlreadyExists, BucketAlreadyOwnedByYou

from pframe.resources.minio import BenchMinio, PframeMinioConfigMap, PframeMinioClient
from unittest.mock import Mock, patch
from kubernetes import client
from base64 import b64encode


class BenchMinioTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.minio = BenchMinio(
            "name",
            "namespace",
            "access_key",
            "secret_key",
            "version",
            1,
            {
                "requests": {"memory": "16Gi", "cpu": "4"},
                "limits": {"memory": "16Gi", "cpu": "4"},
            },
            Mock(),
            Mock(),
            "10G",
            "storage_class",
            ["node1"],
            "scheduler",
        )

    def test_generate_service(self):

        result = self.minio._generate_service()
        expected = client.V1Service(
            api_version="v1",
            kind="Service",
            metadata=client.V1ObjectMeta(
                name="name", labels={"app.kubernetes.io/name": "name"}
            ),
            spec=client.V1ServiceSpec(
                ports=[client.V1ServicePort(name="https", port=9000, target_port=9000)],
                selector={"app.kubernetes.io/name": "name"},
            ),
        )
        self.assertEqual(result, expected)

    def test_generate_secret(self):
        result = self.minio._generate_secret()
        expected = client.V1Secret(
            api_version="v1",
            kind="Secret",
            type="Opaque",
            metadata=client.V1ObjectMeta(name="secret-name"),
            data={
                # decode from bytes to string
                "accesskey": b64encode(bytes("access_key", "utf-8")).decode("utf-8"),
                "secretkey": b64encode(bytes("secret_key", "utf-8")).decode("utf-8"),
            },
        )
        self.assertEqual(result, expected)

    def test_generate_minio_instance(self):
        self.maxDiff = None
        result = self.minio.generate_minio_instance()
        body = {
            "kind": "MinIOInstance",
            "apiVersion": "miniocontroller.min.io/v1beta1",
            "metadata": {"name": "name", "namespace": "namespace"},
            "scheduler": {"name": "scheduler"},
            "spec": {
                "replicas": 1,
                "version": "version",
                "podManagementPolicy": "OrderedReady",
                "credsSecret": {"name": "secret-name"},
                "resources": {
                    "requests": {"memory": "16Gi", "cpu": "4"},
                    "limits": {"memory": "16Gi", "cpu": "4"},
                },
                "metadata": {
                    "labels": {
                        **{"app.kubernetes.io/name": "name"},
                        "pframe-minio": "true",
                    }
                },
                "liveness": {
                    "httpGet": {
                        "path": "/minio/health/live",
                        "port": 9000,
                        "scheme": "HTTP",
                    },
                    "initialDelaySeconds": 120,
                    "periodSeconds": 20,
                },
                "readiness": {
                    "httpGet": {"path": "/minio/health/ready", "port": 9000},
                    "initialDelaySeconds": 10,
                    "periodSeconds": 5,
                },
                "volumeClaimTemplate": {
                    "metadata": {"name": "data"},
                    "spec": {
                        "accessModes": ["ReadWriteOnce"],
                        "storageClassName": "storage_class",
                        "resources": {"requests": {"storage": "10G"}},
                    },
                },
                "env": [{"name": "MINIO_STORAGE_CLASS_STANDARD", "value": "EC:4"}],
                "affinity": {
                    "nodeAffinity": {
                        "requiredDuringSchedulingIgnoredDuringExecution": {
                            "nodeSelectorTerms": [
                                {
                                    "matchExpressions": [
                                        {
                                            "key": "kubernetes.io/hostname",
                                            "operator": "In",
                                            "values": ["node1"],
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    "podAntiAffinity": {
                        "preferredDuringSchedulingIgnoredDuringExecution": [
                            {
                                "weight": 100,
                                "podAffinityTerm": {
                                    "labelSelector": {
                                        "matchExpressions": [
                                            {
                                                "key": "app.kubernetes.name",
                                                "operator": "In",
                                                "values": ["name"],
                                            }
                                        ]
                                    },
                                    "topologyKey": "failure-domain.beta.kubernetes.io/zone",
                                },
                            },
                            {
                                "weight": 100,
                                "podAffinityTerm": {
                                    "labelSelector": {
                                        "matchExpressions": [
                                            {
                                                "key": "pframe-minio",
                                                "operator": "In",
                                                "values": ["true"],
                                            }
                                        ]
                                    },
                                    "topologyKey": "failure-domain.beta.kubernetes.io/zone",
                                },
                            },
                        ]
                    },
                },
            },
        }

        self.assertEqual(result, body)


class PframeMinioCMTestCase(unittest.TestCase):
    def test_get_pframe_minio_cm(self):
        minio = PframeMinioConfigMap(
            "name", "namespace", "endpoint", "access_key", "secret_key", Mock()
        )
        expected = client.V1ConfigMap(
            api_version="v1",
            kind="ConfigMap",
            metadata=client.V1ObjectMeta(name="name"),
            data={
                "config.json": json.dumps(
                    {
                        "version": "9",
                        "hosts": {
                            "endpoint": {
                                "url": f"https://endpoint",
                                "accessKey": "access_key",
                                "secretKey": "secret_key",
                                "api": "s3v4",
                                "lookup": "auto",
                            }
                        },
                    }
                )
            },
        )
        result = minio._get_pframe_minio_configmap()
        self.assertEqual(result, expected)


class MinioBenchTestCase(unittest.TestCase):
    @patch("minio.Minio.make_bucket")
    def test_make_bucket(self, make_mock):
        attempts = 3
        bucket = PframeMinioClient(
            "bucket", "endpoint", "acceskey", "secretkey", None, None, "scenario"
        )
        expected = [
            "Bucket bucket already exists skipping",
            "Bucket bucket already owned by you ",
        ]
        make_mock.side_effect = [
            BucketAlreadyExists("abc"),
            BucketAlreadyOwnedByYou("abc"),
            True,
        ]
        with patch("sys.stdout", new=StringIO()) as output:
            for i in range(attempts):
                bucket.make_bucket()
            result = output.getvalue().split("\n")[:-1]
        self.assertEqual(make_mock.call_count, 3)
        self.assertListEqual(result, expected)

    @patch("minio.Minio.list_objects")
    @patch("os.mkdir")
    @patch("builtins.open")
    @patch("datetime.datetime")
    @patch("minio.Minio.get_object")
    def test_get_results(
        self, minio_mock, datetime_mock, open_mock, mkdirs_mock, list_mock
    ):
        bucket = PframeMinioClient(
            "bucket", "endpoint", "acceskey", "secretkey", None, None, "scenario"
        )
        time = datetime.date.fromtimestamp(1326244364)
        datetime_mock.now.return_value = time
        list_mock.return_value = [MinioObject("name")]
        minio_mock.stream.return_value = "abc"
        with patch.object(
            Minio,
            "__init__",
            lambda a, minio_endpoint, access_key, secret_key, secure: None,
        ):
            result = bucket.get_results()
        self.assertTrue(open_mock.called_once)
        self.assertEqual(result, "results/scenario/2012-01-11")


class MinioObject:
    def __init__(self, name):
        self.object_name = name

    def get_object(self):
        return Data()


class Data:
    def stream(self):
        return "stream"


if __name__ == "__main__":
    unittest.main()
