# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from pframe.utils.minio import (
    merge_fio_results,
    merge_minio_results,
    print_minio_results,
)
from unittest.mock import patch
from io import StringIO

import os


def raise_error(error):
    raise error


class MyTestCase(unittest.TestCase):
    def test_merge_fio_results(self):
        expected_result_file = [
            "POD_NAME,COMPUTE_NODE,STORAGE_NODE,STORAGE_POOL,BW [MB/s],IOPS,MEAN_LAT [usec]",
            "pod,compute,storage,disk,29.97,479,1228628.19",
        ]
        path = os.path.join(os.getcwd(), "tests/examples/fio_results")
        result = merge_fio_results(path)
        self.assertEqual(result, os.path.join(path, "results.csv"))
        with open(result, "r") as f:
            result_file = f.read().split("\n")[:-1]
        self.assertListEqual(expected_result_file, result_file)
        os.remove(result)

    def test_merge_minio_results(self):
        expected_result_file = [
            "POD_NAME,COMPUTE_NODE,PUT_TOTAL_OBJ,PUT_SPEED [MiB/s],PUT_TOTAL_OPS,GET_TOTAL_OBJ,GET_SPEED [MiB/s],GET_TOTAL_OPS,CLUSTER_NR",
            "s3bench-0,compute,1491,1246.78,124.67811800728931,2427,2369.24,236.92437026446126",
        ]
        path = os.path.join(os.getcwd(), "tests/examples/minio_results")
        result = merge_minio_results(path)
        self.assertEqual(result, os.path.join(path, "results.csv"))
        with open(result, "r") as f:
            result_file = f.read().split("\n")[:-1]
        self.assertListEqual(expected_result_file, result_file)
        os.remove(result)

    def test_print_minio_results(self):
        self.maxDiff = None
        expected = """Results for minio-operator.
POD_NAME     COMPUTE_NODE                          PUT_TOTAL_OBJ    PUT_SPEED [MiB/s]    PUT_TOTAL_OPS    GET_TOTAL_OBJ    GET_SPEED [MiB/s]    GET_TOTAL_OPS    CLUSTER_NR
-----------  ----------------------------------  ---------------  -------------------  ---------------  ---------------  -------------------  ---------------  ------------
s3bench-0-0  compute-3-5.jf2.dmp-pmss.intel.com              691               645.02          64.5021             1487              1444.58          144.458             0
s3bench-0-1  compute-3-5.jf2.dmp-pmss.intel.com              988               813.69          81.3692             1426              1396.45          139.645             0
s3bench-1-0  compute-3-5.jf2.dmp-pmss.intel.com             1118              1099.65         109.965              1458              1373.89          137.389             1
s3bench-1-1  compute-3-5.jf2.dmp-pmss.intel.com              888               805.33          80.5327             2677              2676             267.6               1


Results for each minio cluster
  CLUSTER_NUMBER    PUT_SPEED_SUM [MiB/s]    PUT_TOTAL_OBJ_SUM    GET_SPEED_SUM [MiB/s]    GET_TOTAL_OBJ_SUM
----------------  -----------------------  -------------------  -----------------------  -------------------
               0                  2841.03                 1679                  2841.03                 2913
               1                  4049.89                 2006                  4049.89                 4135


Sum of results
  PUT_SPEED_SUM [MiB/s]    PUT_TOTAL_OBJ_SUM    GET_SPEED_SUM [MiB/s]    GET_TOTAL_OBJ_SUM
-----------------------  -------------------  -----------------------  -------------------
                3363.69                 3685                  6890.92                 7048
"""
        with patch("sys.stdout", new=StringIO()) as output:

            print_minio_results(
                os.path.join(os.getcwd(), "tests/examples/minio_results.txt"),
                "minio-operator",
                2,
            )
            self.assertEqual(output.getvalue(), expected)


if __name__ == "__main__":

    unittest.main()
