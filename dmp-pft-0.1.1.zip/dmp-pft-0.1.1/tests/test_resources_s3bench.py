# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from pframe.resources.s3bench import S3Bench
from unittest.mock import Mock
from kubernetes import client
from pframe.utils.kubernetes import generate_envs, get_affinity


class MyTestCase(unittest.TestCase):
    maxDiff = None

    def setUp(self) -> None:
        self.s3bench = S3Bench(
            "name",
            "namespace",
            "image",
            "s3bench_endpoint",
            "s3bench_bucket",
            "s3bench_access_key",
            "s3bench_secret_key",
            1,
            1,
            1,
            "pframe_minio_endpoint",
            "pframe_minio_bucket",
            "pframe_minio_cm",
            1,
            ["node1"],
            Mock(),
            1,
        )

    def test_generate_sts(self):
        expected = client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(
                name="name", labels={"app.kubernetes.io/name": "name"}
            ),
            spec=client.V1StatefulSetSpec(
                pod_management_policy="Parallel",
                replicas=1,
                template=self.s3bench._get_pod_template(),
                selector=client.V1LabelSelector(
                    match_labels={"app.kubernetes.io/name": "name"}
                ),
                service_name="name",
            ),
        )
        result = self.s3bench._generate_sts()
        self.assertEqual(result, expected)

    def test_get_contiainer(self):
        self.maxDiff = 100000
        expected = client.V1Container(
            name="name",
            image="image",
            image_pull_policy="Always",
            command=["python3", "/executor/entrypoint.py"],
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/minio/config.json",
                    name="pframe_minio_cm",
                    sub_path="config.json",
                )
            ],
            env=generate_envs(self.s3bench.envs),
            security_context=client.V1SecurityContext(privileged=True),
        )
        result = self.s3bench._get_container()

        self.assertEqual(result, expected)

    def test_get_pod_template(self):
        expected = client.V1PodTemplateSpec(
            metadata=client.V1ObjectMeta(labels={"app.kubernetes.io/name": "name"}),
            spec=client.V1PodSpec(
                containers=[self.s3bench._get_container()],
                affinity=get_affinity(["node1"], {"app.kubernetes.io/name": "name"}),
                volumes=[self.s3bench._get_volume()],
            ),
        )
        result = self.s3bench._get_pod_template()
        self.assertEqual(result, expected)

    def test_get_container(self):
        expected = client.V1Container(
            name="name",
            image="image",
            image_pull_policy="Always",
            command=["python3", "/executor/entrypoint.py"],
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/minio/config.json",
                    name="pframe_minio_cm",
                    sub_path="config.json",
                )
            ],
            env=generate_envs(
                {
                    "MINIO_BUCKET": "pframe_minio_bucket",
                    "MINIO_ENDPOINT": "pframe_minio_endpoint",
                    "MINIO_CONFIG_DIR": "/etc/minio",
                    "RESULTS_DIR": "/results",
                    "BINARIES": "/binaries",
                    "PFRAME_SYNC_URL": "http://pframe-sync",
                    "ACCESS_KEY": "s3bench_access_key",
                    "SECRET_KEY": "s3bench_secret_key",
                    "BENCH_BUCKET": "s3bench_bucket",
                    "THREADS": "1",
                    "DURATION": "1",
                    "OBJ_SIZE": 1,
                    "BENCH_MINO_URL": "s3bench_endpoint",
                    "CLUSTER_NR": "1",
                }
            ),
            security_context=client.V1SecurityContext(privileged=True),
        )
        result = self.s3bench._get_container()
        self.assertEqual(result, expected)

    def test_get_volume(self):
        expected = client.V1Volume(
            name="pframe_minio_cm",
            config_map=client.V1ConfigMapVolumeSource(name="pframe_minio_cm"),
        )
        result = self.s3bench._get_volume()
        self.assertEqual(result, expected)


if __name__ == "__main__":
    unittest.main()
