# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from kubernetes.client.rest import ApiException
from pframe.utils.kubernetes import (
    ignore_if_exists,
    generate_envs,
    get_affinity,
    wait_for_endpoints,
    wait_for_adresses,
    wait_for_svc,
    wait_for_connection,
)
from kubernetes import client
from unittest.mock import patch, Mock


class resp:
    @staticmethod
    def json():
        x = 1
        if x == 1:
            x += 1
            return {"state": "notfinished"}
        else:
            return {"state": "finished"}


class MyTestCase(unittest.TestCase):
    def raise_api_exception(self, exception):
        raise exception

    def test_wrapper_404(self):
        exception = ApiException(status=404)
        fun = ignore_if_exists(self.raise_api_exception)
        self.assertFalse(fun(exception))

    def test_wrapper(self):
        self.assertTrue(ignore_if_exists(lambda x: x))

    @patch("builtins.print")
    def test_wrapper_exception(self, print_mock):
        exception = ApiException(status=403)
        fun = ignore_if_exists(self.raise_api_exception)
        with self.assertRaises(ApiException) as ex:
            fun(exception)
        self.assertEqual(ex.exception.status, 403)

    def test_generate_envs(self):
        envs = {
            "MINIO_CONFIG_DIR": "/etc/minio",
            "RESULTS_DIR": "/results",
            "BINARIES": "/binaries",
            "NODE_NAME": "spec.nodeName",
        }
        result = generate_envs(envs)
        for env in result:
            self.assertIn(env.name, envs.keys())
            if env.name != "NODE_NAME":
                self.assertIn(env.value, envs.values())

    def test_get_affinity(self):
        result = get_affinity(["compute"], {"app.kubernetes.io/name": "fio"})
        self.assertEqual(
            result.node_affinity.required_during_scheduling_ignored_during_execution,
            client.V1NodeSelector(
                [
                    client.V1NodeSelectorTerm(
                        [
                            client.V1NodeSelectorRequirement(
                                key="kubernetes.io/hostname",
                                operator="In",
                                values=["compute"],
                            )
                        ]
                    )
                ]
            ),
        )
        self.assertEqual(
            result.pod_anti_affinity.preferred_during_scheduling_ignored_during_execution[
                0
            ].weight,
            100,
        )
        self.assertEqual(
            result.pod_anti_affinity.preferred_during_scheduling_ignored_during_execution[
                0
            ]
            .pod_affinity_term.label_selector.match_expressions[0]
            .operator,
            "In",
        )
        self.assertEqual(
            result.pod_anti_affinity.preferred_during_scheduling_ignored_during_execution[
                0
            ]
            .pod_affinity_term.label_selector.match_expressions[0]
            .values[0],
            "fio",
        )
        self.assertEqual(
            result.pod_anti_affinity.preferred_during_scheduling_ignored_during_execution[
                0
            ].pod_affinity_term.topology_key,
            "kubernetes.io/hostname",
        )

    @patch("builtins.print")
    @patch("time.sleep")
    @patch("kubernetes.client.CoreV1Api.read_namespaced_endpoints")
    def test_wait_for_endpoints(self, read_mock, sleep_mock, print_mock):
        k8s_client = Mock()
        read_mock.side_effect = [
            client.V1Endpoints(subsets=[]),
            client.V1Endpoints(subsets=[client.V1EndpointSubset]),
        ]
        wait_for_endpoints("svc", "namespace", k8s_client)
        self.assertEqual(read_mock.call_count, 2)

    @patch("builtins.print")
    @patch("time.sleep")
    @patch("kubernetes.client.CoreV1Api.read_namespaced_endpoints")
    def test_wait_for_addresses(self, read_mock, sleep_mock, print_mock):
        endpointSubset = client.V1EndpointSubset(
            addresses=[client.V1EndpointAddress(ip="127.0.0.1")]
        )
        read_mock.side_effect = [
            client.V1Endpoints(subsets=[client.V1EndpointSubset(addresses=[])]),
            client.V1Endpoints(subsets=[endpointSubset]),
        ]
        k8s_client = Mock()
        wait_for_adresses("svc", "namespace", 1, k8s_client)
        self.assertEqual(read_mock.call_count, 2)

    @patch("builtins.print")
    @patch("time.sleep")
    @patch("kubernetes.client.CoreV1Api.read_namespaced_endpoints")
    def test_wait_for_svc(self, read_mock, sleep_mock, print_mock):
        endpointSubset = client.V1EndpointSubset(
            addresses=[client.V1EndpointAddress(ip="127.0.0.1")]
        )
        returned_object = [
            client.V1Endpoints(
                subsets=[
                    client.V1EndpointSubset(
                        not_ready_addresses=[client.V1EndpointAddress(ip="127.0.0.1")]
                    )
                ]
            ),
            client.V1Endpoints(subsets=[endpointSubset]),
        ]
        read_mock.side_effect = returned_object
        wait_for_svc("svc", "namespace", Mock())
        self.assertEqual(read_mock.call_count, 2)

    @patch("builtins.print")
    @patch("time.sleep")
    @patch("socket.socket.connect_ex")
    def test_wait_for_connection(self, socket_mock, sleep_mock, print_mock):
        socket_mock.side_effect = [1, 0]
        wait_for_connection("svc", "namespace", "port")
        self.assertEqual(socket_mock.call_count, 2)

    @patch("kubernetes.config.load_kube_config")
    def test_get_api_client(self, load_mock):
        from pframe.utils.kubernetes import KubernetesClient

        KubernetesClient()
        self.assertEqual(load_mock.call_count, 1)


if __name__ == "__main__":
    unittest.main()
