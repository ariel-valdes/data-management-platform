# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from pframe.resources.fio import Fio, FioStorageClass, StorageClassInvalidDiskType
from unittest.mock import Mock
from kubernetes import client
from pframe.utils.kubernetes import get_affinity, generate_envs


class TestFioClass(unittest.TestCase):
    def setUp(self) -> None:
        self.fio = Fio(
            "name",
            "image",
            "namespace",
            "sc_name",
            "disk",
            "storage_node",
            "minio_endpoint",
            "minio_cm",
            "minio_bucket",
            "disk_size",
            1,
            ["compute"],
            Mock(),
            {"fio_runtime_options": {"rw": 1, "size": 1, "directory": "/data"}},
            pmem=False,
        )

    def test_init(self):
        self.assertDictEqual(self.fio.labels, {"app.kubernetes.io/name": "fio"})
        self.assertDictEqual(
            self.fio.envs,
            {
                "MINIO_BUCKET": "minio_bucket",
                "MINIO_ENDPOINT": "minio_endpoint",
                "MINIO_CONFIG_DIR": "/etc/minio",
                "RESULTS_DIR": "/results",
                "BINARIES": "/binaries",
                "STORAGE_POOL": "disk",
                "STORAGE_NODE": "storage_node",
                "PFRAME_SYNC_URL": "http://pframe-sync",
                "FS": 1,
                "RW": 1,
                "FIO_RUNTIME_OPTIONS": " --rw=1 --size=1 --directory=/data",
                "PMEM": "0",
                "DIRECTORY": "/data",
            },
        )

    def test_generate_sts(self):
        result = self.fio._generate_sts()
        expected = client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(
                name="name", labels={"app.kubernetes.io/name": "fio"}
            ),
            spec=client.V1StatefulSetSpec(
                pod_management_policy="Parallel",
                volume_claim_templates=[self.fio._get_volume_clam_template("fio")],
                replicas=1,
                template=self.fio._generate_pod_template(),
                selector=client.V1LabelSelector(
                    match_labels={"app.kubernetes.io/name": "fio"}
                ),
                service_name="name",
            ),
        )
        self.assertEqual(result, expected)

    def test_generate_pod_template(self):
        result = self.fio._generate_pod_template()
        expected = client.V1PodTemplateSpec(
            metadata=client.V1ObjectMeta(labels={"app.kubernetes.io/name": "fio"}),
            spec=client.V1PodSpec(
                containers=[self.fio._get_fio_container()],
                affinity=get_affinity(["compute"], {"app.kubernetes.io/name": "fio"}),
                volumes=[self.fio._get_minio_cm_volume()],
                tolerations=[
                    client.V1Toleration(operator="Exists", key="dmp.intel.com/nodes")
                ],
            ),
        )
        self.assertEqual(result, expected)

    def test_get_minio_cm_volume(self):
        result = self.fio._get_minio_cm_volume()
        expected = client.V1Volume(
            name="minio_cm", config_map=client.V1ConfigMapVolumeSource(name="minio_cm")
        )
        self.assertEqual(result, expected)

    def test_get_volume_claim_template(self):
        result = self.fio._get_volume_clam_template("fio")
        expected = client.V1PersistentVolumeClaim(
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=["ReadWriteOnce"],
                storage_class_name="sc_name",
                resources=client.V1ResourceRequirements(
                    requests={"storage": "disk_size"}
                ),
            ),
            metadata=client.V1ObjectMeta(name="fio"),
        )
        self.assertEqual(result, expected)

    def test_get_fio_container(self):
        self.maxDiff = None
        result = self.fio._get_fio_container()
        expected = client.V1Container(
            name="fio",
            image="image",
            image_pull_policy="Always",
            command=None,
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/minio/config.json",
                    name="minio_cm",
                    sub_path="config.json",
                ),
                client.V1VolumeMount(mount_path="/data", name="fio"),
            ],
            env=generate_envs(
                {
                    "DIRECTORY": "/data",
                    "MINIO_BUCKET": "minio_bucket",
                    "MINIO_ENDPOINT": "minio_endpoint",
                    "MINIO_CONFIG_DIR": "/etc/minio",
                    "RESULTS_DIR": "/results",
                    "BINARIES": "/binaries",
                    "STORAGE_POOL": "disk",
                    "STORAGE_NODE": "storage_node",
                    "FS": 1,
                    "RW": 1,
                    "FIO_RUNTIME_OPTIONS": " --rw=1 --size=1 --directory=/data",
                    "PFRAME_SYNC_URL": "http://pframe-sync",
                    "PMEM": "0",
                }
            ),
            security_context=client.V1SecurityContext(privileged=True),
        )
        self.assertEqual(result, expected)


class TestFioStorageClass(unittest.TestCase):
    def test_generate_sc_nvme(self):
        fio = FioStorageClass("name", "disk", "storage_node", "fstype", Mock(), "nvme")
        expected = client.V1StorageClass(
            kind="StorageClass",
            api_version="storage.k8s.io/v1",
            metadata=client.V1ObjectMeta(name="name"),
            parameters={
                "storagePool": "disk",
                "nodeList": "storage_node",
                "layerList": "nvme",
                "fsType": "fstype",
                "fsOpts": "-K -b size=4096 -d su=128k,sw=1",
                "placementPolicy": "Manual",
                "allowRemoteVolumeAccess": "true",
                "disklessStoragePool": "diskless",
            },
            provisioner="linstor.csi.linbit.com",
        )
        self.assertEqual(fio.sc, expected)

    def test_generate_sc_storage(self):
        fio = FioStorageClass(
            "name", "disk", "storage_node", "fstype", Mock(), "storage"
        )
        expected = client.V1StorageClass(
            kind="StorageClass",
            api_version="storage.k8s.io/v1",
            metadata=client.V1ObjectMeta(name="name"),
            parameters={
                "storagePool": "disk",
                "nodeList": "storage_node",
                "layerList": "storage",
                "fsType": "fstype",
                "fsOpts": "-K -b size=4096 -d su=128k,sw=1",
                "placementPolicy": "FollowTopology",
                "allowRemoteVolumeAccess": "false",
            },
            provisioner="linstor.csi.linbit.com",
        )
        self.assertEqual(fio.sc, expected)

    def test_generate_sc_other(self):
        with self.assertRaises(StorageClassInvalidDiskType):
            FioStorageClass("name", "disk", "storage_node", "fstype", Mock(), "other")


if __name__ == "__main__":
    unittest.main()
