# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from pframe.config import MinioConfig, MultiDriveSingleComputeConfig
import os


class MDSCTestCase(unittest.TestCase):
    def test_mdsc_config(self):
        expected = {
            "namespace": "namespace",
            "fstype": "xfs",
            "computes": ["compute-1-3"],
            "disk_size": "2G",
            "fio_params": {
                "fio_runtime_options": {
                    "directory": "/data",
                    "output-format": "json",
                    "name": "test",
                    "size": "1G",
                    "rw": "read",
                    "numjobs": "1",
                    "iodepth": "64",
                    "runtime": "30",
                    "ramp_time": "5",
                    "bs": "128K",
                    "direct": "1",
                    "nrfiles": "1",
                    "time_based": "1",
                },
                "FLUSH_CACHE": "0",
                "FS": "1280M",
            },
            "minio": {
                "minio_cluster_bucket": "pframe",
                "minio_cluster_name": "pframe-minio",
                "minio_cluster_version": "",
                "minio_cluster_sa": "default",
                "minio_cluster_secret": "pframe-minio-secret",
                "minio_cluster_replicas": 1,
                "minio_cluster_accesskey": "pframe",
                "minio_cluster_secretkey": "pframesecret",
                "minio_cluster_ec": "EC:1",
                "minio_cluster_resources": {
                    "requests": {"memory": "16Gi", "cpu": 4},
                    "limits": {"memory": "16Gi", "cpu": 4},
                },
            },
            "pframe_image": "pframe-gateway",
            "fio_image": "fio",
            "storage_pools": [
                {"node": "storage-1-1", "replicas": 1, "disk": "vg-nvme3n1"},
                {"node": "storage-1-1", "replicas": 1, "disk": "vg-nvme2n1"},
            ],
            "bucket_name": "pframe",
        }

        mdsc = MultiDriveSingleComputeConfig(
            os.path.join(os.getcwd(), "tests/examples/configs/config_mdsc.yaml")
        )
        self.assertDictEqual(mdsc.config, expected)


class MinioTestCase(unittest.TestCase):
    def test_minio_config(self):
        expected_dict = {
            "bench_minio": {
                "bench_minio_accesskey": "pframe",
                "bench_minio_disk_size": "1000G",
                "bench_minio_nodes": ["compute-1-1"],
                "bench_minio_resources": {
                    "limits": {"cpu": 4, "memory": "16Gi"},
                    "requests": {"cpu": 4, "memory": "16Gi"},
                },
                "bench_minio_scheduler": None,
                "bench_minio_secret": "bench-minio-secret",
                "bench_minio_secretkey": "pframesecret",
                "bench_minio_storage_class": "linstor-dmpbalancer",
                "bench_minio_storage_class_name": "linstor-dmpbalancer",
                "bench_minio_version": "",
                "name": "bench-minio",
                "replicas": 8,
            },
            "computes": [],
            "concurrent_clusters": 2,
            "disk_size": "100G",
            "fstype": "xfs",
            "minio": {
                "minio_cluster_accesskey": "pframe",
                "minio_cluster_bucket": "pframe",
                "minio_cluster_ec": "EC:1",
                "minio_cluster_name": "pframe-minio",
                "minio_cluster_replicas": 1,
                "minio_cluster_resources": {
                    "limits": {"cpu": 4, "memory": "16Gi"},
                    "requests": {"cpu": 4, "memory": "16Gi"},
                },
                "minio_cluster_sa": "default",
                "minio_cluster_secret": "pframe-minio-secret",
                "minio_cluster_secretkey": "pframesecret",
                "minio_cluster_version": "",
            },
            "namespace": "namespace",
            "pframe_image": "pframe-gateway",
            "s3bench_config": {
                "s3bench_minio_secretkey": "pframesecret",
                "s3bench_bucket": "pframe",
                "s3bench_duration": 10,
                "s3bench_image": "minio-bench",
                "s3bench_minio_accesskey": "pframeaccess",
                "s3bench_nodes": ["compute-3-5"],
                "s3bench_obj_size": "10M",
                "s3bench_replicas": 2,
                "s3bench_thread_num": 10,
            },
        }

        minio = MinioConfig(
            os.path.join(os.getcwd(), "tests/examples/configs/config_minio.yaml")
        )
        self.assertDictEqual(minio.config, expected_dict)


if __name__ == "__main__":
    unittest.main()
