# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import logging
import unittest
from unittest.mock import patch
from pframe.benchmarks.local import Local
import os

from pframe.resources.fio import FioStorageClass, Fio
from pframe.resources.minio import PframeMinio, PframeMinioConfigMap
from pframe.resources.pframe_sync import PframeSync


class RequestsResponse:
    def json(self):
        return {"state": "finished"}


class TestCase(unittest.TestCase):
    @patch("minio.Minio.__init__")
    @patch("os.path.join")
    @patch("kubernetes.client.CertificatesV1beta1Api")
    @patch("urllib3.PoolManager")
    @patch("builtins.print")
    @patch("minio.Minio.list_objects")
    @patch("minio.Minio.get_object")
    @patch("requests.get")
    @patch("kubernetes.config.load_kube_config")
    @patch("kubernetes.client.StorageV1Api")
    @patch("kubernetes.client.AppsV1Api")
    @patch("kubernetes.client.CustomObjectsApi")
    @patch("kubernetes.client.CoreV1Api", name="core", id="1")
    @patch("minio.Minio.make_bucket")
    @patch("time.sleep")
    @patch("socket.socket.connect_ex")
    def test_deploy_scenario_componets(
        self,
        socket_mock,
        time_mock,
        s3_mock,
        core_api_mock,
        custom_api_mock,
        apps_api_mock,
        storage_api_mock,
        k8s_config_mock,
        requests_mock,
        minio_mock,
        list_mock,
        print_mock,
        urlib_connection_mock,
        cert_api_mock,
        join_mock,
        minio_init_mock,
    ):
        minio_init_mock.return_value = None
        expected = {PframeMinio, PframeMinioConfigMap, FioStorageClass, Fio, PframeSync}
        requests_mock.return_value = RequestsResponse()
        socket_mock.return_value = 0
        join_mock.return_value = os.getcwd() + "/tests/examples/fio_version.txt"
        bench = Local(
            os.getcwd() + "/tests/examples/configs/local.yaml",
            logging.CRITICAL,
            None,
            None,
        )
        bench.run()
        resources = {resource.__class__ for resource in bench.resources}
        self.assertEqual(expected, resources)
