# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
import os
from pframe.utils.fio import print_fio_results, print_mount_options, merge_mount_options
from io import StringIO
from unittest.mock import patch


class MyTestCase(unittest.TestCase):
    def test_print_fio_results(self):
        self.maxDiff = None
        with patch("sys.stdout", new=StringIO()) as output:
            expected = [
                "",
                "Results for multi_drive_single_compute.",
                "",
                "",
                "POD_NAME                      COMPUTE_NODE    STORAGE_NODE     STORAGE_POOL      BW [MB/s]    IOPS    MEAN_LAT [usec]",
                "----------------------------  --------------  ---------------  --------------  -----------  ------  -----------------",
                "fio-storage-1-1-vg-nvme2n1-0  compute-1-3     storage-1-1.jf2  vg-nvme2n1           113.86    1821   171470",
                "fio-storage-1-1-vg-nvme3n1-0  compute-1-3     storage-1-1.jf2  vg-nvme3n1            16.87     269        2.03254e+06",
                "",
                "",
                "  BW_SUM [MB/s]    IOPS_SUM    BW_STDDEV",
                "---------------  ----------  -----------",
                "         130.73        2090      68.5823",
            ]

            print_fio_results(
                os.path.join(os.getcwd(), "tests/examples/fio_results.txt"),
                "multi_drive_single_compute",
            )
            self.assertListEqual(output.getvalue().split("\n")[:-1], expected)

    def test_print_mount_options(self):
        with patch("sys.stdout", new=StringIO()) as output:
            expected = [
                "POD_NAME                     MOUNT_OPTIONS                                                                                    EXTSIZE",
                "---------------------------  ---------------------------------------------------------------------------------------------  ---------",
                "fio-compute-1-1-vg-l-pmem-0  xfs rw,seclabel,noatime,nodiratime,attr2,dax,nobarrier,inode64,sunit=4096,swidth=4096,noquota    2097152",
                "",
            ]
            print_mount_options(
                os.path.join(os.getcwd(), "tests/examples/mount_options_results.txt")
            )
            self.assertListEqual(output.getvalue().split("\n")[:-1], expected)

    def test_merge_mount_options(self):
        expected_result_file = [
            "POD_NAME|MOUNT_OPTIONS|EXTSIZE",
            "fio-compute-1-1-vg-l-pmem-0|xfs rw,seclabel,noatime,nodiratime,attr2,dax,nobarrier,inode64,sunit=4096,swidth=4096,noquota|2097152",
        ]
        path = os.path.join(os.getcwd(), "tests/examples/mount_options_results")
        result = merge_mount_options(path)
        self.assertEqual(result, os.path.join(path, "mount_options.csv"))
        with open(result, "r") as f:
            result_file = f.read().split("\n")[:-1]
        self.assertListEqual(expected_result_file, result_file)
        os.remove(result)


if __name__ == "__main__":
    unittest.main()
