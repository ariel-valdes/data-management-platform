# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from io import StringIO
from unittest.mock import patch, mock_open
import importlib

parse = importlib.import_module("images.minio-bench.scripts.parse")


class fileObject:
    def readlines(self):
        return ["1", "2", "3"]


def side_effect(env_name):
    if env_name == "RW":
        return "randread"
    return env_name


class TestCase(unittest.TestCase):
    @patch("builtins.open")
    @patch("json.loads")
    @patch("os.getenv")
    def test_parse(self, getenv_mock, json_mock, open_mock):
        open_mock.return_value = fileObject()
        json_mock.side_effect = [
            "abc",
            {"totalObjects": 1, "rawSpeed": 2 * 1024 * 1024, "totalOperations": 3},
            {"totalObjects": 4, "rawSpeed": 5 * 1024 * 1024, "totalOperations": 6},
            {"totalObjects": 7, "rawSpeed": 8 * 1024 * 1024, "totalOperations": 9},
        ]
        expected = "HOSTNAME,NODE_NAME,1,2.00,3,4,5.00,6,CLUSTER_NR\n"
        getenv_mock.side_effect = side_effect
        with patch("builtins.open", mock_open(read_data="[1\n2\n3\n4\n]")):
            with patch("sys.stdout", new=StringIO()) as output:
                parse.main()
                self.assertEqual(output.getvalue(), expected)
