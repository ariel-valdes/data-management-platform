#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import json
import os
import sys


def main():
    file = sys.argv[1]
    with open(file) as f:
        output = json.load(f)

    rw = os.getenv("RW")
    if rw == "randread":
        rw = "read"
    elif rw == "randwrite":
        rw = "write"

    job = output["jobs"][0][rw]

    pmem = os.getenv("PMEM")

    results = [
        os.getenv("HOSTNAME"),
        os.getenv("NODE_NAME"),
        os.getenv("STORAGE_NODE"),
        os.getenv("STORAGE_POOL"),
        # fio is expected to return value in KiB/s so it is converted to B/s and then MB/s
        str((round(job["bw_mean"] * 1024 / 1000000, 2))),
        str(int(job["iops_mean"])),
        str(float(job["lat_ns"]["mean"]) / 1000),
    ]

    if pmem == "1":
        results.append(
            " ".join(
                [item["name"] for item in output["disk_util"] if "pmem" in item["name"]]
            )
        )
    print(",".join(results))


if __name__ == "__main__":
    main()
