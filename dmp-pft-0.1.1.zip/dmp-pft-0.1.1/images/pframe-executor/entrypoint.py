# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import asyncio
import os
import logging
from pathlib import Path
from typing import List

import aiohttp


class Worker:
    api_root: str
    phases: List[str]
    name: str

    def __init__(self, api_root: str, name: str, scripts_dir: str):
        self.api_root = api_root
        self.name = name
        self.scripts_dir = scripts_dir

    async def run(self) -> None:
        await self._gather_phases()

        for phase in self.phases:
            logging.info(f'Entering phase "{phase}".')

            await self._execute_script(phase)

            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=None)
            ) as session:
                await session.post(
                    f"{self.api_root}/phase/{phase}/advance",
                    json={"pod": {"name": self.name}},
                )
                resp = await session.get(f"{self.api_root}/phase/{phase}/finished")
                await resp.text()

    async def _gather_phases(self):
        async with aiohttp.ClientSession() as session:
            resp = await session.get(f"{self.api_root}/phases")
            data = await resp.json()

        self.phases = [phase["name"] for phase in data["phases"]]

    async def _execute_script(self, script: str):
        script_path = Path(f"{self.scripts_dir}/{script}")
        if script_path.is_file():
            process = await asyncio.create_subprocess_exec(
                str(script_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            async def print_stream(stream: asyncio.StreamReader) -> None:
                while not stream.at_eof():
                    line = (await stream.readline()).decode("utf-8")
                    if line:
                        logging.info(line.rstrip())

            await asyncio.wait(
                [print_stream(process.stdout), print_stream(process.stderr)]
            )

            if process.returncode == 0:
                logging.info(f'Executed script "{script}".')
            else:
                logging.error(
                    f'An error occurred: script "{script}" returned {process.returncode}.'
                )
        else:
            logging.info(f'Skipping phase "{script}"')


def main():
    pframe_sync_url = os.environ.get("PFRAME_SYNC_URL", "http://pframe-sync")
    scripts_dir = os.environ.get("SCRIPTS_DIR", "/scripts")
    hostname = os.environ.get("HOSTNAME")
    worker = Worker(pframe_sync_url, hostname, scripts_dir)
    logging.basicConfig(level=logging.INFO)
    asyncio.run(worker.run())


if __name__ == "__main__":
    main()
