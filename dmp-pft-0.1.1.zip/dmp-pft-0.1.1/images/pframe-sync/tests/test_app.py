# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import asyncio
from ipaddress import ip_network
from unittest import mock

from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop, TestClient
from aiohttp.web_app import Application

from pframe_sync.types import Phase
from pframe_sync import core


class PframeSyncTestCase(AioHTTPTestCase):
    client: TestClient

    def get_app(self) -> Application:
        return core.get_app(2, ip_network("127.0.0.0/8"))

    @unittest_run_loop
    async def test_root(self):
        resp = await self.client.get("/")
        self.assertEqual("Pframe-Sync", await resp.text())

    @unittest_run_loop
    async def test_current_phase(self):
        expected = {
            "phase": {
                "name": "init",
                "pods": [],
                "status": Phase.Status.IN_PROGRESS.value,
            }
        }
        resp = await self.client.get("/phase/current")
        self.assertEqual(expected, await resp.json())

    @unittest_run_loop
    async def test_get_phases(self):
        expected = {
            "phases": [
                {"name": "init", "pods": [], "status": Phase.Status.IN_PROGRESS.value},
                {
                    "name": "action",
                    "pods": [],
                    "status": Phase.Status.NOT_STARTED.value,
                },
                {
                    "name": "publish",
                    "pods": [],
                    "status": Phase.Status.NOT_STARTED.value,
                },
                {
                    "name": "cleanup",
                    "pods": [],
                    "status": Phase.Status.NOT_STARTED.value,
                },
            ]
        }
        resp = await self.client.get("/phases")
        phases = await resp.json()
        self.assertEqual(expected, phases)

    @unittest_run_loop
    async def test_advance_phase_advances_single_pod(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        phase = await self.client.get("/phase/current")

        expected = {
            "phase": {
                "name": "init",
                "pods": ["pod1"],
                "status": Phase.Status.IN_PROGRESS.value,
            }
        }
        self.assertEqual(expected, await phase.json())

    @unittest_run_loop
    async def test_waiting_for_phase_to_finish_does_not_complete(self):
        res = await self.client.get("/phase/init/finished")
        with self.assertRaises(asyncio.TimeoutError):
            await asyncio.wait_for(res.text(), 0.05)

    @unittest_run_loop
    async def test_advance_finishes_with_enough_clients(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod2"}})
        res = await self.client.get("phase/init/finished")
        await asyncio.wait_for(res.text(), 0.05)

    @unittest_run_loop
    async def test_advance_starts_another_phase(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod2"}})
        res = await self.client.get("/phase/current")
        data = await res.json()
        self.assertEqual("action", data["phase"]["name"])
        self.assertEqual(Phase.Status.IN_PROGRESS.value, data["phase"]["status"])

    @unittest_run_loop
    async def test_advance_finishes_current_phase(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod2"}})
        res = await self.client.get("/phase/init")
        data = await res.json()
        self.assertEqual(Phase.Status.FINISHED.value, data["phase"]["status"])

    @unittest_run_loop
    async def test_cannot_advance_phase_that_does_not_exist(self):
        resp = await self.client.post("/phase/foo/advance")
        data = await resp.json()
        self.assertIn("error", data)
        self.assertEqual(404, resp.status)

    @unittest_run_loop
    async def test_cannot_advance_phase_not_in_progress(self):
        resp = await self.client.post("/phase/action/advance")
        data = await resp.json()
        self.assertIn("error", data)
        self.assertEqual(409, resp.status)

    @unittest_run_loop
    async def test_cannot_advance_without_specifying_pod(self):
        resp = await self.client.post("/phase/init/advance")
        data = await resp.json()
        self.assertIn("error", data)
        self.assertEqual(422, resp.status)

    @unittest_run_loop
    async def test_advancing_empties_pods(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod2"}})
        res = await self.client.get("/phase/init")
        data = await res.json()
        self.assertEqual([], data["phase"]["pods"])

    @unittest_run_loop
    async def test_cannot_advance_same_pod_twice(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        res = await self.client.post(
            "/phase/init/advance", json={"pod": {"name": "pod1"}}
        )
        data = await res.json()
        self.assertIn("error", data)
        self.assertEqual(422, res.status)

    @unittest_run_loop
    async def test_cannot_get_pod_that_does_not_exist(self):
        res = await self.client.get("/pod/pod1")
        data = await res.json()
        self.assertIn("error", data)
        self.assertEqual(404, res.status)

    @unittest_run_loop
    async def test_can_get_pod(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})

        res = await self.client.get("/pod/pod1")
        self.assertEqual(200, res.status)

        data = await res.json()
        expected = {"pod": {"name": "pod1", "phase": "init"}}
        self.assertEqual(expected, data)

    @unittest_run_loop
    async def test_advancing_successfully_changes_pods_phase(self):
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod1"}})
        await self.client.post("/phase/init/advance", json={"pod": {"name": "pod2"}})
        resp = await self.client.get("/pod/pod1")
        data = await resp.json()
        self.assertEqual("action", data["pod"]["phase"])

    @unittest_run_loop
    async def test_post_from_outside_network_fails(self):
        with mock.patch("aiohttp.web.BaseRequest.transport") as transport:
            transport.get_extra_info.return_value = ("10.0.0.1", 1234)
            res = await self.client.post(
                "/phase/init/advance", json={"pod": {"name": "pod1"}}
            )

        data = await res.json()
        self.assertIn("error", data)
        self.assertEqual(403, res.status)

    @unittest_run_loop
    async def test_post_from_inside_network_succeeds(self):
        with mock.patch("aiohttp.web.BaseRequest.transport") as transport:
            transport.get_extra_info.return_value = ("127.0.0.1", 1234)
            res = await self.client.post(
                "/phase/init/advance", json={"pod": {"name": "pod1"}}
            )

        self.assertEqual(200, res.status)
