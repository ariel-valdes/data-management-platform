# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import asyncio
from asyncio import Future
from dataclasses import dataclass, field
from enum import Enum
from typing import List


@dataclass
class Phase:
    class Status(Enum):
        NOT_STARTED = "Not started"
        IN_PROGRESS = "In progress"
        FINISHED = "Finished"

    name: str
    status: Status = Status.NOT_STARTED
    pods: List[str] = field(default_factory=list)
    future: Future = field(
        default_factory=lambda: asyncio.get_event_loop().create_future()
    )

    def to_dict(self):
        return {"name": self.name, "status": self.status.value, "pods": self.pods}


@dataclass
class Pod:
    name: str
    phase: str
