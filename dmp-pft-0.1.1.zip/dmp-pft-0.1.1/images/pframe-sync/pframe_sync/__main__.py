# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import logging
import os
import sys
from ipaddress import ip_network

from aiohttp import web

from pframe_sync.core import get_app


def main():
    try:
        import uvloop

        uvloop.install()
    except ImportError:
        pass

    pod_count = int(os.environ.get("POD_COUNT", 0))

    if pod_count < 1:
        logging.error("POD_COUNT cannot be less than 0.")
        sys.exit(1)

    port = int(os.environ.get("PORT", 80))
    pod_network = ip_network(os.environ.get("POD_SUBNET", "0.0.0.0/0"))

    app = get_app(pod_count, pod_network)
    logging.basicConfig(level=logging.INFO)
    web.run_app(app, port=port, access_log=None)


if __name__ == "__main__":
    main()
