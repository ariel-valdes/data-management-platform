# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from dataclasses import asdict
from itertools import zip_longest
from json import JSONDecodeError
from typing import Dict
from ipaddress import IPv4Network, ip_address
import logging

from aiohttp import web

from . import constants
from .types import Phase, Pod


class PframeSync:
    pod_count: int
    phases: Dict[str, Phase]
    pods: Dict[str, Pod]
    current_phase: Phase
    _next_phases: Dict[str, Phase]

    def __init__(self, pod_count: int) -> None:
        self.pod_count = pod_count
        self.phases = {name: Phase(name=name) for name in constants.PHASE_NAMES}
        self.pods = {}
        self.current_phase = self.phases[constants.PHASE_NAMES[0]]
        self.current_phase.status = Phase.Status.IN_PROGRESS
        self._next_phases = dict(
            zip_longest(constants.PHASE_NAMES, list(self.phases.values())[1:])
        )

        for phase in self.phases.values():
            phase.future.add_done_callback(
                lambda f: logging.info(f'Completed phase "{f.result()}."')
            )

    async def get_phase(self, request: web.Request) -> web.Response:
        phase_name = request.match_info["phase_name"]
        return web.json_response({"phase": self.phases[phase_name].to_dict()})

    async def get_current_phase(self, _request: web.Request) -> web.Response:
        return web.json_response({"phase": self.current_phase.to_dict()})

    async def get_phases(self, _request: web.Request) -> web.Response:
        return web.json_response(
            {"phases": [phase.to_dict() for phase in self.phases.values()]}
        )

    async def advance_phase(self, request: web.Request) -> web.Response:
        phase_name = request.match_info["phase_name"]

        if phase_name not in constants.PHASE_NAMES:
            return web.json_response({"error": "No phase with that name."}, status=404)

        if phase_name != self.current_phase.name:
            return web.json_response(
                {"error": "Cannot advance a phase which hasn't been started."},
                status=409,
            )

        try:
            data = await request.json()
            pod_name = data["pod"]["name"]
        except (JSONDecodeError, KeyError):
            return web.json_response(
                {"error": "Received malformed request body."}, status=422
            )

        if pod_name in self.current_phase.pods:
            return web.json_response(
                {"error": "Specified pod has already finished that phase."}, status=422
            )

        self.current_phase.pods.append(pod_name)

        if pod_name not in self.pods:
            self.pods[pod_name] = Pod(name=pod_name, phase=phase_name)

        if len(self.current_phase.pods) == self.pod_count:
            self.current_phase.status = Phase.Status.FINISHED
            next_phase = self._next_phases[self.current_phase.name]

            if next_phase:
                self.current_phase.pods = []
                self.current_phase = next_phase
                self.current_phase.status = Phase.Status.IN_PROGRESS

                for pod in self.pods.values():
                    pod.phase = self.current_phase.name

            self.phases[phase_name].future.set_result(phase_name)

        return web.Response(status=200)

    async def wait_for_phase_finished(self, request: web.Request) -> web.StreamResponse:
        phase_name = request.match_info["phase_name"]
        if phase_name not in self.phases:
            return web.json_response({"error": "No such phase."}, status=404)

        resp = web.StreamResponse()
        await resp.prepare(request)

        await self.phases[phase_name].future
        return resp

    async def get_pod(self, request: web.Request) -> web.Response:
        pod_name = request.match_info["pod_name"]
        pod = self.pods.get(pod_name)
        if not pod:
            return web.json_response({"error": "Pod does not exist."}, status=404)

        return web.json_response({"pod": asdict(pod)})


async def root(_request: web.Request) -> web.Response:
    return web.Response(text="Pframe-Sync")


def reject_post_outside_network(network: IPv4Network):
    @web.middleware
    async def middleware(request: web.BaseRequest, handler):
        if request.method != "POST":
            return await handler(request)

        peer = request.transport.get_extra_info("peername")

        if peer:
            host, _ = peer

            if ip_address(host) in network:
                return await handler(request)

            logging.info(f"{host} - {request.method} {request.path} - 403 Forbidden")

        return web.json_response(
            {"error": "This action is not allowed from the current network."},
            status=403,
        )

    return middleware


def get_app(pod_count: int, pod_network: IPv4Network) -> web.Application:
    app = web.Application(middlewares=[reject_post_outside_network(pod_network)])

    pf_sync = PframeSync(pod_count)

    app.add_routes(
        [
            web.get("/", root),
            web.get("/phases", pf_sync.get_phases),
            web.get("/phase/current", pf_sync.get_current_phase),
            web.get("/phase/{phase_name}", pf_sync.get_phase),
            web.post("/phase/{phase_name}/advance", pf_sync.advance_phase),
            web.get("/phase/{phase_name}/finished", pf_sync.wait_for_phase_finished),
            web.get("/pod/{pod_name}", pf_sync.get_pod),
        ]
    )
    return app
