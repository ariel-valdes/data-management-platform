#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import json
import os
import sys


def main():
    file = sys.argv[1]
    with open(file) as f:
        content = f.readlines()
        for line_number, line in enumerate(content):
            if line_number == 0:
                json.loads(line)
            elif line_number == 1:
                put = json.loads(line)
                put_total_objects = put["totalObjects"]
                put_raw_speed = float(put["rawSpeed"]) / (1024 * 1024)
                put_total_ops = put["totalOperations"]
            elif line_number == 2:
                get = json.loads(line)
                get_total_objects = get["totalObjects"]
                get_raw_speed = float(get["rawSpeed"]) / (1024 * 1024)
                get_total_ops = get["totalOperations"]
            elif line_number == 3:
                delete = json.loads(line)
                delete["totalObjects"]
                delete["rawSpeed"]
                delete["totalOperations"]

    hostname = os.getenv("HOSTNAME")
    node_name = os.getenv("NODE_NAME")
    cluster_nr = os.getenv("CLUSTER_NR")

    print(
        f"{hostname},{node_name},{put_total_objects},{put_raw_speed:.2f},{put_total_ops},{get_total_objects},{get_raw_speed:.2f},{get_total_ops},{cluster_nr}"
    )


if __name__ == "__main__":
    main()
