#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import os
import argparse
import math
from typing import List, Tuple
from pathlib import Path

import docker


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dry_run",
        "-d",
        help="Prints names of images",
        action="store_true",
        default=False,
    )

    parser.add_argument("--registry", "-r", type=str, help="Path to docker registry")
    parser.add_argument(
        "--namespace",
        "-n",
        type=str,
        help="Namespace in which image will be pushed",
        default="",
    )

    parser.add_argument(
        "--tag", "-t", type=str, help="Tag which will be added to image name"
    )

    parser.add_argument(
        "--images_dir",
        "-i",
        type=str,
        help="Path to folder containing docker images",
        default=os.getcwd(),
    )

    args = parser.parse_args()
    dry = args.dry_run
    registry_url = args.registry
    namespace = args.namespace
    tag = args.tag
    path = args.images_dir
    images = get_folders_containing_dockerfile(path)

    if dry:
        dry_run(images, registry_url, namespace, tag)
        exit(1)

    os.chdir(path)
    client = docker.from_env()
    for image in images:
        build_and_push_dockerimage(image, tag, registry_url, namespace, client)


def get_folders_containing_dockerfile(path: str) -> List[str]:
    images: List[Tuple[str, float]] = []
    for child in Path(path).iterdir():
        if child.is_dir():
            if child.joinpath("Dockerfile").is_file():
                build_priority = child.joinpath(".build_priority")
                priority = (
                    int(build_priority.read_text())
                    if build_priority.exists()
                    else math.inf
                )
                images.append((child.name, priority))

    return [image[0] for image in sorted(images, key=lambda x: x[1])]


def build_and_push_dockerimage(
    image_name, tag, registry_url, namespace: str, docker_client: docker.DockerClient
) -> None:
    if namespace:
        repository = f"{registry_url}/{namespace}/{image_name}"
    else:
        repository = f"{registry_url}/{image_name}"

    image, build_log = docker_client.images.build(path=image_name, tag=f"{image_name}")

    for line in build_log:
        print(line)

    if not image.tag(f"{repository}", tag, force=True):
        raise Exception(f"Cannot tag image: {image.attrs} as {repository}/{tag}")

    for line in docker_client.images.push(
        repository, stream=True, decode=True, tag=tag
    ):
        print(line)


def dry_run(images: List[str], registry_url, namespace, tag):
    print("Images that would be build:")
    for image in images:
        print(
            f"Image {image} will be pushed as {registry_url}/{namespace}/{image}:{tag}"
        )


if __name__ == "__main__":
    main()
