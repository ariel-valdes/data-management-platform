#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import argparse

from pframe.config import NetDataConfig
from pframe.utils.netdata import deploy_netdata_minion, purge_netdata_minion


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "action",
        help="what action to perform, deploy or purge",
        type=str,
        choices=["deploy", "purge"],
    )
    parser.add_argument("-config", help="path to config", type=str)
    args = parser.parse_args()

    config = NetDataConfig(args.config)

    netdata_minion_name = "netdata-minion"
    netdata_minion_cm = "netdata-minion-config"

    if args.action == "deploy":
        # netdata_master = deploy_netdata_master(
        #     config.namespace,
        #     config.netdata_image,
        #     config.netdata_master_config,
        #     config.stream_master_config,
        #     netdata_master_name,
        #     netdata_master_cm,
        # )

        deploy_netdata_minion(
            config.namespace,
            config.netdata_image,
            config.netdata_minion_config,
            config.stream_minion_config,
            netdata_minion_name,
            netdata_minion_cm,
            config.nodes,
        )
    elif args.action == "purge":
        purge_netdata_minion(config.namespace, netdata_minion_name, netdata_minion_cm)
        # purge_netdata_master(config.namespace, netdata_master_name, netdata_master_cm)


if __name__ == "__main__":
    main()
