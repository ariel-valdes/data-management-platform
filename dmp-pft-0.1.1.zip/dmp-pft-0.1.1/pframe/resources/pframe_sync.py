# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from dataclasses import dataclass

from kubernetes import client

from pframe.resources.generic import PframeGenericResource


@dataclass
class PframeSync(PframeGenericResource):
    name: str
    namespace: str
    image: str
    pod_count: int
    pod_subnet: str
    apps_api: client.AppsV1Api
    core_api: client.CoreV1Api

    def __post_init__(self) -> None:
        self.labels = {"app.kubernetes.io/name": self.name}
        self.svc = self._get_svc()
        self.sts = self._get_sts()

    def create(self) -> None:
        self.core_api.create_namespaced_service(self.namespace, self.svc)
        self.apps_api.create_namespaced_stateful_set(self.namespace, self.sts)

    def delete(self) -> None:
        self.core_api.delete_namespaced_service(self.svc.metadata.name, self.namespace)
        self.apps_api.delete_namespaced_stateful_set(
            self.sts.metadata.name, self.namespace
        )

    def _get_svc(self) -> client.V1Service:
        service_spec = client.V1ServiceSpec(
            ports=[client.V1ServicePort(name="http", port=80, target_port=5000)],
            selector=self.labels,
        )
        return client.V1Service(
            api_version="v1",
            kind="Service",
            metadata=client.V1ObjectMeta(name=self.name, labels=self.labels),
            spec=service_spec,
        )

    def _get_sts(self) -> client.V1StatefulSet:
        sts_selector = client.V1LabelSelector(match_labels=self.labels)
        sts_spec = client.V1StatefulSetSpec(
            replicas=1,
            template=self._get_pod_template(),
            selector=sts_selector,
            service_name=self.name,
        )

        return client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(name=self.name, labels=self.labels),
            spec=sts_spec,
        )

    def _get_pod_template(self) -> client.V1PodTemplateSpec:
        tolerations = [
            client.V1Toleration(operator="Exists", key="dmp.intel.com/nodes")
        ]
        pod_spec = client.V1PodSpec(
            containers=[self._get_pframe_sync_container()],
            affinity=self._get_affinity(),
            tolerations=tolerations,
        )
        return client.V1PodTemplateSpec(
            metadata=client.V1ObjectMeta(labels=self.labels), spec=pod_spec
        )

    def _get_affinity(self) -> client.V1Affinity:
        hostname_label = "node-role.kubernetes.io/master"
        # prepare NodeAffinity to bind pods to nodes passed in TopologyOptions
        nodeSelectorRequirement = client.V1NodeSelectorRequirement(
            key=hostname_label, operator="In", values=["true"]
        )
        nodeSelectorTerms = client.V1NodeSelectorTerm([nodeSelectorRequirement])
        nodeSelector = client.V1NodeSelector([nodeSelectorTerms])
        node_affinity = client.V1NodeAffinity(
            required_during_scheduling_ignored_during_execution=nodeSelector
        )
        return client.V1Affinity(node_affinity=node_affinity)

    def _get_pframe_sync_container(self) -> client.V1Container:
        pframe_port = client.V1ContainerPort(container_port=5000, name=self.name)
        return client.V1Container(
            name=self.name,
            env=[
                client.V1EnvVar(name="POD_COUNT", value=str(self.pod_count)),
                client.V1EnvVar(name="PORT", value="5000"),
                client.V1EnvVar(name="POD_SUBNET", value=self.pod_subnet)
            ],
            image=self.image,
            ports=[pframe_port],
            readiness_probe=client.V1Probe(
                http_get=client.V1HTTPGetAction(path="/", port=self.name)
            ),
        )
