# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from dataclasses import dataclass
from typing import Dict, List

from kubernetes import client

from pframe.resources.generic import PframeGenericResource
from pframe.utils.kubernetes import generate_envs, get_affinity
from pframe.utils.fio import create_fio_runtime_options


@dataclass
class Fio(PframeGenericResource):
    name: str
    image: str
    namespace: str
    sc_name: str
    disk: str
    storage_node: str
    minio_endpoint: str
    minio_cm: str
    minio_bucket: str
    disk_size: str
    replicas: int
    computes: List[str]
    apps_api: client.AppsV1Api
    fio_params: Dict[str, str]
    pmem: bool

    def __post_init__(self) -> None:
        params = self.fio_params.copy()
        fio_runtime_options = create_fio_runtime_options(params)
        params["RW"] = params["fio_runtime_options"]["rw"]
        del params["fio_runtime_options"]

        self.labels = {"app.kubernetes.io/name": "fio"}
        self.envs = {
            "DIRECTORY": "/data",
            "MINIO_BUCKET": self.minio_bucket,
            "MINIO_ENDPOINT": self.minio_endpoint,
            "MINIO_CONFIG_DIR": "/etc/minio",
            "RESULTS_DIR": "/results",
            "BINARIES": "/binaries",
            "STORAGE_POOL": self.disk,
            "STORAGE_NODE": self.storage_node,
            "FS": self.fio_params["fio_runtime_options"].get("size", "default_size"),
            **params,
            "FIO_RUNTIME_OPTIONS": fio_runtime_options,
            "PFRAME_SYNC_URL": "http://pframe-sync",
            "PMEM": "1" if self.pmem else "0",
        }
        self.sts = self._generate_sts()

    def create(self) -> None:
        self.apps_api.create_namespaced_stateful_set(self.namespace, self.sts)

    def delete(self) -> None:
        self.apps_api.delete_namespaced_stateful_set(
            self.name, self.namespace, propagation_policy="Foreground"
        )

    def _generate_sts(self) -> client.V1StatefulSet:
        sts_selector = client.V1LabelSelector(match_labels=self.labels)
        sts_spec = client.V1StatefulSetSpec(
            pod_management_policy="Parallel",
            volume_claim_templates=[self._get_volume_clam_template("fio")],
            replicas=self.replicas,
            template=self._generate_pod_template(),
            selector=sts_selector,
            service_name=self.name,
        )

        return client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(name=self.name, labels=self.labels),
            spec=sts_spec,
        )

    def _generate_pod_template(self) -> client.V1PodTemplateSpec:
        tolerations = [
            client.V1Toleration(operator="Exists", key="dmp.intel.com/nodes")
        ]
        pod_spec = client.V1PodSpec(
            containers=[self._get_fio_container()],
            affinity=get_affinity(self.computes, self.labels),
            volumes=[self._get_minio_cm_volume()],
            tolerations=tolerations,
        )

        return client.V1PodTemplateSpec(
            metadata=client.V1ObjectMeta(labels=self.labels), spec=pod_spec
        )

    def _get_minio_cm_volume(self) -> client.V1Volume:
        return client.V1Volume(
            name=self.minio_cm,
            config_map=client.V1ConfigMapVolumeSource(name=self.minio_cm),
        )

    def _get_volume_clam_template(self, name: str) -> client.V1PersistentVolumeClaim:
        return client.V1PersistentVolumeClaim(
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=["ReadWriteOnce"],
                storage_class_name=self.sc_name,
                resources=client.V1ResourceRequirements(
                    requests={"storage": self.disk_size}
                ),
            ),
            metadata=client.V1ObjectMeta(name=name),
        )

    def _get_fio_container(self) -> client.V1Container:
        return client.V1Container(
            name="fio",
            image=self.image,
            image_pull_policy="Always",
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/minio/config.json",
                    name=self.minio_cm,
                    sub_path="config.json",
                ),
                client.V1VolumeMount(mount_path="/data", name="fio"),
            ],
            env=generate_envs(self.envs),
            security_context=client.V1SecurityContext(privileged=True),
        )


class StorageClassInvalidDiskType(Exception):
    pass


@dataclass
class FioStorageClass(PframeGenericResource):
    name: str
    disk: str
    storage_node: str
    fstype: str
    storage_api: client.StorageV1Api
    disk_type: str = "nvme"

    def __post_init__(self) -> None:
        self.sc = self._generate_sc()

    def _generate_sc(self) -> client.V1StorageClass:
        sc_params = {
            "storagePool": self.disk,
            "nodeList": self.storage_node,
            "layerList": self.disk_type,
            "fsType": self.fstype,
            "fsOpts": "-K -b size=4096 -d su=128k,sw=1",
            "placementPolicy": "Manual",
            "allowRemoteVolumeAccess": "true",
        }

        if self.disk_type == "nvme":
            sc_params["disklessStoragePool"] = "diskless"
        elif self.disk_type == "storage":
            sc_params["placementPolicy"] = "FollowTopology"
            sc_params["allowRemoteVolumeAccess"] = "false"
        else:
            raise StorageClassInvalidDiskType

        return client.V1StorageClass(
            kind="StorageClass",
            api_version="storage.k8s.io/v1",
            metadata=client.V1ObjectMeta(name=self.name),
            parameters=sc_params,
            provisioner="linstor.csi.linbit.com",
        )

    def create(self) -> None:
        self.storage_api.create_storage_class(self.sc)

    def delete(self) -> None:
        self.storage_api.delete_storage_class(self.name)
