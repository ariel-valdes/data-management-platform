# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.
import datetime
import json
import os
from base64 import b64encode
import urllib3

from dataclasses import dataclass
from typing import Any, Dict, List, Union
from abc import abstractmethod

from minio.error import BucketAlreadyExists, BucketAlreadyOwnedByYou

from kubernetes import client
from minio import Minio as MinioClient
from urllib3.util.ssl_ import create_urllib3_context

from pframe.resources.generic import PframeGenericResource

Json = Dict[str, Any]


@dataclass
class Minio(PframeGenericResource):
    name: str
    namespace: str
    access_key: str
    secret_key: str
    version: str
    replicas: int
    resources: Dict[str, Dict[str, str]]
    custom_api: client.CustomObjectsApi
    core_api: client.CoreV1Api
    disk_size: Union[str, None] = None
    sc_name: Union[str, None] = None
    nodes: Union[List[str], None] = None
    scheduler: Union[str, None] = None

    def __post_init__(self) -> None:
        self.labels = {"app.kubernetes.io/name": self.name}
        self.secret = self._generate_secret()
        self.secret_name = self.secret.metadata.name
        self.minio_instance = self.generate_minio_instance()
        self.svc = self._generate_service()
        self.minio_url = f"https://{self.name}.{self.namespace}.svc:9000"
        self.minio_endpoint = f"{self.name}.{self.namespace}.svc:9000"

    def _generate_service(self) -> client.V1Service:
        service_spec = client.V1ServiceSpec(
            ports=[client.V1ServicePort(name="https", port=9000, target_port=9000)],
            selector=self.labels,
        )
        return client.V1Service(
            api_version="v1",
            kind="Service",
            metadata=client.V1ObjectMeta(name=self.name, labels=self.labels),
            spec=service_spec,
        )

    @abstractmethod
    def generate_minio_instance(self):
        ...

    def _generate_secret(self) -> client.V1Secret:
        accesskey = b64encode(bytes(self.access_key, "utf-8")).decode("utf-8")
        secretkey = b64encode(bytes(self.secret_key, "utf-8")).decode("utf-8")
        return client.V1Secret(
            api_version="v1",
            kind="Secret",
            type="Opaque",
            metadata=client.V1ObjectMeta(name=f"secret-{self.name}"),
            data={
                # decode from bytes to string
                "accesskey": accesskey,
                "secretkey": secretkey,
            },
        )

    def create(self) -> None:
        self.core_api.create_namespaced_service(self.namespace, self.svc)
        self.core_api.create_namespaced_secret(self.namespace, self.secret)
        self.custom_api.create_namespaced_custom_object(
            "miniocontroller.min.io",
            "v1beta1",
            self.namespace,
            "minioinstances",
            self.minio_instance,
        )

    def delete(self) -> None:
        body = client.V1DeleteOptions()
        self.custom_api.delete_namespaced_custom_object(
            "miniocontroller.min.io",
            "v1beta1",
            self.namespace,
            "minioinstances",
            self.name,
            body,
        )
        self.core_api.delete_namespaced_secret(self.secret_name, self.namespace)
        self.core_api.delete_namespaced_service(self.svc.metadata.name, self.namespace)


class BenchMinio(Minio):
    def __post_init__(self) -> None:
        super().__post_init__()
        self.minio_url = f"http://{self.name}.{self.namespace}.svc:9000"

    def generate_minio_instance(self) -> Json:
        body = {
            "kind": "MinIOInstance",
            "apiVersion": "miniocontroller.min.io/v1beta1",
            "metadata": {"name": self.name, "namespace": self.namespace},
            # "scheduler": {"name": "dmp-scheduler"},
            "spec": {
                "replicas": self.replicas,
                "version": self.version,
                "podManagementPolicy": "OrderedReady",
                "credsSecret": {"name": self.secret_name},
                "resources": self.resources,
                "metadata": {"labels": {**self.labels, "pframe-minio": "true"}},
                "liveness": {
                    "httpGet": {
                        "path": "/minio/health/live",
                        "port": 9000,
                        "scheme": "HTTP",
                    },
                    "initialDelaySeconds": 120,
                    "periodSeconds": 20,
                },
                "readiness": {
                    "httpGet": {"path": "/minio/health/ready", "port": 9000},
                    "initialDelaySeconds": 10,
                    "periodSeconds": 5,
                },
                "volumeClaimTemplate": {
                    "metadata": {"name": "data"},
                    "spec": {
                        "accessModes": ["ReadWriteOnce"],
                        "storageClassName": self.sc_name,
                        "resources": {"requests": {"storage": self.disk_size}},
                    },
                },
                "env": [{"name": "MINIO_STORAGE_CLASS_STANDARD", "value": "EC:4"}],
                "affinity": {
                    "nodeAffinity": {
                        "requiredDuringSchedulingIgnoredDuringExecution": {
                            "nodeSelectorTerms": [{"matchExpressions": []}]
                        }
                    },
                    "podAntiAffinity": {
                        "preferredDuringSchedulingIgnoredDuringExecution": [
                            {
                                "weight": 100,
                                "podAffinityTerm": {
                                    "labelSelector": {
                                        "matchExpressions": [
                                            {
                                                "key": "app.kubernetes.name",
                                                "operator": "In",
                                                "values": [self.name],
                                            }
                                        ]
                                    },
                                    "topologyKey": "failure-domain.beta.kubernetes.io/zone",
                                },
                            },
                            {
                                "weight": 100,
                                "podAffinityTerm": {
                                    "labelSelector": {
                                        "matchExpressions": [
                                            {
                                                "key": "pframe-minio",
                                                "operator": "In",
                                                "values": ["true"],
                                            }
                                        ]
                                    },
                                    "topologyKey": "failure-domain.beta.kubernetes.io/zone",
                                },
                            },
                        ]
                    },
                },
            },
        }

        if len(self.nodes) > 0:
            body["spec"]["affinity"]["nodeAffinity"][
                "requiredDuringSchedulingIgnoredDuringExecution"
            ]["nodeSelectorTerms"][0]["matchExpressions"] = [
                {
                    "key": "kubernetes.io/hostname",
                    "operator": "In",
                    "values": self.nodes,
                }
            ]
        else:
            body["spec"]["affinity"]["nodeAffinity"][
                "requiredDuringSchedulingIgnoredDuringExecution"
            ]["nodeSelectorTerms"][0]["matchExpressions"] = [
                {
                    "key": "node-role.kubernetes.io/compute",
                    "operator": "In",
                    "values": ["true"],
                }
            ]

        if self.scheduler:
            body["scheduler"] = {"name": self.scheduler}

        return body


@dataclass
class PframeMinio(Minio):
    def generate_minio_instance(self):
        body = {
            "kind": "MinIOInstance",
            "apiVersion": "miniocontroller.min.io/v1beta1",
            "metadata": {"name": self.name, "namespace": self.namespace},
            "spec": {
                "metadata": {"labels": {**self.labels}},
                # for most usecases it should be 1
                "replicas": self.replicas,
                "version": self.version,
                "credsSecret": {"name": self.secret_name},
                "requestAutoCert": True,
                "resources": self.resources,
                "liveness": {
                    "httpGet": {
                        "path": "/minio/health/live",
                        "port": 9000,
                        "scheme": "HTTPS",
                    },
                    "initialDelaySeconds": 120,
                    "periodSeconds": 20,
                },
                "certConfig": {
                    "commonName": f"{self.name}.{self.namespace}.svc.cluster.local",
                    "organizationName": ["DMP"],
                    "dnsNames": [
                        f"{self.name}.{self.namespace}.svc.cluster.local",
                        f"{self.name}.{self.namespace}.svc",
                    ],
                },
            },
        }

        return body


@dataclass
class PframeMinioConfigMap(PframeGenericResource):
    name: str
    namespace: str
    minio_endpoint: str
    access_key: str
    secret_key: str
    core_api: client.CoreV1Api

    def __post_init__(self) -> None:
        self.cm = self._get_pframe_minio_configmap()

    def _get_pframe_minio_configmap(self) -> client.V1ConfigMap:
        minio_cm = {
            "version": "9",
            "hosts": {
                f"{self.minio_endpoint}": {
                    "url": f"https://{self.minio_endpoint}",
                    "accessKey": self.access_key,
                    "secretKey": self.secret_key,
                    "api": "s3v4",
                    "lookup": "auto",
                }
            },
        }
        return client.V1ConfigMap(
            api_version="v1",
            kind="ConfigMap",
            metadata=client.V1ObjectMeta(name=self.name),
            data={"config.json": json.dumps(minio_cm)},
        )

    def create(self) -> None:
        self.core_api.create_namespaced_config_map(self.namespace, self.cm)

    def delete(self) -> None:
        self.core_api.delete_namespaced_config_map(
            self.cm.metadata.name, self.namespace
        )


@dataclass
class PframeMinioClient:
    minio_bucket: str
    minio_endpoint: str
    access_key: str
    secret_key: str
    ca_certs: str
    insecure: bool
    scenario: str

    def __post_init__(self):
        allowed_ciphers = (
            "ECDHE-RSA-AES128-GCM-SHA256"
            ":ECDHE-ECDSA-AES128-GCM-SHA256"
            ":ECDHE-RSA-AES256-GCM-SHA384"
            ":ECDHE-ECDSA-AES256-GCM-SHA384"
        )

        cert_reqs = not self.insecure
        context = create_urllib3_context(
            ciphers=allowed_ciphers, cert_reqs=cert_reqs
        )
        # insecure option doesn't verify certificates
        if self.insecure:
            self.s3Client = MinioClient(
                self.minio_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=True,
                http_client=urllib3.PoolManager(
                    timeout=urllib3.Timeout.DEFAULT_TIMEOUT,
                    maxsize=10,
                    ssl_context=context,
                    retries=urllib3.Retry(
                        total=5,
                        backoff_factor=0.2,
                        status_forcelist=[500, 502, 503, 504],
                    ),
                ),
            )

        else:
            ca_certs = self.ca_certs if self.ca_certs else "/etc/ssl/certs/ca-bundle.crt"
            self.s3Client = MinioClient(
                self.minio_endpoint,
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=True,
                http_client=urllib3.PoolManager(
                    ssl_context=context,
                    ca_certs=ca_certs,
                    maxsize=10,
                    retries=urllib3.Retry(
                        total=5,
                        backoff_factor=0.2,
                        status_forcelist=[500, 502, 503, 504],
                    ),
                ),
            )

    def make_bucket(self):
        try:
            self.s3Client.make_bucket(self.minio_bucket)
        except BucketAlreadyExists:
            print(f"Bucket {self.minio_bucket} already exists skipping")
        except BucketAlreadyOwnedByYou:
            print(f"Bucket {self.minio_bucket} already owned by you ")

    def get_results(self) -> str:

        objects = self.s3Client.list_objects(self.minio_bucket, recursive=True)
        now = datetime.datetime.now().isoformat()

        results_dir = f"results/{self.scenario}/{now}"
        os.makedirs(results_dir)

        for obj in objects:
            name = obj.object_name
            data = self.s3Client.get_object(self.minio_bucket, name)
            with open(f"{results_dir}/{os.path.basename(name)}", "wb") as file:
                for d in data.stream():
                    file.write(d)

        return results_dir
