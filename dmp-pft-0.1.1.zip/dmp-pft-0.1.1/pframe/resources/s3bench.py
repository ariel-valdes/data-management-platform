# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from dataclasses import dataclass
from typing import List

from kubernetes import client

from pframe.utils.kubernetes import generate_envs, get_affinity
from pframe.resources.generic import PframeGenericResource


@dataclass
class S3Bench(PframeGenericResource):
    name: str
    namespace: str
    image: str
    s3bench_endpoint: str
    s3bench_bucket: str
    s3bench_access_key: str
    s3bench_secret_key: str
    s3bench_threads: int
    s3bench_obj_size: int
    s3bench_duration: int
    pframe_minio_endpoint: str
    pframe_minio_bucket: str
    pframe_minio_cm: str
    replicas: int
    nodes: List[str]
    apps_api: client.AppsV1Api
    cluster_nr: int

    def __post_init__(self) -> None:
        self.labels = {"app.kubernetes.io/name": self.name}
        pframe_envs = {
            "MINIO_BUCKET": self.pframe_minio_bucket,
            "MINIO_ENDPOINT": self.pframe_minio_endpoint,
            "MINIO_CONFIG_DIR": "/etc/minio",
            "RESULTS_DIR": "/results",
            "BINARIES": "/binaries",
            "PFRAME_SYNC_URL": "http://pframe-sync",
        }
        s3bench_envs = {
            "ACCESS_KEY": self.s3bench_access_key,
            "SECRET_KEY": self.s3bench_secret_key,
            "BENCH_BUCKET": self.s3bench_bucket,
            "THREADS": str(self.s3bench_threads),
            "DURATION": str(self.s3bench_duration),
            "OBJ_SIZE": self.s3bench_obj_size,
            "BENCH_MINO_URL": self.s3bench_endpoint,
            "CLUSTER_NR": str(self.cluster_nr),
        }
        self.envs = {**pframe_envs, **s3bench_envs}
        self.sts = self._generate_sts()

    def _generate_sts(self) -> client.V1StatefulSet:
        sts_selector = client.V1LabelSelector(match_labels=self.labels)
        sts_spec = client.V1StatefulSetSpec(
            pod_management_policy="Parallel",
            replicas=self.replicas,
            template=self._get_pod_template(),
            selector=sts_selector,
            service_name=self.name,
        )

        return client.V1StatefulSet(
            api_version="apps/v1",
            kind="StatefulSet",
            metadata=client.V1ObjectMeta(name=self.name, labels=self.labels),
            spec=sts_spec,
        )

    def _get_pod_template(self) -> client.V1PodTemplateSpec:
        pod_spec = client.V1PodSpec(
            containers=[self._get_container()],
            affinity=get_affinity(self.nodes, self.labels),
            volumes=[self._get_volume()],
        )

        return client.V1PodTemplateSpec(
            metadata=client.V1ObjectMeta(labels=self.labels), spec=pod_spec
        )

    def _get_container(self) -> client.V1Container:
        return client.V1Container(
            name=self.name,
            image=self.image,
            image_pull_policy="Always",
            command=["python3", "/executor/entrypoint.py"],
            volume_mounts=[
                client.V1VolumeMount(
                    mount_path="/etc/minio/config.json",
                    name=self.pframe_minio_cm,
                    sub_path="config.json",
                )
            ],
            env=generate_envs(self.envs),
            security_context=client.V1SecurityContext(privileged=True),
        )

    def _get_volume(self) -> client.V1Volume:
        return client.V1Volume(
            name=self.pframe_minio_cm,
            config_map=client.V1ConfigMapVolumeSource(name=self.pframe_minio_cm),
        )

    def delete(self) -> None:
        self.apps_api.delete_namespaced_stateful_set(
            self.sts.metadata.name, self.namespace
        )

    def create(self) -> None:
        self.apps_api.create_namespaced_stateful_set(self.namespace, self.sts)
