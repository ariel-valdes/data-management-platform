# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import csv
import datetime
from os import listdir

from tabulate import tabulate
import time

from kubernetes import client


def wait_for_csr(name: str, retries: int):
    for _ in range(retries):
        try:
            cert_api = client.CertificatesV1beta1Api()
            cert_api.read_certificate_signing_request(name=name)
            break
        except client.rest.ApiException:
            time.sleep(2)


def sign_csr(name):
    cert_api = client.CertificatesV1beta1Api()
    csr = cert_api.read_certificate_signing_request(name=name)
    approval_condition = client.V1beta1CertificateSigningRequestCondition(
        type="Approved",
        reason="abc",
        message="cde",
        last_update_time=datetime.datetime.now().astimezone(),
    )
    csr.status.conditions = [approval_condition]
    cert_api.replace_certificate_signing_request_approval(name, csr)


def merge_fio_results(results_dir: str, pmem=False) -> str:
    header = [
        "POD_NAME",
        "COMPUTE_NODE",
        "STORAGE_NODE",
        "STORAGE_POOL",
        "BW [MB/s]",
        "IOPS",
        "MEAN_LAT [usec]",
    ]
    if pmem:
        header.append("PMEM")
    files = [file for file in listdir(results_dir) if file.endswith(".pframe")]

    results_csv = f"{results_dir}/results.csv"

    with open(results_csv, "w") as results:
        results.write(",".join(header) + "\n")
        for file in files:
            with open(f"{results_dir}/{file}") as f:
                results.write(f.read())

    return results_csv


def merge_minio_results(results_dir: str) -> str:
    header = [
        "POD_NAME",
        "COMPUTE_NODE",
        "PUT_TOTAL_OBJ",
        "PUT_SPEED [MiB/s]",
        "PUT_TOTAL_OPS",
        "GET_TOTAL_OBJ",
        "GET_SPEED [MiB/s]",
        "GET_TOTAL_OPS",
        "CLUSTER_NR",
    ]
    files = [file for file in listdir(results_dir) if file.endswith(".pframe")]

    results_csv = f"{results_dir}/results.csv"

    with open(results_csv, "w") as results:
        results.write(",".join(header) + "\n")
        for file in files:
            with open(f"{results_dir}/{file}") as f:
                results.write(f.read())

    return results_csv


def print_minio_results(results_file, scenario: str, concurrent_clusters: int) -> None:
    print(f"Results for {scenario}.")
    cluster_nrs = []
    put_total_obj_list = []
    put_speed_list = []
    get_speed_list = []
    get_total_obj_list = []
    with open(results_file) as f:
        csv_file = csv.reader(f, delimiter=",")
        header = next(csv_file)
        results_table = []
        for row in csv_file:
            cluster_nrs.append(row[8])
            put_total_obj = int(row[2])
            put_total_obj_list.append(put_total_obj)
            put_speed = float(row[3])
            put_speed_list.append(put_speed)
            get_total_obj = int(row[5])
            get_total_obj_list.append(get_total_obj)
            get_speed = float(row[6])
            get_speed_list.append(get_speed)
            results_table.append(row)

    print(tabulate(results_table, headers=header))
    print("\n")
    cluster_table = []
    header = [
        "CLUSTER_NUMBER",
        "PUT_SPEED_SUM [MiB/s]",
        "PUT_TOTAL_OBJ_SUM",
        "GET_SPEED_SUM [MiB/s]",
        "GET_TOTAL_OBJ_SUM",
    ]

    # Insert zeros in all used field of list
    cluster_put_speed_sum = [0 for i in range(concurrent_clusters)]
    cluster_put_total_obj_sum = [0 for i in range(concurrent_clusters)]
    cluster_get_speed_sum = [0 for i in range(concurrent_clusters)]
    cluster_get_total_obj_sum = [0 for i in range(concurrent_clusters)]

    for i, cluster_nr in enumerate(cluster_nrs):
        cluster_put_speed_sum[int(cluster_nr)] += put_speed_list[i]
        cluster_put_total_obj_sum[int(cluster_nr)] += put_total_obj_list[i]
        cluster_get_speed_sum[int(cluster_nr)] += get_speed_list[i]
        cluster_get_total_obj_sum[int(cluster_nr)] += get_total_obj_list[i]

    for row in range(concurrent_clusters):
        cluster_table.append(
            [
                row,
                cluster_get_speed_sum[row],
                cluster_put_total_obj_sum[row],
                cluster_get_speed_sum[row],
                cluster_get_total_obj_sum[row],
            ]
        )

    print("Results for each minio cluster")
    print(tabulate(cluster_table, headers=header))
    print("\n")
    sum_table = [
        [
            sum(put_speed_list),
            sum(put_total_obj_list),
            sum(get_speed_list),
            sum(get_total_obj_list),
        ]
    ]
    header = [
        "PUT_SPEED_SUM [MiB/s]",
        "PUT_TOTAL_OBJ_SUM",
        "GET_SPEED_SUM [MiB/s]",
        "GET_TOTAL_OBJ_SUM",
    ]
    print("Sum of results")
    print(tabulate(sum_table, headers=header))
