# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import time
from typing import List
import requests
import logging


def wait_for_test_completion(pframe_endpoint, namespace: str) -> None:
    times = []
    times.append(time.time())
    logger = logging.getLogger("Benchmark")
    phases = ["init", "action", "publish", "cleanup"]
    for phase in phases:
        url = f"http://{pframe_endpoint}.{namespace}.svc"
        requests.get(f"{url}/phase/{phase}/finished")
        logger.info(f"Phase {phase} has finished")
        times.append(time.time())

    phases_times = {}
    for name, execution_time in zip(phases, times[1:]):
        phases_times[name] = execution_time - times[0] - sum(phases_times.values())
    phases_times["total"] = times[-1] - times[0]
    return phases_times


def print_phases_times(phases_times: List[str]) -> None:
    line = "Phases times:"
    for name, execution_time in phases_times.items():
        line += f" {name}: {execution_time:.2f} s"
    print(line)
