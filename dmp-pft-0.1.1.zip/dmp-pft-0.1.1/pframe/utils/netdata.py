# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from typing import Dict, List

from kubernetes import client

from pframe import get_api_client

k8s_client = get_api_client()

PORT = 19999


def generate_envs() -> List[client.V1EnvVar]:
    return [
        client.V1EnvVar(
            name="MY_POD_NAME",
            value_from=client.V1EnvVarSource(
                field_ref=client.V1ObjectFieldSelector(field_path="metadata.name")
            ),
        ),
        client.V1EnvVar(
            name="MY_POD_NAMESPACE",
            value_from=client.V1EnvVarSource(
                field_ref=client.V1ObjectFieldSelector(field_path="metadata.namespace")
            ),
        ),
    ]


def get_netdata_container(
    name, image, config_cm: str, port: int, volume_mounts: List[client.V1VolumeMount]
) -> client.V1Container:
    return client.V1Container(
        name=name,
        image=image,
        image_pull_policy="Always",
        volume_mounts=[
            client.V1VolumeMount(
                mount_path="/etc/netdata/.opt-out-from-anonymous-statistics",
                name=config_cm,
                sub_path="optout",
            ),
            *volume_mounts,
        ],
        env=generate_envs(),
        lifecycle=client.V1Lifecycle(
            post_start=client.V1Handler(
                _exec=client.V1ExecAction(
                    command=[
                        "/bin/sh",
                        "-c",
                        "python -c 'import uuid; import socket; print(uuid.uuid3(uuid.NAMESPACE_DNS, socket.gethostname()))' > /var/lib/netdata/registry/netdata.public.unique.id",
                    ]
                )
            ),
            pre_stop=client.V1Handler(
                _exec=client.V1ExecAction(
                    command=[
                        "/bin/sh",
                        "-c",
                        "killall netdata; while killall -0 netdata; do sleep 1; done",
                    ]
                )
            ),
        ),
        ports=[
            client.V1ContainerPort(protocol="TCP", name="http", container_port=port)
        ],
        security_context=client.V1SecurityContext(privileged=True),
        resources=client.V1ResourceRequirements(
            limits={"cpu": "2", "memory": "4Gi"}, requests={"cpu": "2", "memory": "4Gi"}
        ),
        liveness_probe=client.V1Probe(
            http_get=client.V1HTTPGetAction(path="/api/v1/info", port="http"),
            timeout_seconds=1,
            period_seconds=30,
            success_threshold=1,
            failure_threshold=3,
        ),
        readiness_probe=client.V1Probe(
            http_get=client.V1HTTPGetAction(path="/api/v1/info", port="http"),
            timeout_seconds=1,
            period_seconds=30,
            success_threshold=1,
            failure_threshold=3,
        ),
    )


def create_netdata_cm(namespace, name, netdata_config, stream_config: str) -> str:
    cm = client.V1ConfigMap(
        kind="ConfigMap",
        metadata=client.V1ObjectMeta(name=name),
        data={"netdata": netdata_config, "stream": stream_config, "optout": ""},
    )
    cm_api = client.CoreV1Api(k8s_client)
    netdata_cm = cm_api.create_namespaced_config_map(namespace, cm)
    return netdata_cm.metadata.name


def get_master_affinity() -> client.V1Affinity:
    hostname_label = "node-role.kubernetes.io/master"
    # prepare NodeAffinity to bind pods to nodes passed in TopologyOptions
    nodeSelectorRequirement = client.V1NodeSelectorRequirement(
        key=hostname_label, operator="In", values=["true"]
    )
    nodeSelectorTerms = client.V1NodeSelectorTerm([nodeSelectorRequirement])
    nodeSelector = client.V1NodeSelector([nodeSelectorTerms])
    node_affinity = client.V1NodeAffinity(
        required_during_scheduling_ignored_during_execution=nodeSelector
    )
    return client.V1Affinity(node_affinity=node_affinity)


def get_minion_nodes_affinity(nodes: List[str]) -> client.V1Affinity:
    hostname_label = "kubernetes.io/hostname"
    # prepare NodeAffinity to bind pods to nodes passed in TopologyOptions
    nodeSelectorRequirement = client.V1NodeSelectorRequirement(
        key=hostname_label, operator="In", values=nodes
    )
    nodeSelectorTerms = client.V1NodeSelectorTerm([nodeSelectorRequirement])
    nodeSelector = client.V1NodeSelector([nodeSelectorTerms])
    node_affinity = client.V1NodeAffinity(
        required_during_scheduling_ignored_during_execution=nodeSelector
    )
    return client.V1Affinity(node_affinity=node_affinity)


def get_minion_roles_affinity(roles: List[str]) -> client.V1Affinity:
    # prepare NodeAffinity to bind pods to nodes passed in TopologyOptions
    terms = []
    for role in roles:
        terms.append(
            client.V1NodeSelectorTerm(
                [
                    client.V1NodeSelectorRequirement(
                        key=role, operator="In", values=["true"]
                    )
                ]
            )
        )
    nodeSelector = client.V1NodeSelector(terms)
    node_affinity = client.V1NodeAffinity(
        required_during_scheduling_ignored_during_execution=nodeSelector
    )
    return client.V1Affinity(node_affinity=node_affinity)


def deploy_netdata_service(
    namespace: str, labels: Dict[str, str], port: int
) -> client.V1Service:
    service_spec = client.V1ServiceSpec(
        ports=[client.V1ServicePort(name="http", port=port, target_port=port)],
        selector=labels,
    )
    svc = client.V1Service(
        api_version="v1",
        kind="Service",
        metadata=client.V1ObjectMeta(name="netdata", labels=labels),
        spec=service_spec,
    )
    service_api = client.CoreV1Api(k8s_client)
    return service_api.create_namespaced_service(namespace, svc)


def purge_netdata_minion(namespace, netdata_minion_name, netdata_cm: str) -> None:
    extension_api = client.ExtensionsV1beta1Api(k8s_client)
    extension_api.delete_namespaced_daemon_set(
        netdata_minion_name, namespace, propagation_policy="Foreground"
    )

    cm_api = client.CoreV1Api(k8s_client)
    cm_api.delete_namespaced_config_map(netdata_cm, namespace)


def get_netdata_minio_template(
    namespace,
    netdata_image,
    netdata_config,
    stream_config,
    netdata_minion_name,
    netdata_cm: str,
    nodes: List[str],
):
    netdata_minion_labels = {"app.kubernetes.io/name": "netdata-minion"}

    affinity = None
    if len(nodes) != 0:
        # affinity = get_minion_nodes_affinity(nodes)
        affinity = get_minion_roles_affinity(
            ["node-role.kubernetes.io/compute", "node-role.kubernetes.io/storage"]
        )

    netdata_cm = create_netdata_cm(namespace, netdata_cm, netdata_config, stream_config)

    # netdata_volume = client.V1Volume(
    #    name=netdata_cm, config_map=client.V1ConfigMapVolumeSource(name=netdata_cm)
    # )
    volume_mounts = [
        client.V1VolumeMount(mount_path="/host/proc", read_only=True, name="proc"),
        client.V1VolumeMount(
            mount_path="/var/run/docker.sock", read_only=True, name="run"
        ),
        client.V1VolumeMount(mount_path="/host/sys", read_only=True, name="sys"),
        client.V1VolumeMount(
            mount_path="/etc/netdata/netdata.conf", name=netdata_cm, sub_path="netdata"
        ),
        client.V1VolumeMount(
            mount_path="/etc/netdata/stream.conf", name=netdata_cm, sub_path="stream"
        ),
    ]
    container = get_netdata_container(
        netdata_minion_name, netdata_image, netdata_cm, PORT, volume_mounts
    )

    volumes = [
        client.V1Volume(
            name=netdata_cm, config_map=client.V1ConfigMapVolumeSource(name=netdata_cm)
        ),
        client.V1Volume(
            name="proc", host_path=client.V1HostPathVolumeSource(path="/proc")
        ),
        client.V1Volume(
            name="run",
            host_path=client.V1HostPathVolumeSource(path="/var/run/docker.sock"),
        ),
        client.V1Volume(
            name="sys", host_path=client.V1HostPathVolumeSource(path="sys")
        ),
    ]
    pod_spec = client.V1PodSpec(
        containers=[container],
        affinity=affinity,
        volumes=volumes,
        host_pid=True,
        host_network=True,
        host_ipc=True,
        dns_policy="ClusterFirstWithHostNet",
    )
    pod_template = client.V1PodTemplateSpec(
        metadata=client.V1ObjectMeta(labels=netdata_minion_labels), spec=pod_spec
    )

    ds_selector = client.V1LabelSelector(match_labels=netdata_minion_labels)
    ds_spec = client.V1DaemonSetSpec(selector=ds_selector, template=pod_template)

    return client.V1DaemonSet(
        kind="DaemonSet",
        metadata=client.V1ObjectMeta(name=netdata_minion_name),
        spec=ds_spec,
    )


def deploy_netdata_minion(
    namespace,
    netdata_image,
    netdata_config,
    stream_config,
    netdata_minion_name,
    netdata_cm: str,
    nodes: List[str],
) -> str:

    ds = get_netdata_minio_template(
        netdata_image,
        netdata_config,
        stream_config,
        netdata_minion_name,
        netdata_cm,
        nodes,
        namespace,
    )
    extension_api = client.ExtensionsV1beta1Api(k8s_client)
    netdata_ds = extension_api.create_namespaced_daemon_set(namespace, ds)
    return netdata_ds.metadata.name


def purge_netdata_master(namespace, netdata_master_name, netdata_cm: str) -> None:
    service_api = client.CoreV1Api(k8s_client)
    service_api.delete_namespaced_service("netdata", namespace)

    apps_api = client.AppsV1Api(k8s_client)
    apps_api.delete_namespaced_stateful_set(netdata_master_name, namespace)

    cm_api = client.CoreV1Api(k8s_client)
    cm_api.delete_namespaced_config_map(netdata_cm, namespace)


def get_netdata_master_template(
    namespace,
    netdata_image,
    netdata_config,
    stream_config,
    netdata_master_name,
    netdata_cm: str,
):
    replicas = 1
    netdata_master_labels = {"app.kubernetes.io/name": "netdata-master"}

    affinity = get_master_affinity()

    netdata_cm = create_netdata_cm(namespace, netdata_cm, netdata_config, stream_config)
    volume_mounts = [
        client.V1VolumeMount(
            mount_path="/etc/netdata/netdata.conf", name=netdata_cm, sub_path="netdata"
        ),
        client.V1VolumeMount(
            mount_path="/etc/netdata/stream.conf", name=netdata_cm, sub_path="stream"
        ),
    ]
    container = get_netdata_container(
        netdata_master_name, netdata_image, netdata_cm, PORT, volume_mounts
    )
    netdata_volume = client.V1Volume(
        name=netdata_cm, config_map=client.V1ConfigMapVolumeSource(name=netdata_cm)
    )

    pod_spec = client.V1PodSpec(
        containers=[container], affinity=affinity, volumes=[netdata_volume]
    )
    pod_template = client.V1PodTemplateSpec(
        metadata=client.V1ObjectMeta(labels=netdata_master_labels), spec=pod_spec
    )

    sts_selector = client.V1LabelSelector(match_labels=netdata_master_labels)
    sts_spec = client.V1StatefulSetSpec(
        pod_management_policy="Parallel",
        replicas=replicas,
        template=pod_template,
        selector=sts_selector,
        service_name=netdata_master_name,
    )

    return client.V1StatefulSet(
        api_version="apps/v1",
        kind="StatefulSet",
        metadata=client.V1ObjectMeta(
            name=netdata_master_name, labels=netdata_master_labels
        ),
        spec=sts_spec,
    )


def deploy_netdata_master(
    namespace,
    netdata_image,
    netdata_config,
    stream_config,
    netdata_master_name,
    netdata_cm: str,
) -> str:
    netdata_master_labels = {"app.kubernetes.io/name": "netdata-master"}

    sts = get_netdata_master_template(
        namespace,
        netdata_image,
        netdata_config,
        stream_config,
        netdata_master_name,
        netdata_cm,
    )
    apps_api = client.AppsV1Api(k8s_client)
    deploy_netdata_service(namespace, netdata_master_labels, PORT)
    netdata_sts = apps_api.create_namespaced_stateful_set(namespace, sts)

    return netdata_sts.metadata.name
