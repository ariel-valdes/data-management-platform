# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import csv
from statistics import stdev
from typing import Dict
from tabulate import tabulate
from os import listdir, path


class ConfigError(Exception):
    pass


def print_fio_version(results_dir: str):
    with open(path.join(results_dir, "fio.version"), "r") as f:
        print(f"\nFio version: {f.readline()}")


def create_fio_runtime_options(options: Dict):
    fio_runtime_options = ""
    params = options.copy()
    for key, value in params["fio_runtime_options"].items():
        fio_runtime_options += f" --{key}={value}"
    return fio_runtime_options


def print_fio_results(results_file, scenario: str) -> None:
    title = f"\nResults for {scenario}."
    print(title)
    bw_list = []
    iops_list = []
    with open(results_file) as f:
        csv_file = csv.reader(f, delimiter=",")
        header = next(csv_file)
        results_table = []
        for row in csv_file:
            bw = float(row[4])
            iops = int(row[5])
            results_table.append(row)
            bw_list.append(bw)
            iops_list.append(iops)

    print("\n")
    print(tabulate(results_table, headers=header))
    print("\n")
    header = ["BW_SUM [MB/s]", "IOPS_SUM", "BW_STDDEV"]
    std_dev = 0
    if len(bw_list) > 1:
        std_dev = stdev(bw_list)

    print(tabulate([[sum(bw_list), sum(iops_list), std_dev]], headers=header))


def merge_mount_options(results_dir: str) -> str:
    header = ["POD_NAME", "MOUNT_OPTIONS", "EXTSIZE"]
    files = [f for f in listdir(results_dir) if f.endswith(".mount")]

    results_csv = f"{results_dir}/mount_options.csv"

    with open(results_csv, "w") as results:
        results.write("|".join(header) + "\n")
        for file_object in files:
            with open(f"{results_dir}/{file_object}") as f:
                data = f.readlines()
                line = []
                line.append(data[0].strip("\n"))
                line.append(data[1].split(" ")[2] + " " + data[1].split(" ")[3])
                line.append(data[2].split(" ")[0].strip("[]"))
                results.write("|".join(line) + "\n")

    return results_csv


def print_mount_options(results_file: str):
    with open(results_file) as f:
        csv_file = csv.reader(f, delimiter="|")
        header = next(csv_file)
        results_table = []
        for row in csv_file:
            results_table.append(row)
        print(tabulate(results_table, headers=header) + "\n")


def validate_storage_pools(sps: list):
    sp_list = []
    duplicates = []
    for item in sps:
        sp_list.append(item["node"] + " " + item["disk"])
    for i, item in enumerate(sp_list):
        if item in sp_list[:i]:
            duplicates.append(item)

    if len(duplicates) > 0:
        raise ConfigError("Duplicates inside storage_pools: " + str(duplicates))
