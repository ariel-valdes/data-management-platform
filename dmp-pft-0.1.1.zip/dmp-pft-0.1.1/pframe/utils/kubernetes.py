# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import socket
import time
from typing import Dict, List, Callable, Any
import logging

from kubernetes import config, client
from kubernetes.client.rest import ApiException


class KubernetesClient:
    def __init__(self) -> None:
        # init k8s clients
        self.k8s_client = self.get_api_client()
        self.core_api = client.CoreV1Api(self.k8s_client)
        self.apps_api = client.AppsV1Api(self.k8s_client)
        self.storage_api = client.StorageV1Api(self.k8s_client)
        self.custom_api = client.CustomObjectsApi(self.k8s_client)

    @staticmethod
    def get_api_client():
        # init k8s config
        config.load_kube_config()
        configuration = client.Configuration()
        configuration.verify_ssl = False
        return client.ApiClient(configuration=configuration)


def generate_envs(envs: Dict[str, str]) -> List[client.V1EnvVar]:
    env_vars = []
    for key, value in envs.items():
        env_vars.append(client.V1EnvVar(name=key, value=value))

    env_vars.append(
        client.V1EnvVar(
            name="NODE_NAME",
            value_from=client.V1EnvVarSource(
                field_ref=client.V1ObjectFieldSelector(field_path="spec.nodeName")
            ),
        )
    )

    return env_vars


def wait_for_endpoints(svc, namespace, k8s_client):
    api = client.CoreV1Api(k8s_client)
    # wait till svc endpoint
    while True:
        endpoints = api.read_namespaced_endpoints(svc, namespace)
        if not endpoints.subsets:
            print(f"{svc} has no endpoints. Sleeping")
            time.sleep(1)
        else:
            break


def wait_for_adresses(svc, namespace, number_replicas, k8s_client):
    while True:
        api = client.CoreV1Api(k8s_client)
        endpoints = api.read_namespaced_endpoints(svc, namespace)
        if not endpoints.subsets[0].addresses:
            print(f"No addresses in  subsets")
            time.sleep(1)
            continue

        add_len = len(endpoints.subsets[0].addresses)
        if add_len != number_replicas:
            print(f"{svc} has {add_len} wanted {number_replicas} . Sleeping")
            time.sleep(1)
            continue

        break


def wait_for_svc(svc, namespace, k8s_client):
    while True:
        api = client.CoreV1Api(k8s_client)
        endpoints = api.read_namespaced_endpoints(svc, namespace)
        start_again = False
        for subset in endpoints.subsets:
            if subset.not_ready_addresses and len(subset.not_ready_addresses) > 0:
                start_again = True
                break

        if start_again:
            print(f"{svc} not ready sleeping")
            time.sleep(1)

        else:
            print(f"{svc} is ready")
            break


def wait_for_connection(svc, namespace, port):
    while True:
        logger = logging.getLogger("Benchmark")
        url = f"{svc}.{namespace}.svc"
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ping = sock.connect_ex((url, port))
        if ping == 0:
            sock.close()
            break
        else:
            logger.info("Service is not receiving connections, sleeping")
            time.sleep(1)


def wait_for_bench(svc, namespace: str, port: int, number_replicas: int = None) -> None:
    k8s_client = KubernetesClient.get_api_client()
    wait_for_endpoints(svc, namespace, k8s_client)
    if number_replicas:
        wait_for_adresses(svc, namespace, number_replicas, k8s_client)

    wait_for_svc(svc, namespace, k8s_client)

    # if endpoints.subsets and endpoints.subsets[0].addresses:
    #     break

    # wait till svc starts receiving traffic
    wait_for_connection(svc, namespace, port)


def get_affinity(computes: List[str], labels: Dict[str, str]) -> client.V1Affinity:
    hostname_label = "kubernetes.io/hostname"
    # prepare NodeAffinity to bind pods to nodes passed in TopologyOptions
    nodeSelectorRequirement = client.V1NodeSelectorRequirement(
        key=hostname_label, operator="In", values=computes
    )
    nodeSelectorTerms = client.V1NodeSelectorTerm([nodeSelectorRequirement])
    nodeSelector = client.V1NodeSelector([nodeSelectorTerms])
    node_affinity = client.V1NodeAffinity(
        required_during_scheduling_ignored_during_execution=nodeSelector
    )

    # prepare PodAntiAffinity to spread pods through hosts
    labelSelectorRequirement = client.V1LabelSelectorRequirement(
        key=list(labels.keys())[0], operator="In", values=[list(labels.values())[0]]
    )
    labelSelector = client.V1LabelSelector([labelSelectorRequirement])
    podAffinityTerm = client.V1PodAffinityTerm(
        labelSelector, topology_key=hostname_label
    )
    weightedPodAffinityTerm = client.V1WeightedPodAffinityTerm(podAffinityTerm, 100)
    pod_anti_affinity = client.V1PodAntiAffinity([weightedPodAffinityTerm])
    return client.V1Affinity(
        node_affinity=node_affinity, pod_anti_affinity=pod_anti_affinity
    )


def delete_pvc(name, namespace: str) -> None:
    k8s_client = KubernetesClient.get_api_client()
    if exists_pvc(name, namespace):
        core_api = client.CoreV1Api(k8s_client)
        core_api.delete_namespaced_persistent_volume_claim(name, namespace)


def ignore_if_exists(function) -> Callable[[List[Any]], List[Any]]:
    def wrapper(*args, **kwargs):
        try:
            function(*args, **kwargs)
        except ApiException as exception:
            if exception.status == 404:
                return False
            else:
                print("HTTP error: {}".format(exception.status))
                raise exception
        else:
            return True

    return wrapper


@ignore_if_exists
def exists_pvc(name, namespace: str):
    k8s_client = KubernetesClient.get_api_client()
    core_api = client.CoreV1Api(k8s_client)
    core_api.read_namespaced_persistent_volume_claim(name, namespace)
