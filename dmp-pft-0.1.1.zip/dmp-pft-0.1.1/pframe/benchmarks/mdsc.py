# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from pframe.utils import print_phases_times
from pframe.config import Config, MultiDriveSingleComputeConfig
from pframe.utils.minio import merge_fio_results
from pframe.utils.fio import (
    print_fio_results,
    merge_mount_options,
    print_mount_options,
    create_fio_runtime_options,
    print_fio_version,
)
from pframe.resources.fio import Fio, FioStorageClass
from pframe.benchmarks.bench import Bench


class Mdsc(Bench):
    scenario: str = "multi_drive_single_compute"

    def load_config(self, config_path: str) -> Config:
        return MultiDriveSingleComputeConfig(config_path)

    def deploy_scenario_components(self) -> None:
        self.logger.debug("Creating storage class")
        for sp in self.config.storage_pools:
            node = sp["node"]
            disk = sp["disk"]
            replicas = sp.get("replicas", 1)
            sc = FioStorageClass(
                self._get_storage_class_name(disk, node),
                disk,
                node,
                self.config.fstype,
                self.k8s_client.storage_api,
            )
            sc.create()
            self.resources.append(sc)
            self.logger.debug("Creating sts")
            sts_name = f"fio-{node.split('.')[0]}-{disk}"
            fio = Fio(
                sts_name,
                self.config.fio_image,
                self.config.namespace,
                sc.name,
                disk,
                node,
                self.pframe_minio.minio_endpoint,
                self.pframe_minio_cm.name,
                self.config.minio_bucket,
                self.config.disk_size,
                replicas,
                self.config.computes,
                self.k8s_client.apps_api,
                self.config.fio_params,
                pmem=False,
            )
            fio.create()
            self.resources.append(fio)

    def save_results(self) -> None:
        results_dir = self.get_results_dir()
        results_file = merge_fio_results(results_dir)
        print_fio_results(results_file, self.scenario)
        mount_results_file = merge_mount_options(results_dir)
        print_mount_options(mount_results_file)
        print(
            f"\n\nFio options used: {create_fio_runtime_options(self.config.fio_params.copy())}\n"
        )
        print_phases_times(self.phases_times)
        print_fio_version(results_dir)

    def clean_scenario(self) -> None:
        self.logger.debug("Deleting sts")
        for resource in self.resources:
            resource.delete()

    def _get_storage_class_name(self, disk, storage_node: str) -> str:
        return f"pframe-{storage_node.split('.')[0]}-{disk}"
