# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from typing import List

import logging
import sys
import urllib3

from abc import ABC, abstractmethod

from pframe.utils import wait_for_test_completion
from pframe.utils.kubernetes import wait_for_bench, delete_pvc, KubernetesClient
from pframe.utils.minio import sign_csr, wait_for_csr
from pframe.config import Config
from pframe.resources.generic import PframeGenericResource
from pframe.resources.minio import PframeMinio, PframeMinioConfigMap, PframeMinioClient
from pframe.resources.pframe_sync import PframeSync


class Bench(ABC):
    def __init__(
        self, config_path: str, logging_level: int, certs_path: str, ssl_insecure: bool
    ) -> None:
        # disable insecure SSL warning
        urllib3.disable_warnings()
        self.ssl_insecure = ssl_insecure
        self.certs_path = certs_path
        self.k8s_client = KubernetesClient()
        # create loggers
        self.logger = self.create_logger(logging_level)
        self.config = self.load_config(config_path)
        self.pod_count = self.config.pod_count
        self.csr_name = "pframe-minio-csr"
        self.pframe_minio = PframeMinio(
            "pframe-minio",
            self.config.namespace,
            self.config.minio_accesskey,
            self.config.minio_secretkey,
            self.config.minio_version,
            self.config.minio_replicas,
            self.config.minio_resources,
            self.k8s_client.custom_api,
            self.k8s_client.core_api,
        )
        self.minio_bucket = PframeMinioClient(
            self.config.minio_bucket,
            self.pframe_minio.minio_endpoint,
            self.config.minio_accesskey,
            self.config.minio_secretkey,
            self.certs_path,
            self.ssl_insecure,
            self.scenario,
        )

        self.pframe_minio_cm = PframeMinioConfigMap(
            "pframe-minio-cm",
            self.config.namespace,
            self.pframe_minio.minio_endpoint,
            self.config.minio_accesskey,
            self.config.minio_secretkey,
            self.k8s_client.core_api,
        )

        self.pframe_sync = PframeSync(
            "pframe-sync",
            self.config.namespace,
            self.config.pframe_image,
            self.config.pod_count,
            self.config.pod_subnet,
            self.k8s_client.apps_api,
            self.k8s_client.core_api,
        )
        self.resources: List[PframeGenericResource] = []

    @property
    @classmethod
    @abstractmethod
    def scenario(cls) -> str:
        pass

    @abstractmethod
    def load_config(self, config_path: str) -> Config:
        pass

    def create_logger(self, logging_level: int):
        logger = logging.getLogger("Benchmark")
        logger.setLevel(logging.getLevelName(logging_level))
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.getLevelName(logging_level))
        formatter = logging.Formatter("{asctime} {message}", style="{")
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        return logger

    def deploy_pframe_minio(self) -> None:
        # use Minio Operator deploy CRD and wait till Minio SVC has endpoints
        self.logger.debug("Deploying MinioInstance")
        self.pframe_minio.create()
        self.resources.append(self.pframe_minio)

        self.logger.debug("Deploying configmap")
        self.pframe_minio_cm.create()
        self.resources.append(self.pframe_minio_cm)

    def deploy_pframe_components(self) -> None:
        self.deploy_pframe_minio()
        wait_for_csr(self.csr_name, 20)
        sign_csr(self.csr_name)
        # Wait till Minio Operator will create svc
        self.logger.info("Sleeping till operator will deploy Minio")
        wait_for_bench(self.pframe_minio.name, self.config.namespace, 9000)

        # make bucket
        self.logger.debug("Creating bucket")

        self.minio_bucket.make_bucket()
        self.logger.debug("Deploying pframe sync")
        self.pframe_sync.create()
        self.resources.append(self.pframe_sync)

        wait_for_bench(self.pframe_sync.name, self.config.namespace, 80)

    @abstractmethod
    def deploy_scenario_components(self) -> None:
        ...

    def run(self):
        try:
            self.deploy_pframe_components()
            self.deploy_scenario_components()
            self.phases_times = wait_for_test_completion(
                self.pframe_sync.name, self.config.namespace
            )

        except KeyboardInterrupt:
            print("Interrupted by keyboard")

        else:
            self.save_results()

        finally:
            self.clean()

    def get_results_dir(self) -> str:
        self.logger.info("Saving results")
        results_dir = self.minio_bucket.get_results()
        return results_dir

    @abstractmethod
    def save_results(self) -> None:
        pass

    def clean(self):
        for resource in self.resources:
            resource.delete()

        pvcs = self.k8s_client.core_api.list_namespaced_persistent_volume_claim(
            self.config.namespace
        )

        for pvc in pvcs.items:
            self.logger.debug(f"Deleting pvc {pvc.metadata.name}")
            delete_pvc(pvc.metadata.name, self.config.namespace)
