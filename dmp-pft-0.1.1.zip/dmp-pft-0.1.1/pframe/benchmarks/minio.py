# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import time

from pframe.utils import print_phases_times
from pframe.config import Config, MinioConfig
from pframe.resources.minio import BenchMinio
from pframe.resources.s3bench import S3Bench
from pframe.utils.minio import merge_minio_results, print_minio_results

from pframe.utils.kubernetes import wait_for_bench
from pframe.benchmarks.bench import Bench


class MinioOperator(Bench):
    scenario = "minio-operator"

    def load_config(self, config_path: str) -> Config:
        return MinioConfig(config_path)

    def deploy_scenario_components(self) -> None:
        bench_minios = []
        if not self.config.s3bench_nodes:
            self.logger.error("No s3bench nodes were given")
            raise KeyboardInterrupt
        # We are first creating all MinioInstances since it takes couple of minutes
        # to spin up the cluster
        for cluster_nr in range(self.config.concurrent_clusters):
            # deploy minio to be benchmarked
            self.logger.debug(f"Deploying minio nr {cluster_nr}")
            bench_minio = BenchMinio(
                f"{self.config.bench_minio_name}-{cluster_nr}",
                self.config.namespace,
                self.config.bench_minio_accesskey,
                self.config.bench_minio_secretkey,
                self.config.bench_minio_version,
                self.config.bench_minio_replicas,
                self.config.bench_minio_resources,
                self.k8s_client.custom_api,
                self.k8s_client.core_api,
                self.config.bench_minio_disk_size,
                self.config.bench_minio_storage_class,
                self.config.bench_minio_nodes,
                self.config.bench_minio_scheduler,
            )
            # append local variable so we will be able to wait for all instances
            bench_minio.create()
            bench_minios.append(bench_minio)
            self.resources.append(bench_minio)

        # Wait till Minio Operator will create svc

        self.logger.info("Sleeping till operator will deploy Bench Minio")
        time.sleep(5)

        for bench_minio in bench_minios:
            # wait for benchmarked minio
            wait_for_bench(
                bench_minio.svc.metadata.name,
                bench_minio.namespace,
                9000,
                bench_minio.replicas,
            )

        for i, bench_minio in enumerate(bench_minios):
            name = f"s3bench-{i}"
            self.logger.debug("Creating s3bench nr {}".format(i))
            s3bench = S3Bench(
                name,
                self.config.namespace,
                self.config.s3bench_image,
                bench_minio.minio_url,
                self.config.s3bench_bucket,
                bench_minio.access_key,
                bench_minio.secret_key,
                self.config.s3bench_thread_num,
                self.config.s3bench_obj_size,
                self.config.s3bench_duration,
                self.pframe_minio.minio_endpoint,
                self.config.minio_bucket,
                self.pframe_minio_cm.name,
                self.config.s3bench_replicas,
                self.config.s3bench_nodes,
                self.k8s_client.apps_api,
                i,
            )

            s3bench.create()
            self.resources.append(s3bench)

    def save_results(self) -> None:
        results_dir = self.get_results_dir()
        results_file = merge_minio_results(results_dir)
        print_minio_results(
            results_file, self.scenario, self.config.concurrent_clusters
        )
        print_phases_times(self.phases_times)

    def clean_scenario(self) -> None:
        for resource in self.resources:
            resource.delete()
