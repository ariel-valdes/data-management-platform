# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

from typing import Dict, Any

from kubernetes import client
from kubernetes import config as k8s_config

Config = Dict[str, Any]


def get_api_client():
    # init k8s config
    k8s_config.load_kube_config()
    configuration = client.Configuration()
    configuration.verify_ssl = False
    return client.ApiClient(configuration=configuration)
