# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import re
from copy import deepcopy
from functools import lru_cache
from typing import Dict, List, Union, Type
from marshmallow import Schema, fields, ValidationError, validate

from abc import ABC, abstractmethod
import yaml

from pframe.utils.fio import validate_storage_pools
from pframe.utils.validate_fio_option import validate_fio_option


class ConfigError(Exception):
    pass


FIO_DEFAULTS = {
    "fio_runtime_options": {
        "directory": "/data",
        "output-format": "json",
        "name": "test",
        "size": "1G",
        "time_based": "1",
    },
    "FLUSH_CACHE": "0",
}
MINIO_DEFAULTS = {
    "minio_cluster_bucket": "pframe",
    "minio_cluster_name": "pframe-minio",
    "minio_cluster_version": "",
    "minio_cluster_sa": "default",
    "minio_cluster_secret": "pframe-minio-secret",
    "minio_cluster_replicas": 1,
    "minio_cluster_accesskey": "pframe",
    "minio_cluster_secretkey": "pframesecret",
    "minio_cluster_ec": "EC:1",
    "minio_cluster_resources": {
        "requests": {"memory": "16Gi", "cpu": 4},
        "limits": {"memory": "16Gi", "cpu": 4},
    },
}

BENCH_MINIO_DEFAULTS: Dict[str, str] = {
    "name": "bench-minio",
    "replicas": 12,
    "bench_minio_accesskey": "pframeaccess",
    "bench_minio_secretkey": "pframesecret",
    "bench_minio_secret": "bench-minio-secret",
    "bench_minio_resources": {
        "requests": {"memory": "16Gi", "cpu": 4},
        "limits": {"memory": "16Gi", "cpu": 4},
    },
    "bench_minio_scheduler": None,
    "bench_minio_version": "",
    "bench_minio_storage_class": "linstor-dmpbalancer",
    "bench_minio_storage_class_name": "linstor-dmpbalancer",
    "bench_minio_disk_size": "10G",
}
S3_BENCH_DEFAULTS: Dict[str, str] = {
    "s3bench_replicas": 2,
    "s3bench_bucket": "pframe",
    "s3bench_thread_num": 1,
    "s3bench_obj_size": "1M",
    "s3bench_duration": 10,
    "s3bench_minio_accesskey": "pframeaccess",
    "s3bench_minio_secretkey": "pframesecret",
}

DEFAULT = {
    "namespace": "pframe",
    "fstype": "xfs",
    "computes": [],
    "disk_size": "100G",
    "fio_params": FIO_DEFAULTS,
    "minio": MINIO_DEFAULTS,
}


class FioParamsSchema(Schema):
    fio_runtime_options = fields.Dict(required=True)
    FLUSH_CACHE = fields.Int(required=True, validate=validate.OneOf([0, 1]))


class RequestsSchema(Schema):
    memory = fields.Str(required=True)
    cpu = fields.Int(required=True)


class ResourcesSchema(Schema):
    requests = fields.Nested(RequestsSchema, required=True)
    limits = fields.Nested(RequestsSchema, required=True)


class SPSchema(Schema):
    node = fields.Str(required=True)
    disk = fields.Str(required=True)
    replicas = fields.Int()


class MinioClusterSchema(Schema):
    minio_cluster_bucket = fields.Str(required=True)
    minio_cluster_name = fields.Str(required=True)
    minio_cluster_version = fields.Str(required=True)
    minio_cluster_sa = fields.Str(required=True)
    minio_cluster_secret = fields.Str(required=True)
    minio_cluster_replicas = fields.Int(required=True)
    minio_cluster_accesskey = fields.Str(required=True)
    minio_cluster_secretkey = fields.Str(required=True)
    minio_cluster_ec = fields.Str(required=True)
    minio_cluster_resources = fields.Nested(ResourcesSchema, required=True)


class BenchMinioSchema(Schema):
    name = fields.Str()
    replicas = fields.Int(required=True)
    bench_minio_accesskey = fields.Str(required=True)
    bench_minio_secretkey = fields.Str(required=True)
    bench_minio_secret = fields.Str(required=True)
    bench_minio_resources = fields.Nested(ResourcesSchema, required=True)
    bench_minio_nodes = fields.List(fields.Str, required=True)
    bench_minio_disk_size = fields.Str(required=True)
    bench_minio_scheduler = fields.Str(required=True, allow_none=True)
    bench_minio_storage_class = fields.Str(required=True)
    bench_minio_storage_class_name = fields.Str(required=True)
    bench_minio_version = fields.Str(required=True)


class S3BenchSchema(Schema):
    s3bench_replicas = fields.Int(required=True)
    s3bench_image = fields.Str(required=True)
    s3bench_thread_num = fields.Int(required=True)
    s3bench_obj_size = fields.Str(required=True)
    s3bench_nodes = fields.List(fields.Str, required=True)
    s3bench_minio_secretkey = fields.Str(required=True)
    s3bench_minio_accesskey = fields.Str(required=True)
    s3bench_duration = fields.Int(required=True)
    s3bench_bucket = fields.Str(required=True)


class ConfigSchema(Schema):
    scenario = fields.Str(required=True)
    pframe_image = fields.Str(required=True)
    bucket_name = fields.Str()
    minio = fields.Nested(MinioClusterSchema())
    namespace = fields.Str(required=True)
    fstype = fields.Str(required=True)
    computes = fields.List(fields.Str, required=True)
    disk_size = fields.Str(required=True)
    pod_subnet = fields.Str()


class FioSchema(ConfigSchema):
    fio_image = fields.Str(required=True)
    fio_params = fields.Nested(FioParamsSchema, required=True)
    storage_pools = fields.List(fields.Nested(SPSchema), required=True)
    replicas = fields.Int(required=False)
    pmem = fields.Bool()


class MinioSchema(ConfigSchema):
    concurrent_clusters = fields.Int(required=True)
    bench_minio = fields.Nested(BenchMinioSchema, required=True)
    s3bench_config = fields.Nested(S3BenchSchema, required=True)


def get_duplicates(items: list) -> list:
    duplicates = []

    for i, item in enumerate(items):
        if item in items[:i]:
            duplicates.append(item)

    return duplicates


class NetDataConfig:
    def __init__(self, config_path: str) -> None:
        with open(config_path, "r") as file:
            self.config = yaml.load(file.read(), Loader=yaml.FullLoader)

    @property
    def nodes(self) -> List[str]:
        return self.config.get("nodes", [])

    @property
    def netdata_image(self) -> str:
        return self.config["netdata_image"]

    @property
    def netdata_master_config(self) -> str:
        return self.config["netdata_master_config"]

    @property
    def stream_master_config(self) -> str:
        return self.config["stream_master_config"]

    @property
    def netdata_minion_config(self) -> str:
        return self.config["netdata_minion_config"]

    @property
    def stream_minion_config(self) -> str:
        return self.config["stream_minion_config"]

    @property
    def namespace(self) -> str:
        return self.config.get("namespace", "pframe")


class Config(ABC):
    schema: Type[Schema]

    def __init__(self, config_path: str) -> None:
        if hasattr(self, "config"):
            self.config.update(deepcopy(DEFAULT))
        else:
            self.config = deepcopy(DEFAULT)
        with open(config_path, "r") as file:
            loaded_file = yaml.load(file.read(), Loader=yaml.FullLoader)
        if "fio_params" in loaded_file:
            loaded_file = self._covnert_fio_options(loaded_file)
        for key, value in loaded_file.items():
            if type(value) == dict:
                self.config[key].update(value)
            else:
                self.config[key] = value

    def _covnert_fio_options(self, loaded_file):
        if "fio_runtime_options" in loaded_file["fio_params"]:
            pattern = r"\A[a-zA-Z0-9:/\"\"]*\Z"
            regex = re.compile(pattern)
            for key, value in loaded_file["fio_params"]["fio_runtime_options"].items():
                if validate_fio_option(key) and regex.match(value):
                    self.config["fio_params"]["fio_runtime_options"][key] = value
            del loaded_file["fio_params"]["fio_runtime_options"]
        return loaded_file

    def print_config(self):
        print("Config that will be used: ")
        print(yaml.dump(self.config))

    def validate_config(self):
        try:
            self.schema().load(self.config)
        except ValidationError as err:
            print(yaml.dump(err.messages))
            if err.messages:
                raise ConfigError

        if hasattr(self, "storage_pools") and len(self.storage_pools) > 1:
            validate_storage_pools(self.storage_pools)

        if hasattr(self, "computes") and len(self.computes) > 1:
            duplicates = get_duplicates(self.computes)
            if duplicates:
                raise ConfigError("Duplicates inside computes:" + str(duplicates))

    @property
    @classmethod
    @abstractmethod
    def pod_count(self) -> int:
        """
        This is really important method it returns on how many pods Pframe-sync should
        synchronize
        """
        ...

    @property  # type: ignore
    @lru_cache()
    def minio(self) -> Dict[str, str]:
        minio = MINIO_DEFAULTS.copy()
        if "minio" in self.config.keys():
            for key, value in self.config["minio"].items():
                minio["key"] = value
        return minio

    @property
    def namespace(self) -> str:
        return self.config.get("namespace", "pframe")

    @property
    def fstype(self) -> str:
        return self.config.get("fstype", "xfs")

    @property  # type: ignore
    @lru_cache()
    def nodes(self) -> List[str]:
        spls = self.storage_pools
        nodes = []
        for sp in spls:
            nodes.append(sp["node"])

        return nodes

    @property  # type: ignore
    @lru_cache()
    def disks(self) -> List[str]:
        spls = self.storage_pools
        disks = []
        for sp in spls:
            disks.append(sp["disk"])

        return disks

    @property
    def disk_size(self) -> str:
        return self.config.get("disk_size", "100G")

    @property  # type: ignore
    @lru_cache()
    def fio_params(self) -> Dict[str, str]:
        return self.config["fio_params"]

    @property
    def minio_accesskey(self) -> str:
        return self.minio["minio_cluster_accesskey"]

    @property
    def minio_secretkey(self) -> str:
        return self.minio["minio_cluster_secretkey"]

    @property
    def minio_secret(self) -> str:
        return self.minio["minio_cluster_secret"]

    @property
    def minio_cluster_name(self) -> str:
        return self.minio["minio_cluster_name"]

    @property
    def minio_version(self) -> str:
        return self.minio.get("minio_cluster_version", "")

    @property
    def minio_replicas(self) -> str:
        return self.minio.get("minio_cluster_replicas", 1)

    @property
    def minio_resources(self) -> str:
        return self.minio.get("minio_cluster_resources", {})

    @property
    def minio_configmap(self) -> str:
        return self.minio.get("minio_cluster_configmap", "minio-config")

    @property
    def minio_bucket(self) -> str:
        return self.minio.get("minio_cluster_bucket", "pframe")

    @property
    def pframe_image(self) -> str:
        return self.config["pframe_image"]

    @property
    def fio_image(self) -> str:
        return self.config["fio_image"]

    @property
    def pod_subnet(self) -> str:
        return self.config.get("pod_subnet", "0.0.0.0/0")


class MultiComputeSingleDriveConfig(Config):
    schema = FioSchema

    @property
    def computes(self) -> List[str]:
        return self.config.get("computes", [])

    @property
    def storage_pools(self) -> List[Dict[str, str]]:
        return self.config["storage_pools"]

    @property
    @lru_cache()
    def pod_count(self) -> int:
        return self.config.get("replicas", len(self.computes))


class MinioConfig(Config):
    schema = MinioSchema

    def __init__(self, config_path):
        self.config = {"concurrent_clusters": 1}
        self.config["s3bench_config"] = S3_BENCH_DEFAULTS
        self.config["bench_minio"] = BENCH_MINIO_DEFAULTS
        super().__init__(config_path)
        del self.config["fio_params"]
        del self.config["fio_image"]

    def validate_config(self):
        super().validate_config()
        if len(self.s3bench_nodes) > 1:
            duplicates = get_duplicates(self.s3bench_nodes)
            if duplicates:
                raise ConfigError("Duplicates inside s3bench_nodes: " + str(duplicates))
        if len(self.bench_minio_nodes) > 1:
            duplicates = get_duplicates(self.bench_minio_nodes)
            if duplicates:
                raise ConfigError(
                    "Duplicates inside bench_minio_nodes: " + str(duplicates)
                )

    @property
    @lru_cache()
    def pod_count(self) -> int:
        return self.concurrent_clusters * self.s3bench_replicas

    @property
    def concurrent_clusters(self) -> int:
        return self.config.get("concurrent_clusters", 1)

    @property
    def bench_minio_config(self) -> str:
        return self.config.get("bench_minio", BENCH_MINIO_DEFAULTS)

    @property
    def bench_minio_name(self) -> str:
        return self.bench_minio_config.get("name", "pframe-bench-minio")

    @property
    def bench_minio_replicas(self) -> int:
        return self.bench_minio_config.get("replicas", 12)

    @property
    def bench_minio_accesskey(self) -> str:
        return self.bench_minio_config.get("bench_minio_accesskey", "pframeaccess")

    @property
    def bench_minio_secretkey(self) -> str:
        return self.bench_minio_config.get("bench_minio_secretkey", "pframesecret")

    @property
    def bench_minio_secret(self) -> str:
        return self.bench_minio_config.get("bench_minio_secret", "pframe-bench-minio")

    @property
    def bench_minio_resources(self) -> Dict[str, str]:
        return self.bench_minio_config.get("bench_minio_resources", {})

    @property
    def bench_minio_scheduler(self) -> Union[None, str]:
        return self.bench_minio_config.get("scheduler", None)

    @property
    def bench_minio_version(self) -> str:
        return self.bench_minio_config.get("bench_minio_version", "")

    @property
    def bench_minio_nodes(self) -> List[str]:
        return self.bench_minio_config.get("bench_minio_nodes", [])

    @property
    def bench_minio_storage_class_name(self) -> str:
        return self.bench_minio_config.get(
            "bench_minio_storage_class_name", "linstor-dmpbalancer"
        )

    @property
    def bench_minio_storage_class(self) -> str:
        return self.bench_minio_config.get(
            "bench_minio_storage_class", "linstor-dmpbalancer"
        )

    @property
    def bench_minio_disk_size(self) -> str:
        return self.bench_minio_config.get("bench_minio_disk_size", "10G")

    @property
    def s3bench_config(self) -> str:
        return self.config.get("s3bench_config", S3_BENCH_DEFAULTS)

    @property
    def s3bench_image(self) -> str:
        return self.s3bench_config.get("s3bench_image", "")

    @property
    def s3bench_nodes(self) -> List[str]:
        return self.s3bench_config.get("s3bench_nodes", [])

    @property
    def s3bench_replicas(self) -> int:
        return self.s3bench_config.get("s3bench_replicas", len(self.s3bench_nodes))

    @property
    def s3bench_bucket(self) -> str:
        return self.s3bench_config.get("s3bench_bucket", "pframe")

    @property
    def s3bench_thread_num(self) -> int:
        return self.s3bench_config.get("s3bench_thread_num", 1)

    @property
    def s3bench_obj_size(self) -> str:
        return self.s3bench_config.get("s3bench_obj_size", "1M")

    @property
    def s3bench_duration(self) -> int:
        return self.s3bench_config.get("s3bench_duration", 10)

    @property
    def s3bench_minio_accesskey(self) -> str:
        return self.s3bench_config.get("s3bench_minio_accesskey", "pframeaccess")

    @property
    def s3bench_minio_secretkey(self) -> str:
        return self.s3bench_config.get("s3bench_minio_secretkey", "pframesecret")


class LocalConfig(Config):
    schema = FioSchema

    @property
    def computes(self) -> List[str]:
        return self.config.get("computes", [])

    @property
    def storage_pools(self) -> List[Dict[str, str]]:
        return self.config["storage_pools"]

    @property
    def pmem(self) -> bool:
        return self.config.get("pmem")

    @property
    @lru_cache()
    def pod_count(self) -> int:
        spls = self.storage_pools
        replicas = 0
        for sp in spls:
            replicas += sp.get("replicas", 1)

        return replicas


class MultiDriveSingleComputeConfig(Config):
    schema = FioSchema

    @property
    def computes(self) -> List[str]:
        return self.config.get("computes", [])

    @property
    def storage_pools(self) -> List[Dict[str, str]]:
        return self.config["storage_pools"]

    @property
    @lru_cache()
    def pod_count(self) -> int:
        spls = self.storage_pools
        replicas = 0
        for sp in spls:
            replicas += sp.get("replicas", 1)

        return replicas
