import os

from setuptools import setup, find_packages

project_root = os.path.dirname(__file__)

with open(os.path.join(project_root, "requirements.txt")) as requirements:
    install_requires = requirements.read().split()

setup(
    name="pframe",
    version="0.1.0",
    author="Intel",
    description="Performance Framework Tool",
    scripts=["pft"],
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=install_requires,
)
