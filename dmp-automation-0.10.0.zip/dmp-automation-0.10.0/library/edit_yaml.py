#!/usr/bin/python

# Intel OBL Pre-Release Software (Internal Use)
# Copyright (c) 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


ANSIBLE_METADATA = {
    "metadata_version": "0.1",
    "status": ["preview"],
    "supported_by": "community",
}

DOCUMENTATION = """
---
module: edit_yaml

short_description: Edit yaml file

version_added: "2.4"

description:
    - "This module is responsible for editing yaml files"

options:
    path:
        description:
            - Path to yaml file
        required: False
        type: str
    content:
        description:
            - Content to modify provided in yaml syntax
        required: False
        type: str
    key:
        description:
            - "Key which should be edited. Each nested key is separate from previous one by '.' (e.g.: key.nestedkey.0)."
        required: True
        type: str
    value:
        description:
            - Value to set
        required: True
        type: str
    is_json:
        description:
            - Is value in json format. If yes, value will be unmarshalled first and then mount under specified key.
        required: False
        type: bool
        default: False
    backup_localization:
        description:
            - If is specified, backup file will be created under selected localization. If is empty then won't create any backup file.
        required: False
        type: str
        default: ''
    list_append:
        description:
            - If yes, then append a list under key. If no, replace list with a value.
        required: False
        type: bool
        default: False

author:
    - Michal Stachowski (@squall0gd)
"""

EXAMPLES = """
# change value under selected key.
- name: Change mtu value for kubelet
  edit_yaml:
    path: "/etc/origin/node/node-config.yaml"
    key: "networkConfig.mtu"
    value: 9000

# mount dict under key
- name: Present how dict mounting is working
  edit_yaml:
    path: "/etc/origin/node/node-config.yaml"
    key: "networkConfig.mtu"
    value: "{\"key\": \"value\"}"
    is_json: True

# append item to existing list
- name: Enable additional feature gate in kubelet
  edit_yaml:
    path: "/etc/origin/node/node-config.yaml"
    key: "kubeletArguments.feature-gates"
    value: "PersistentLocalVolumes=true"
    list_append: True
"""

RETURN = """
backup_path:
    description: backup file localization
    type: str
msg:
    description: error message
    type: str
"""

from ansible.module_utils.basic import AnsibleModule
import yaml
import json


def setup_value(content, key_path, value, append_list=False):
    if len(key_path) > 1:
        if type(content[key_path[0]]) is list:
            key_path[1] = int(key_path[1])
        setup_value(content[key_path[0]], key_path[1:], value, append_list)

    else:
        if append_list:
            content[key_path[0]].append(value)
            unique_names_list = []

            for dict in content[key_path[0]]:
                if dict["name"] not in unique_names_list:
                    unique_names_list.append(dict["name"])
                else:
                    content[key_path[0]].remove(dict)
        else:
            content[key_path[0]] = value


def state_present(key_path, params, content):
    if params["is_json"]:
        value = json.loads(params["value"])

    else:
        value = params["value"]

    setup_value(content, key_path, value, append_list=params["list_append"])
    return content


def create_backup(path, fd):
    fd.seek(0)
    backup_fd = open(path, mode="w")
    backup_fd.writelines(fd.readlines())
    backup_fd.close()
    return path


def run_module():
    module_args = dict(
        path=dict(type="str", required=False, default=""),
        content=dict(type="str", required=False, default=""),
        key=dict(type="str", required=True),
        value=dict(type="str", required=True),
        is_json=dict(type="bool", required=False, default=False),
        backup_localization=dict(type="str", required=False, default=""),
        list_append=dict(type="bool", required=False, default=False),
    )

    result = dict(changed=True, backup_path="", msg="")

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    if module.check_mode:
        return result

    try:
        if module.params["path"] != "":
            with open(module.params["path"]) as fd:
                content = yaml.load(fd)
        elif module.params["content"] != "":
            content = yaml.load(module.params["content"])

        if module.params["backup_localization"] != "":
            result["backup_path"] = create_backup(
                module.params["backup_localization"], fd
            )

    except Exception as e:
        result["msg"] = str(e)
        module.fail_json(**result)

    key_path = module.params["key"].split(".")

    try:
        content = state_present(key_path, module.params, content)
        result["changed_content"] = content
    except Exception as e:
        result["msg"] = str(e)
        module.fail_json(**result)

    if module.params["path"] != "":
        with open(module.params["path"], "w") as fd:
            yaml.dump(content, fd, default_flow_style=False)

    module.exit_json(**result)


def main():
    run_module()


if __name__ == "__main__":
    main()
