# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import os
import sys
import unittest

from ansible.errors import AnsibleFilterError

testdir = os.path.dirname(__file__)
srcdir = '../filters'
sys.path.insert(0, os.path.abspath(os.path.join(testdir, srcdir)))

import filters


class TestFilter(unittest.TestCase):

    def test_are_numbers_unique_pass(self):
        self.assertTrue(filters._is_unique([1, 2]))

    def test_are_numbers_unique_fail(self):
        numbers = [1, 2, 1, 3, 4, 5, 5]
        self.assertFalse(filters._is_unique(numbers))

    def test_validate_partition_schemas(self):
        schemas = {'default': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                                'number': 1, 'name': 'casandra'},
                               {'start': '25%', 'label': 'gpt', 'end': '100%',
                                'number': 2, 'name': 'minio'}],
                   'kaczka': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                               'number': 1, 'name': 'casandra'}]}

        self.assertListEqual(['default', 'kaczka'],
                             filters._validate_partition_schemas(schemas))

    def test_validate_partition_schemas_start_greater_than_end(self):
        schemas = {'default': [{'start': '75%', 'label': 'gpt', 'end': '25%',
                                'number': 1, 'name': 'casandra'},
                               {'start': '25%', 'label': 'gpt', 'end': '100%',
                                'number': 2, 'name': 'minio'}],
                   'kaczka': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                               'number': 1, 'name': 'casandra'}]}

        with self.assertRaises(AnsibleFilterError):
            filters._validate_partition_schemas(schemas)

    def test_validate_partition_schemas_not_gpt(self):
        schemas = {'default': [{'start': '0%', 'label': 'msdos', 'end': '25%',
                                'number': 1, 'name': 'casandra'},
                               {'start': '25%', 'label': 'gpt', 'end': '100%',
                                'number': 2, 'name': 'minio'}],
                   'kaczka': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                               'number': 1, 'name': 'casandra'}]}

        with self.assertRaises(AnsibleFilterError):
            filters._validate_partition_schemas(schemas)

    def test_validate_devices(self):
        partition_schema_names = ['default', 'kaczka']
        devices = [{'disk': 'nvme0n1', 'part': 'default'},
                   {'disk': 'nvme0n2', 'part': 'kaczka'},
                   {'disk': 'nvme0n3', 'part': 'kaczka'},
                   {'disk': 'nvme0n4', 'part': 'default'},
                   {'disk': 'sdb'}]

        filters._validate_devices(devices, partition_schema_names)

    def test_validate_devices_fails(self):
        partition_schema_names = ['default', 'kaczka']
        devices = [{'disk': 'nvme0n1', 'part': 'default'},
                   {'disk': 'nvme0n2', 'part': 'kaczka'},
                   {'disk': 'nvme0n3', 'part': 'nie_ma'},
                   {'disk': 'nvme0n4', 'part': 'default'},
                   {'disk': 'sdb'}]

        with self.assertRaises(AnsibleFilterError):
            filters._validate_devices(devices, partition_schema_names)

    def test_is_range_overlapping(self):
        ranges = [(25, 100), (0, 25)]
        self.assertFalse(filters._is_range_overlaping(ranges))

    def test_is_range_overlapping_fail(self):
        ranges = [(20, 100), (0, 25)]
        self.assertTrue(filters._is_range_overlaping(ranges))

    def test_is_range_overlapping_throws(self):
        ranges = [(20, 120), (0, 25)]
        with self.assertRaises(AnsibleFilterError):
            filters._is_range_overlaping(ranges)

    def test_validate_partition_sizes(self):
        start = "20%"
        end = "100%"

        expected_output = (20, 100)
        self.assertEqual(expected_output,
                         filters._validate_partition_sizes(start, end))

    def test_validate_lvm(self):
        lvm = {'vgs': [{'pvs': '/dev/sdb', 'linstor': False, 'name': 'extras',
                        'lvs': [{'mountpoint': '/docker', 'name': 'docker',
                                 'size': '100', 'fstype': 'xfs', 'opts': '-cc'},
                                {'mountpoint': '/other', 'name': 'other',
                                 'size': '20'}]},
                       {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2', 'linstor': True, 'if': 'enp108s0',
                        'name': 'kaczka1'}]}

        partitioned_devices = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                               'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2', 'sdb']
        filters._validate_lvm(lvm, partitioned_devices)

    def test_validate_lvm_fails_pv_doesnt_exists(self):
        lvm = {'vgs': [{'pvs': '/dev/sdb1', 'linstor': False, 'name': 'extras',
                        'lvs': [{'mountpoint': '/docker', 'name': 'docker',
                                 'size': '100', 'fstype': 'xfs'},
                                {'mountpoint': '/other', 'name': 'other',
                                 'size': '20'}]},
                       {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2', 'linstor': True, 'if': 'enp108s0',
                        'name': 'kaczka1'}]}

        partitioned_devices = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                               'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2', 'sdb']

        with self.assertRaises(AnsibleFilterError):
            filters._validate_lvm(lvm, partitioned_devices)

    def test_validate_lvm_fails_linstor_not_bool(self):
        lvm = {'vgs': [{'pvs': '/dev/sdb1', 'linstor': 1, 'name': 'extras',
                        'lvs': [{'mountpoint': '/docker', 'name': 'docker',
                                 'size': '100'},
                                {'mountpoint': '/other', 'name': 'other',
                                 'size': '20'}]},
                       {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2', 'linstor': True, 'if': 'enp108s0',
                        'name': 'kaczka1'}]}

        partitioned_devices = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                               'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2', 'sdb']

        with self.assertRaises(AnsibleFilterError):
            filters._validate_lvm(lvm, partitioned_devices)

    def test_validate_lvm_fails_linstor_true_with_lv_section(self):
        lvm = {'vgs': [{'pvs': '/dev/sdb1', 'linstor': True, 'name': 'extras',
                        'lvs': [{'mountpoint': '/docker', 'name': 'docker',
                                 'size': '100'},
                                {'mountpoint': '/other', 'name': 'other',
                                 'size': '20'}]},
                       {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2', 'linstor': True, 'if': 'enp108s0',
                        'name': 'kaczka1'}]}

        partitioned_devices = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                               'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2', 'sdb']

        with self.assertRaises(AnsibleFilterError):
            filters._validate_lvm(lvm, partitioned_devices)

    def test_get_partitioned_devices(self):
        schemas = {'default': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                                'number': 1, 'name': 'casandra'},
                               {'start': '25%', 'label': 'gpt', 'end': '100%',
                                'number': 2, 'name': 'minio'}],
                   'kaczka': [{'start': '0%', 'label': 'gpt', 'end': '25%',
                               'number': 1, 'name': 'casandra'}]}
        devices = [{'disk': 'nvme0n1', 'part': 'default'},
                   {'disk': 'nvme0n2', 'part': 'kaczka'},
                   {'disk': 'nvme0n3', 'part': 'kaczka'},
                   {'disk': 'nvme0n4', 'part': 'default'},
                   {'disk': 'sdb'}]

        expected_output = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                           'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2',
                           'sdb']

        self.assertListEqual(expected_output,
                             filters._get_partitioned_devices(devices,
                                                              schemas))

    def test_get_partitioned_devices_empty_schemas(self):
        schemas = {}
        devices = [{'disk': 'nvme0n1'}, {'disk': 'nvme0n2'},
                   {'disk': 'nvme0n3'}, {'disk': 'nvme0n4'}, {'disk': 'sdb'}]

        expected_output = ['nvme0n1', 'nvme0n2', 'nvme0n3', 'nvme0n4', 'sdb']

        self.assertListEqual(expected_output,
                             filters._get_partitioned_devices(devices,
                                                              schemas))

    def test_validate_lvm_fails_linstor_true_without_interface_name_set(self):
        lvm = {'vgs': [{'pvs': '/dev/sdb', 'linstor': False, 'name': 'extras',
                        'lvs': [{'mountpoint': '/docker', 'name': 'docker',
                                 'size': '100'},
                                {'mountpoint': '/other', 'name': 'other',
                                 'size': '20'}]},
                       {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2', 'linstor': True,
                        'name': 'kaczka1'}]}

        partitioned_devices = ['nvme0n1p1', 'nvme0n1p2', 'nvme0n2p1',
                               'nvme0n3p1', 'nvme0n4p1', 'nvme0n4p2', 'sdb']

        with self.assertRaises(AnsibleFilterError):
            filters._validate_lvm(lvm, partitioned_devices)

    def test_validate_lv_size(self):
        size = '100'
        filters._validate_lv_size(size)

    def test_validate_lv_size_gb(self):
        size = '100g'
        filters._validate_lv_size(size)

    def test_validate_lv_size_free(self):
        size = '100%FREE'
        filters._validate_lv_size(size)

    def test_validate_lv_size_vg(self):
        size = '10%VG'
        filters._validate_lv_size(size)

    def test_validate_lv_size_pv(self):
        size = '18%PVS'
        filters._validate_lv_size(size)

    def test_validate_lv_size_fails_more_than_100(self):
        size = '120%PVS'
        with self.assertRaises(AnsibleFilterError):
            filters._validate_lv_size(size)

    def test_validate_lv_size_fails_wrong_size(self):
        size = 'fa120%PVS'
        with self.assertRaises(AnsibleFilterError):
            filters._validate_lv_size(size)

    def test_validate_lv_size_fails_wrong_size_2(self):
        size = 'ads500g'
        with self.assertRaises(AnsibleFilterError):
            filters._validate_lv_size(size)

    def test_validate_fstype_fails_wrong_type(self):
        fstype = 'fst4'
        with self.assertRaises(AnsibleFilterError):
            filters._validate_fstype(fstype)

    def test_validate_fstype_fails_empty_type(self):
        fstype = ''
        with self.assertRaises(AnsibleFilterError):
            filters._validate_fstype(fstype)

    def test_is_storage_info_invalid(self):
        storage_info = {'lvm': {'vgs': [{'pvs': '/dev/sdb', 'linstor': False,
                                         'name': 'extras',
                                         'lvs': [{'mountpoint': '/docker',
                                                  'name': 'docker', 'size':
                                                  '100', 'fstype': 'xfs', 'opts': '-cc'},
                                                 {'mountpoint': '/other',
                                                  'name': 'other', 'size':
                                                  '20'}]},
                                        {'pvs': '/dev/nvme0n2p1,/dev/nvme0n4p2',
                                         'linstor': True, 'if': 'enp108s0', 'name':
                                         'kaczka1'}]},
                        'linstor_role': 'Combined',
                        'part': {'default': [{'start': '0%', 'label': 'gpt',
                                              'end': '25%', 'number': 1,
                                              'name': 'casandra'},
                                             {'start': '25%', 'label': 'gpt',
                                              'end': '100%', 'number': 2,
                                              'name': 'minio'}],
                                 'kaczka': [{'start': '0%', 'label': 'gpt',
                                             'end': '25%', 'number': 1,
                                             'name': 'casandra'}]},
                        'devices': [{'disk': 'nvme0n1', 'part': 'default'},
                                    {'disk': 'nvme0n2', 'part': 'kaczka'},
                                    {'disk': 'nvme0n3', 'part': 'kaczka'},
                                    {'disk': 'nvme0n4', 'part': 'default'},
                                    {'disk': 'sdb'}]}

        self.assertFalse(filters.is_storage_info_invalid(storage_info))


if __name__ == "__main__":
    unittest.main()
