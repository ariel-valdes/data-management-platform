# Intel OBL Pre-Release Software (Internal Use)
# Copyright (c) 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import re

from ansible.errors import AnsibleFilterError

REQUIRED_STORAGE_INFO_FIELDS = ['devices', 'lvm']


def is_empty_string(var):
    if var == '':
        raise AnsibleFilterError("{} var is empty string".format(var))

    return False


def _is_unique(numbers):
    return len(numbers) == len(set(numbers))


def _is_range_overlaping(ranges):
    sorted_range = sorted(ranges)
    end_of_range = 0
    for span in sorted_range:
        if span[1] > 100:
            raise AnsibleFilterError('End of part size cannot be greater than'
                                     ' 100%')
        if span[0] < end_of_range:
            return True
        end_of_range = span[1]

    return False


def _validate_partition_sizes(start, end):
    start_size = end_size = None
    re_start = re.match("(\d+)\%", start)
    if re_start:
        start_size = re_start.groups()[0]

    re_end = re.match("(\d+)\%", end)
    if re_end:
        end_size = re_end.groups()[0]

    if not start_size:
        raise AnsibleFilterError('Min_size is not in format VALUE%')

    if not end_size:
        raise AnsibleFilterError('Max_size is not in format VALUE%')

    return int(start_size), int(end_size)


def _validate_partition_schemas(schemas):
    """Validate partition schemas

    Returns: list of schema names
    """
    for partition_schema in schemas:
        # create list to store numbers for partitions
        ranges = []
        number_list = []
        for partition in schemas[partition_schema]:
            # check if label is gpt
            if partition['label'] != 'gpt':
                raise AnsibleFilterError('Partition {} label is {} but should'
                                         ' be gpt'.format(partition,
                                                          partition['label']))

            # populate number_list with partition number
            number_list.append(partition['number'])
            # retrieve start and end size
            start = partition['start']
            end = partition['end']
            # validate if sizes are in format DIGIT%
            start_size, end_size = _validate_partition_sizes(start, end)
            if start_size >= end_size:
                raise AnsibleFilterError('Start size is greater or equal end'
                                         ' size')

            # append ranges to check overlapping later
            ranges.append((start_size, end_size))

        # validate if all numbers are unique
        if not _is_unique(number_list):
            raise AnsibleFilterError('Numbers in Part: {} are not'
                                     ' unique'.format(partition_schema))

        # check overlapping of ranges for given schema
        if _is_range_overlaping(ranges):
            raise AnsibleFilterError('Ranges are overlapping in part'
                                     ' {}'.format(partition_schema))

    return schemas.keys()


def _validate_devices(devices, partition_schema_names):
    """ Validate devices

    Returns: list of device names
    """
    for device in devices:
        # validate whether desired part is specified in schema
        if device.get('part') and not device['part'] in partition_schema_names:
            raise AnsibleFilterError('Partition schema {} is not'
                                     ' defined'.format(device['part']))


def _get_partitioned_devices(devices, partition_schemas):
    """ Get partitioned devices

    Returns: list of parted devices
    """
    partitioned_devices = []
    for device in devices:
        if not device.get('part'):
            partitioned_devices.append(device['disk'])
            continue

        partition_schema = device['part']
        partition_number = len(partition_schemas[partition_schema])
        disk_name = device['disk']
        disk_prefix = disk_name
        if device['disk'][:4] == 'nvme':
            disk_prefix = disk_name + 'p'

        for partition in range(1, partition_number + 1):
            partitioned_devices.append(disk_prefix + str(partition))

    return partitioned_devices


def _validate_lvm(lvm, partitioned_devices):
    for vg in lvm['vgs']:
        for pv in vg['pvs'].split(','):
            if re.sub(r'/dev/', "", pv) not in partitioned_devices:
                raise AnsibleFilterError('PV {} in VG {} doesnt'
                                         ' exist'.format(re.sub(r'/dev/', "", pv), vg['name']))

        linstor = vg['linstor']
        if not isinstance(linstor, bool):
            raise AnsibleFilterError("Field linstor in VG {} is not a"
                                     " boolean".format(vg['name']))

        if not linstor and 'lvs' in vg:
            names = []
            for lv in vg['lvs']:
                names.append(lv['name'])
                _validate_lv_size(lv['size'])
                # User can set filesystem type or can omit this
                # variable
                if lv.get('fstype') is not None:
                    _validate_fstype(lv['fstype'])

            if not _is_unique(names):
                raise AnsibleFilterError('LV names in VG {} are not'
                                         ' unique'.format(vg['name']))

        if linstor:
            if vg.get('lvs'):
                raise AnsibleFilterError('If linstor is set to True lvs'
                                         ' section is forbidden')


def _validate_lv_size(size):
    validated_size = 0
    re_size = re.match('^(\d+)[bBsSkKmMgGtTpPeE]?$', size)
    re_percent = re.match('^(\d+)\%(FREE|PVS|VG)$', size)
    if re_percent:
        validated_size = int(re_percent.groups()[0])
        if validated_size > 100:
            raise AnsibleFilterError('Size: {} in percent cannot be greater'
                                     ' than 100'.format(size))

    if not (re_percent or re_size):
        raise AnsibleFilterError('Size {} is not valid'.format(size))


def _validate_fstype(fstype):
    valid_fstype_values = ['ext2', 'ext3', 'ext4', 'xfs', 'btrfs', 'lvm']
    if fstype not in valid_fstype_values:
        raise AnsibleFilterError('Filesystem type {} is not valid'.
                                 format(fstype))


def is_storage_info_invalid(storage_info):
    # check required field
    for field in REQUIRED_STORAGE_INFO_FIELDS:
        if not storage_info.get(field):
            raise AnsibleFilterError("{} field is missing".format(field))

    # retrieve partition names
    partition_schemas = storage_info.get('part')
    partition_schema_names = []
    if partition_schemas:
        partition_schema_names = _validate_partition_schemas(partition_schemas)

    _validate_devices(storage_info['devices'], partition_schema_names)

    partitioned_devices = _get_partitioned_devices(storage_info['devices'],
                                                   storage_info.get('part',
                                                                    []))
    _validate_lvm(storage_info['lvm'], partitioned_devices)

    return False


class FilterModule(object):
    def filters(self):
        return {
            'is_empty_string': is_empty_string,
            'is_storage_info_invalid': is_storage_info_invalid,
        }
