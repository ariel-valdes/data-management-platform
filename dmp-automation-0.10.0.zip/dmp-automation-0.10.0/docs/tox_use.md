------------

### Using Tox:

#### What is Tox?
Tox (http://tox.testrun.org/) is a tool for running tests in multiple virtualenvs.

#### How to use Tox?
To use it:
```bash
pip install tox
```
and then run one of the options from **"Ready checks to run"** section.


**Ready checks to run:**

1. To **YAML** syntax and **flake8** for Python PEP8 style checks run:
```bash
tox
```
2. To check the **unused** Ansible **defaults** variables run:
```bash
tox -e dvars
```
3. To check the **useless** or **empty** Ansible **group_vars** variables run:
```bash
tox -e gvars
```
4. To run **ansible-lint** for checks Ansible playbooks for practices and behaviour that could potentially be improved run:
```bash
tox -e ansible-lint
```

**NOTE:**

All of the above commands to run checks should be running from directory which contains the tox.ini file configuration.

**HELPFUL LINKS**
- [Official Tox Documentation](https://tox.readthedocs.io/en/latest/ "Official Tox Documentation")
- [ansible-lint project](https://github.com/willthames/ansible-lint)


------------
