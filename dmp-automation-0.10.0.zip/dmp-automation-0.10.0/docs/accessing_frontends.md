Accessing cluster front-ends
===
Information below is meant to guide admin in accessing front-end dashboards on OCP cluster.

# Front-end reachability from utility
To reach front-end from utility:
- ensure pod with front-end is running and can be reached with its service
- expose that service with route.

# Windows setup
## Putty configuration
Configure dynamic ssh tunnel to utility. In Putty tunnel specific options are under *Connection/SSH/Tunnels*. Example instructions can be found [here](https://blog.devolutions.net/2017/4/how-to-configure-an-ssh-tunnel-on-putty).

## Firefox setup
Those steps was done on 63.0 version of firefox.
1. Open up settings and go to *Network Settings* section.
1. Click *Settings..* to get iframe with network configuration.
1. Select *Manual proxy configuration* radial button.
1. In SOCKS Host type `127.0.0.1` and port of tunnel configured in prerequisite step.
1. Type `localhost, 127.0.0.1` in *No Proxy for* textfield.
1. Select *Proxy DNS when using SOCKS v5* checkbox. You can also set this with *network.proxy.sock_remote_dns* preference in firefox's *about:config*.
1. Disabling firefox proxy can be easily done by changing radial button in network settings.

# Linux setup
## Tunnel to utility with ssh-shuttle
Sshuttle redirects network traffic through desired host with ssh. Get it from [here](https://github.com/sshuttle/sshuttle).
Make sure you can reach desired cluster and have access.
## Example command:
```sshuttle -r utility_node 10.0.0.0/10 --dns```
- ```-r utility_node``` - remote hostname (here alias configured in *.ssh/config* file) to use for connecting to the remote server. From manual it is expressed as standard: ``[username@]sshserver[:port]```.
- ```10.0.0.0/10``` - subnet to which sshuttle will redirect traffic.
- ```--dns``` - flag that will enable DNS requests to be also redirected through desired remote host.
