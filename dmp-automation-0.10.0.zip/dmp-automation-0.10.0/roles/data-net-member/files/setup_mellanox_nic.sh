#!/bin/bash

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


function check_ib_name {
    ls /sys/class/net/$1/device/infiniband
}

function configure_nic {
    mlnx_qos -i ${NIC} --trust dscp
    mlnx_qos -i ${NIC} -s ets,ets,ets,ets,ets,ets,ets,ets -t 30,0,0,70,0,0,0,0
    IB=$(check_ib_name ${NIC})
    cma_roce_tos -d ${IB} -t 104
}

function check_is_mlnx {
    V_ID=$(cat /sys/class/net/${NIC}/device/vendor)
    # 0x15b3 is Mellanox vendor ID
    if [ "$V_ID" != "0x15b3" ]; then
        echo "Not a Mellanox NIC"
        exit 1
    fi
}

function check_is_binary_present {
    if [ ! -x "$(which $1 2> /dev/null)" ]; then
        echo "Binary $1 is not present. Install OFED first"
        echo "Exit with 0, to not interrupt NIC setup if OFED is not installed yet"
        exit 0
    fi
}

check_is_binary_present mlnx_qos
check_is_binary_present cma_roce_tos

if [ "$1" == "" ]; then
    echo "Pass NIC parameter"
    echo "Exit with 0, to not interrupt NIC setup"
    exit 0
fi

NIC=${1}

check_is_mlnx
configure_nic
