data-net-member
===

Overview
~~~~~~~~
This role is responsible for configuration of data network on nodes



Actions
~~~~~~~

:Deploy:
  - Copy data inferface ifcfg file, up interface
  
:Purge:
  - Remove data interface file, down interface
