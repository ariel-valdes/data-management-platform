LinBit core deployment scripts
==============================

Role to deploy LinBit core components.

Description
-----------
This script will do the node registration to linbit account license, create
**/opt/intel/linbit** directory, where linbit scripts will be downloaded
and install linstor CLI packages.

Requirements
------------
LinBit installation requies to have active license. When deploying this role,
please provide your username, password, contract id and cluster id to
successfully install packages, the variables:
* **linstor_user** - username to http://my.linbit.com portal
* **linstor_password** - password to http://my.linbit.com portal
* **linstor_contract_id** - contract ID from http://my.linbit.com portal
* **linstor_cluster_id** - http://my.linbit.com portal cluster ID

Usage
-----

Example playbook
```
- name: Install Linstor CLI
  hosts: linstor_cli_hosts
  become: yes
  gather_facts: False
  tasks:
  - name: Install Linstor Client
    import_role:
      name: linstor-client
```

Purging
-------
When LinBit packages will be removed, we have to delete used license in
http://my.linbit.com portal. Please log into your account, and manually
delete registred node, if they would not be used anymore. It is important
to perform this manual step, since the license is sold for exact node number,
so when doing constantly deployment and purging on different nodes, the license
will go out of available pool.


Credits to: https://github.com/kermat/linbit-ansible
