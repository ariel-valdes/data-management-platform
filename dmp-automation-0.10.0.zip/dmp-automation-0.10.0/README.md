[![pipeline status](https://gitlab.devtools.intel.com/intelsds/daas-automation/badges/master/pipeline.svg)](https://gitlab.devtools.intel.com/intelsds/daas-automation/commits/master)

dmp automation
===============

This repository contains playbooks and roles used to deploy dmp solution.

Contains playbooks specific to daas solution.


### Prerequisites and requirements
 - Ansible - 2.4.3
 - Corectly prepared inventory
 - SSH key pair with private key added to SSH agent

### General details
- All playbooks are designed to be run from utility node.
- Please make sure you are using latest version

### How to run the playbooks:

Run Ansible directly.
```console
ansible-playbook -i <inventory> <playbooks/playbook name>
```
 *NOTE* - In any case, please run the playbooks from current directory for `ansible.cfg` to be loaded.


## Further Reading
 - [How to use tox][tox]
 - [Accessing front-ends][accessing_frontends]

[tox]: docs/tox_use.md
[accessing_frontends]: docs/accessing_frontends.md
