#!/bin/bash

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


set -e

. "$(dirname "$0")"/.usage.sh

function usage()
{
    cat <<EOF
Usage: $0 [options]

  -h|--help         Prints this help.
  -a|--all          Force reencrypting all files - useful when PGP keys were modified.
EOF
}

function parse_args()
{
    ENCRYPT_ALL=false

    while [[ $# -gt 0 ]] ; do
        key="$1"

        case "$key" in
            -h|--help)
                usage
                exit
                ;;
            -a|--all)
                ENCRYPT_ALL=true
                ;;
            *)
                echo "Unknown argument $key exiting..."
                echo ""
                usage
                exit
                ;;
        esac
        shift
    done
}

# Get input arguments
parse_args $*

if [ ! -d "$DECRYPTED_DIR" ] ; then
    echo "Nothing to encrypt, exiting..."
    exit
fi

# First, check if there are any files deleted in the decrypted folder.
# Compare decrypted folder and encrypted folder since for every file there
# should be a matching .gpg encrypted file or a matching folder.
for encrypted_file in $(find $ENCRYPTED_DIR/) ; do
    file_encr_subpath=${encrypted_file#$ENCRYPTED_DIR/}
    if [ -f $encrypted_file ] ; then
        file_decr_subpath=${file_encr_subpath%.gpg}
    elif [ -d $encrypted_file ] ; then
        file_decr_subpath=${file_encr_subpath}
    fi

    if [ ! -e $DECRYPTED_DIR/${file_decr_subpath} ] ; then
        LIST_OF_FILES_TO_DELETE="$LIST_OF_FILES_TO_DELETE $file_encr_subpath"
    fi
done

LIST_OF_FILES_TO_ENCRYPT=

if [ "$ENCRYPT_ALL" == false ] ; then
    # By default, only encrypt files which are modified or added in decrypted folder

    # Delete previous temporary directory for decrypted files
    if [ -d "$DECRYPTED_TMP_DIR" ] ; then
        rm -rf  $DECRYPTED_TMP_DIR
    fi

    echo "Decrypting files to a temporary location for comparison..."
    ./decrypt.sh --target-dir "$DECRYPTED_TMP_DIR"

    # Get relative paths for all modified/new files and directories
    LIST_OF_FILES_TO_ENCRYPT=$(rsync -rcn --out-format="%n" $DECRYPTED_DIR/ $DECRYPTED_TMP_DIR/ | sort)

    # We no longer need the folder
    rm -rf $DECRYPTED_TMP_DIR
else
    # If requested then we can encrypt all files
    for decrypted_file in $(find $DECRYPTED_DIR -type f) ; do
        file_subpath=${decrypted_file#$DECRYPTED_DIR/}
        LIST_OF_FILES_TO_ENCRYPT="$LIST_OF_FILES_TO_ENCRYPT $file_subpath"
    done
fi

if [ -n "$LIST_OF_FILES_TO_DELETE" ] ; then
    echo Files to delete:
    for file_to_delete in $LIST_OF_FILES_TO_DELETE ; do
        echo "* $file_to_delete"
    done

    echo "Removing deleted files, please wait..."

    for file_to_delete in $LIST_OF_FILES_TO_DELETE ; do
        encrypted_file=${ENCRYPTED_DIR}/${file_to_delete}
        rm -rf $encrypted_file
    done

    echo "Successfully removed deleted files!"
else
    echo "No files to delete, skipping..."
fi

if [ -n "$LIST_OF_FILES_TO_ENCRYPT" ] ; then
    echo Files to encrypt:
    for file_to_encrypt in $LIST_OF_FILES_TO_ENCRYPT ; do
        echo "* $file_to_encrypt"
    done

    recipients_param=""

    echo "Owners of the following email addresses will be able to decrypt:"
    for email in $EMAILS ; do
        echo "* $email"
        recipients_param="$recipients_param --recipient $email"
    done

    tmp_keyring_dir=$(mktemp -d)

    echo "Importing public keys to a temporary local keyring..."
    gpg2 --import --quiet --yes --homedir "$tmp_keyring_dir" "$PUBKEYS_DIR"/*.asc
    echo "Succesfully imported public keys!"

    echo "Encrypting files, please wait..."

    for file_to_encrypt in $LIST_OF_FILES_TO_ENCRYPT ; do
        decrypted_file=${DECRYPTED_DIR}/${file_to_encrypt}

        # If this is a directory then just create it and continue with next item
        if [ -d $decrypted_file ] ; then
            mkdir -p $ENCRYPTED_DIR/$file_to_encrypt
            continue
        fi

        # All encrypted files have .gpg suffix so construct the absolute path
        encrypted_file=${ENCRYPTED_DIR}/${file_to_encrypt}.gpg

        gpg2 --encrypt $recipients_param --output "$encrypted_file" --yes --trust-model always --homedir "$tmp_keyring_dir" "$decrypted_file"
    done

    echo "Successfully encrypted all files!"

    rm -rf $tmp_keyring_dir
else
    echo "No files to encrypt, skipping..."
fi

