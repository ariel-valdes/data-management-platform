Encryption helpers
==================
Those scripts can be used to encrypt/decrypt sensitive data in inventory

Required version:
```sh
gpg2 --version     
gpg (GnuPG) 2.2.0
libgcrypt 1.7.8
```

Overview
This folder contains encryption helpers which utilize public PGP keys to encrypt data. The helpers assume that a specific directory structure is present and that the path to such a folder is passed to them.

Getting access
--------------
In order to be able to decrypt files, you need to:
Generate pgp keys using gpg2. Remember to use a correct email address.
```sh  
gpg2 --full-gen-key

## Kind of key: RSA and RSA (default)
## RSA key size at least 2048
## Set key validity for 6 months
## Real name: your name and surname
## e-mail: your_email@intel.com
```
Export your public pgp key to a file.
```sh
gpg2 --export --armor your_email@intel.com > {name}-{surname}.asc
```
Make sure that the public key is valid - it should only contain one entry with your email address.
```sh
gpg2 {name}-{surname}.asc
```
Have someone reencrypt the files with your public PGP key already in the repository.
1. Create a new branch in dbaas-xyz repository.
2. Put the generated public pgp key in the repository (*dbaas-xyz/pub_keys/pgp_keys/*), commmit the changes and push the branch.
3. Ask a colleague who already has access to checkout your branch, then he/she will need to run the following:
```sh
   ./encrypt.sh --all
```
4. The colleague will need to commit the changes done to *encrypted* directory, then push the commit, create a PR and merge into master branch.

Decrypting data
---------------
You can decrypt all data in your working dir by using ``config_encr/decrypt.sh`` script:

```sh
./decrypt.sh
```

In order to prevent from changes being overwritten, the script will move your current ``decrypted`` directory to ``decrypted.old.xxxxx``.

There are other options available, for instance you can decrypt the files to another directory with ``--target-dir``:

```sh
./decrypt.sh --target-dir /home/user/decrypted_data
```

For a full list of options use:
```sh
./decrypt.sh --help
```

Encrypting data
---------------
Having decrypted the data, you can modify it. Before pushing the changes, you need to encrypt the file back. This is best done using ``config_encr/encrypt.sh``:

```sh
./encrypt.sh
```

By default, the script only encrypts modified files. If you want to reencrypt all files instead, use ``--all`` flag.

Manual encryption
---------------
This script takes the public keys into account but you can also use gpg2 and do it on your own - just make sure that all pubkeys are imported into your keyring and that all recipients are included:

```sh
gpg2 --quiet --import working_dir/pubkeys/*.asc

gpg2 --encrypt --output working_dir/encrypted/data.enc --recipient xxxxx.yyyyy@intel.com --recipient aaaa.bbbb@intel.com [...] data
```

VERY IMPORTANT - how to introduce changes in safe way
-----------------------------------------------------
Encrypted files due to their nature will generate conflicts in git when not handled properly. Plain text files are easy to auto-merge in case of simultaneous changes, binary files are not.
Here is a proper way to minimize changes for git conflicts and/or loosing data:

- check if there are any pull requests with encrypted files in them not merged yet. If so, contact author(s) and rest of the team to merge that ASAP
- before introducing any changes to encrypted files make sure that you have newest revision of master branch and fork your branch out of it
- decrypt all files
- introduce your changes
- encrypt files
- create PR and make sure it is merged as ASAP as possible ;)

In case when you run into conflict in encrypted files you need to resolve it manually - GitHub will not help you. There are few attempts to do it, one below is definitely not pro-style but fool-proof instead and works best for simple case when you have one commit on your branch that conflicts with master as other PR was merged in the meantime.

- close PR with comment that due to conflict another PR would be created
- follow all steps described above - introduce your changes once again on new branch that was forked from up-to-date master.

For more complicated cases ask team how to handle it. General rule of thumb is that loosing data is worse than some extra effort put into handling conflict.
