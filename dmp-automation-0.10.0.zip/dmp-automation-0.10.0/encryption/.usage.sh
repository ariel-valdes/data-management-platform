#!/bin/bash

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


# Check if executing on a Mac, if so use greadlink instead.
# greadlink is installed by: brew install coreutils

# This is unlikely to work if you have spaces in your directory path

if [ `uname` == "Darwin" ]; then
  export READLINK=greadlink
  echo "You are on a Mac, you must install homebrew and run brew install coreutils"
else
  export READLINK=readlink
fi

# Working dir contains 'encrypted' directory with encrypted data. It should also contain
# links to all gsa-core tools for encryption

WORKING_DIR="$($READLINK -m $(dirname "$0"))"

if [[ ! -d $WORKING_DIR || ! -d $WORKING_DIR/encrypted ]] ; then
    echo "Some of required files or folders are missing. For more info please read README.md."
    exit 1
fi

export WORKING_DIR
# Encrypted dir contains encrypted data
export ENCRYPTED_DIR=$WORKING_DIR/encrypted
# Decrypted dir will be the default directory where the files will be decrypted to
export DECRYPTED_DIR=$WORKING_DIR/decrypted
# Directory used to compare what's inside decrypted directory and the encrypted content
export DECRYPTED_TMP_DIR=$WORKING_DIR/decrypted.tmp
# Directory with all public PGP keys
export PUBKEYS_DIR=$WORKING_DIR/../pub_keys/pgp_keys
# List of all emails based on existing public PGP keys
export EMAILS=$(find $PUBKEYS_DIR -name "*.asc" -exec sh -c "gpg {} | head -n 1 | awk '{print \$NF}' | sed 's/[<>]//g'" \; | sort -u)
