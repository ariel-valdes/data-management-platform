#!/bin/bash

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


set -e

. "$(dirname "$0")"/.usage.sh

function version_gt() { test "$(printf '%s\n' "$@" | sort -V | head -n 1)" != "$1"; }

function usage()
{
    cat <<EOF
Usage: $0 [options]

  -h|--help         Prints this help.
  -p|--passphrase   Specify PGP passphrase to use during decryption.
  -t|--target-dir   Specify target directory to which the files will
                    be decrypted.
EOF
}

function parse_args()
{
    PASSPHRASE=
    TARGET_DIR=

    while [[ $# -gt 0 ]] ; do
        key="$1"

        case "$key" in
            -h|--help)
                usage
                exit
                ;;
            -p|--passphrase)
                shift
                if [ -z "$1" ] ; then
                    echo "Passphrase is missing, exiting..."
                    echo ""
                    usage
                    exit
                fi
                PASSPHRASE="$1"
                ;;
            -t|--target-dir)
                shift
                if [ -z "$1" ] ; then
                    echo "Target directory is missing, exiting..."
                    echo ""
                    usage
                    exit
                fi
                TARGET_DIR="$1"
                ;;
            *)
                echo "Unknown argument $key exiting..."
                echo ""
                usage
                exit
                ;;
        esac
        shift
    done
}

# Get input arguments
parse_args $*

# Check if encrypted folder is present and contains files
# Execute decrypt script only if the above condition is met

if test "$(ls -A "$ENCRYPTED_DIR")" ; then
    if [ -n "$TARGET_DIR" ] ; then
        TARGET_DECRYPTED_DIR="$TARGET_DIR"
    else
        TARGET_DECRYPTED_DIR="$DECRYPTED_DIR"
    fi

    if [ -n "$PASSPHRASE" ] ; then
        GPG_COMMAND="echo $PASSPHRASE | gpg2 --batch --passphrase-fd 0 --quiet --yes"

        # In case of GPG >= 2.1 we need to use an additional option
        GPG_VERSION=$(gpg2 --version | head -n1 | awk '{ print $3 }')
        if version_gt "$GPG_VERSION" "2.1.0" ; then
            GPG_COMMAND="$GPG_COMMAND --pinentry-mode loopback"
        fi
    else
        GPG_COMMAND="gpg2 --quiet --yes"
    fi

    if [[ -d "$TARGET_DECRYPTED_DIR" ]] ; then
        FOR_OLD_DECRYPTED_DIR=$(mktemp -d -t --dry-run -p $WORKING_DIR decrypted.old.XXXXXX)
        echo "Moving old decrypted dir $TARGET_DECRYPTED_DIR to $FOR_OLD_DECRYPTED_DIR"
        mv "$TARGET_DECRYPTED_DIR" "$FOR_OLD_DECRYPTED_DIR"
    fi

    # Copy recursively the contents of encrypted files to decrypted files
    cp -f -R "$ENCRYPTED_DIR" "$TARGET_DECRYPTED_DIR"

    echo "Decrypting files to $TARGET_DECRYPTED_DIR..."

    for file in $(find "$TARGET_DECRYPTED_DIR/" -type f) ; do
        bash -c "$GPG_COMMAND --output "${file%.gpg}" --decrypt "$file""
        rm ${file}
    done

    echo "Succesfully decrypted all files!"
else
    echo "Encrypted folder is empty"
fi

