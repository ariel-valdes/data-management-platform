/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/utils"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func (c *Controller) podIsFromAttachedScheduler(pod *v1.Pod) bool {
	return pod.Spec.SchedulerName == c.Config.SchedulerName
}

// Get pods from defined workload
func (c *Controller) getListOfPods(workload string) (*v1.PodList, error) {
	var podList *v1.PodList
	var err error

	switch {
	case isWorkloadGlobal(workload):
		podList, err = c.clientSet.CoreV1().Pods("").List(metav1.ListOptions{
			TimeoutSeconds: &c.Config.Timeout,
		})
	case isWorkloadNamespaceBound(workload):
		namespace := getNamespaceFromWorkload(workload)

		podList, err = c.clientSet.CoreV1().Pods(namespace).List(metav1.ListOptions{
			TimeoutSeconds: &c.Config.Timeout,
		})
	default:
		podList, err = c.clientSet.CoreV1().Pods("").List(metav1.ListOptions{
			LabelSelector:  c.Config.WorkloadLabelKey + "=" + workload,
			TimeoutSeconds: &c.Config.Timeout,
		})
	}

	if err == nil {
		// Filter out all pods that are either:
		// - not yet scheduled
		// - not from attached scheduler
		newPodList := podList.Items[:0]
		for _, pod := range podList.Items {
			if utils.CheckIfPodIsScheduled(pod) && c.podIsFromAttachedScheduler(&pod) {
				newPodList = append(newPodList, pod)
			}
		}

		podList.Items = newPodList
	}

	return podList, err
}
