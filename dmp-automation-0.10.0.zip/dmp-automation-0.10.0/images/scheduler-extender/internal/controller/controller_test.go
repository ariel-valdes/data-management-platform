/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"os"
	"sort"
	"testing"

	afds "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/api"
	afdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client"
	fakeafdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client/fake"
	schedulerconfig "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/config"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/fake"
	schedulerapi "k8s.io/kubernetes/pkg/scheduler/api"
)

// TODO: write unit tests for restricted fd count

func newTestController(
	clientSet kubernetes.Interface,
	assignedFDsClient afdsclient.AssignedFailureDomainClientInterface,
	config schedulerconfig.GlobalConfiguration,
) *Controller {

	return &Controller{
		Ossignals:        make(chan os.Signal, 1),
		Config:           config,
		clientSet:        clientSet,
		assignedFDClient: assignedFDsClient,
	}
}

func createPod(clientSet kubernetes.Interface, nodeName, workload, namespace, name string) {
	var labels map[string]string
	if workload == "" {
		labels = map[string]string{}
	} else {
		labels = map[string]string{
			"workloadKey": workload,
		}
	}

	_, err := clientSet.CoreV1().Pods(namespace).Create(
		&v1.Pod{
			ObjectMeta: metav1.ObjectMeta{
				Name:      name,
				Namespace: namespace,
				Labels:    labels,
			},
			Spec: v1.PodSpec{
				NodeName: nodeName,
			},
			Status: v1.PodStatus{
				Conditions: []v1.PodCondition{
					{
						Type: "PodScheduled",
					},
				},
			},
		},
	)
	if err != nil {
		panic(err.Error())
	}
}

func createNode(clientSet kubernetes.Interface, failureDomain string, nodeName string) *v1.Node {
	node, _ := clientSet.CoreV1().Nodes().Create(
		&v1.Node{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": failureDomain,
					"name":             nodeName,
				},
				Name: nodeName,
			},
		},
	)
	return node
}

func getRestrictedCountParsedInput(workload string, requestedFDCount uint) *forceWorkloadInput {
	input := &forceWorkloadInput{
		workload:         workload,
		requestedFDCount: new(uint),
	}
	*input.requestedFDCount = requestedFDCount

	return input
}

func getParsedInput(workload string) *forceWorkloadInput {
	input := &forceWorkloadInput{
		workload:         workload,
		requestedFDCount: nil,
	}

	return input
}

func areEqual(left []v1.Node, right []v1.Node) bool {
	if left == nil && right != nil {
		return false
	} else if left != nil && right == nil {
		return false
	}

	if len(left) != len(right) {
		return false
	}

	sort.Slice(left, func(i, j int) bool { return left[i].Name < left[j].Name })
	sort.Slice(right, func(i, j int) bool { return right[i].Name < right[j].Name })

	for i := 0; i < len(left); i++ {
		if left[i].Name != right[i].Name {
			return false
		}
	}

	return true
}

func unschedulableNodesMatch(output map[string]string, answer []string) bool {
	for _, nodeName := range answer {
		if _, ok := output[nodeName]; !ok {
			return false
		}
	}

	return true
}

var clientSet kubernetes.Interface
var assignedFDsClient afdsclient.AssignedFailureDomainClientInterface

var ctrl *Controller

func runTest(name string, t *testing.T, testFunc func(*testing.T)) {
	clientSet = fake.NewSimpleClientset()
	assignedFDsClient = fakeafdsclient.NewFakeAssignedFDsResourceClient()

	ctrl = newTestController(
		clientSet,
		assignedFDsClient,
		schedulerconfig.GlobalConfiguration{
			FailureDomainLabelKey:                   "failureDomainKey",
			RestrictFailureDomainCountAnnotationKey: "restrictFDCountKey",
			WorkloadLabelKey:                        "workloadKey",
			NodeNameLabelKey:                        "name",
		},
	)

	t.Run(name, testFunc)
}

func TestForceWorkloadFailureDomainSchedulingPredicate(t *testing.T) {
	runTest("Restricted count equal to 0", t, testRestrictedCountEqualToZero)
	runTest("Restricted count equal is not a number", t, testRestrictedCountNotANumber)
	runTest("Restricted count present but on an owner", t, testRestrictedCountPresentButNotOwner)

	runTest("Pod without workload label, but enabled scheduling", t, testPodWithoutLabel)

	runTest("Nodes with one failure domain", t, testOneFailureDomain)
	runTest("Two failure domains, both at minimum", t, testTwoDomainsBothAtMinimum)
	runTest("Three failure domains, two at minimum", t, testThreeDomainsTwoViable)

	runTest("Node doesn't have failure domain annotation", t, testNodeDoesntHaveFailureDomainLabel)

	runTest("Restricted count is different than already assigned", t, testRestrictedCountDifferentThanAlreadyAssigned)
	runTest("Failure domain from assignment is not present", t, testFailureDomainFromAssignmentIsNotPresent)

	runTest("No prior assignment, two out of three to assign", t, testNoPriorAssignmentTwoOutOfThreeToBeAssigned)
	runTest(
		"Four failure domains, two assigned, both not at the minimum",
		t,
		testFourFailureDomainsTwoAssignedBothNotMiminum,
	)

	runTest("Test handle for forced workload scheduling", t, testHandleForceDomainScheduling)
	runTest("Test handle for total pod spread", t, testHandleTotalPodSpread)
	runTest("Test global workload scheduling", t, testGlobalWorkloadScheduling)
}

func TestFailureDomainAssignment(t *testing.T) {
	runTest(
		"Restricted count bigger than available failure domains",
		t,
		testRestrictedCountBiggerThanAvailableFailureDomains,
	)

	runTest("Restricted count is equal to available failure domains", t, testRestrictedCountEqualToAvailableFailureDomains)
	runTest(
		"Restricted count is less than available failure domains, all candidates have minimal pod count",
		t,
		testRestrictedCountLessThanAvaiableFailureDomainsAllCandidatesMinimal,
	)
	runTest(
		"Restricted count is less than available failure domains, not all candidates have minimal pod count",
		t,
		testRestrictedCountLessThanAvailableFailureDomainsSomeCandidatesNotMinimal,
	)
}

func areAssignedFDResourcesEqual(a *afds.AssignedFailureDomain, b *afds.AssignedFailureDomain) bool {
	if len(a.Spec.OwnedFDs) != len(b.Spec.OwnedFDs) {
		return false
	}

	left := a.Spec.OwnedFDs
	right := b.Spec.OwnedFDs

	sort.Slice(left, func(i, j int) bool { return left[i] < left[j] })
	sort.Slice(right, func(i, j int) bool { return right[i] < right[j] })

	for i := 0; i < len(right); i++ {
		if left[i] != right[i] {
			return false
		}
	}

	return a.ObjectMeta.Name == b.ObjectMeta.Name && a.Spec.Owner == b.Spec.Owner && a.Spec.OwnerKind == b.Spec.OwnerKind
}

func testRestrictedCountLessThanAvailableFailureDomainsSomeCandidatesNotMinimal(t *testing.T) {
	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
			*createNode(clientSet, "rack3", "compute6"),
			*createNode(clientSet, "rack4", "compute7"),
			*createNode(clientSet, "rack4", "compute8"),
			*createNode(clientSet, "rack5", "compute9"),
			*createNode(clientSet, "rack5", "compute10"),
		},
	}

	// rack1
	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute2", "work1", "namespace", "pod2")
	createPod(clientSet, "compute1", "work1", "namespace", "pod3")
	createPod(clientSet, "compute2", "work1", "namespace", "pod4")
	createPod(clientSet, "compute1", "work1", "namespace", "pod5")

	// rack2
	createPod(clientSet, "compute3", "work1", "namespace", "pod6")
	createPod(clientSet, "compute3", "work1", "namespace", "pod7")

	// rack3
	createPod(clientSet, "compute5", "work1", "namespace", "pod8")
	createPod(clientSet, "compute6", "work1", "namespace", "pod9")
	createPod(clientSet, "compute6", "work1", "namespace", "pod10")

	// rack4
	createPod(clientSet, "compute7", "work1", "namespace", "pod11")
	createPod(clientSet, "compute7", "work1", "namespace", "pod12")
	createPod(clientSet, "compute8", "work1", "namespace", "pod13")
	createPod(clientSet, "compute8", "work1", "namespace", "pod14")

	// rack5
	createPod(clientSet, "compute9", "work1", "namespace", "pod15")
	createPod(clientSet, "compute10", "work1", "namespace", "pod16")

	assignedFDResource, err := ctrl.assignFailureDomainsToOwner(
		"mydeploy",
		"Deployment",
		&nodesIn,
		"work1",
		"namespace",
		3,
	)
	if err != nil {
		t.Error("Function returned an error")
	} else if !areAssignedFDResourcesEqual(
		assignedFDResource,
		afds.NewAssignedFailureDomain("mydeploy", "Deployment", []string{"rack2", "rack3", "rack5"}),
	) {
		t.Error("Function didn't assign failure domains correctly")
	}
}

func testRestrictedCountLessThanAvaiableFailureDomainsAllCandidatesMinimal(t *testing.T) {
	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
			*createNode(clientSet, "rack3", "compute6"),
		},
	}

	createPod(clientSet, "compute1", "work2", "namespace2", "pod8")
	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute2", "work1", "namespace", "pod2")
	createPod(clientSet, "compute1", "work1", "namespace", "pod3")

	createPod(clientSet, "compute3", "work1", "namespace", "pod4")
	createPod(clientSet, "compute3", "work1", "namespace", "pod5")

	createPod(clientSet, "compute5", "work1", "namespace", "pod6")
	createPod(clientSet, "compute6", "work1", "namespace", "pod7")

	assignedFDResource, err := ctrl.assignFailureDomainsToOwner(
		"mydeploy",
		"Deployment",
		&nodesIn,
		"work1",
		"namespace",
		2,
	)
	if err != nil {
		t.Error("Function returned an error")
	} else if !areAssignedFDResourcesEqual(
		assignedFDResource,
		afds.NewAssignedFailureDomain("mydeploy", "Deployment", []string{"rack2", "rack3"}),
	) {

		t.Error("Function didn't assigned correctly failure domains")
	}
}

func testRestrictedCountEqualToAvailableFailureDomains(t *testing.T) {
	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
		},
	}

	assignedFDResource, err := ctrl.assignFailureDomainsToOwner(
		"mydeploy",
		"Deployment",
		&nodesIn,
		"work1",
		"namespace",
		2,
	)
	if err != nil {
		t.Error("Function returned an error")
	} else if !areAssignedFDResourcesEqual(
		assignedFDResource,
		afds.NewAssignedFailureDomain("mydeploy", "Deployment", []string{"rack1", "rack2"}),
	) {
		t.Error("Function didn't assigned correctly failure domains")
	}
}

func testRestrictedCountBiggerThanAvailableFailureDomains(t *testing.T) {
	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
		},
	}

	_, err := ctrl.assignFailureDomainsToOwner("mydeploy", "Deployment", &nodesIn, "work1", "namespace", 3)
	if err == nil {
		t.Error("Predicate didn't returned an error")
	}
}

func testRestrictedCountPresentButNotOwner(t *testing.T) {
	input := getRestrictedCountParsedInput("work2", 2)

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work2",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "2",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
		},
	}

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err == nil {
		t.Error("Predicate didn't return an error")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate filtered pods")
	}
}

func testFourFailureDomainsTwoAssignedBothNotMiminum(t *testing.T) {
	input := getRestrictedCountParsedInput("work1", 2)

	isController := true
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "2",
			},
			OwnerReferences: []metav1.OwnerReference{
				{
					Name:       "mydeploy",
					Kind:       "Deployment",
					Controller: &isController,
				},
			},
			Namespace: "namespace",
		},
	}

	createPod(clientSet, "compute1", "work1", "namespace", "pod1")

	createPod(clientSet, "compute3", "work1", "namespace", "pod2")
	createPod(clientSet, "compute3", "work1", "namespace", "pod3")
	createPod(clientSet, "compute3", "work1", "namespace", "pod4")

	createPod(clientSet, "compute4", "work1", "namespace", "pod5")
	createPod(clientSet, "compute5", "work1", "namespace", "pod6")
	createPod(clientSet, "compute5", "work1", "namespace", "pod7")
	createPod(clientSet, "compute6", "work1", "namespace", "pod8")

	createPod(clientSet, "compute7", "work1", "namespace", "pod9")
	createPod(clientSet, "compute7", "work1", "namespace", "pod10")

	compute1 := *createNode(clientSet, "rack1", "compute1")
	compute2 := *createNode(clientSet, "rack1", "compute2")
	compute3 := *createNode(clientSet, "rack2", "compute3")
	compute4 := *createNode(clientSet, "rack3", "compute4")
	compute5 := *createNode(clientSet, "rack3", "compute5")
	compute6 := *createNode(clientSet, "rack3", "compute6")
	compute7 := *createNode(clientSet, "rack4", "compute7")

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			compute1, compute2, compute3, compute4, compute5, compute6, compute7,
		},
	}

	expectedSchedulableNodes := []v1.Node{
		compute7,
	}

	expectedUnschedulableNodes := []string{
		"compute1", "compute2", "compute3", "compute4", "compute5", "compute6",
	}

	_, err := ctrl.assignedFDClient.AssignedFDs("namespace").Create(
		afds.NewAssignedFailureDomain(
			"mydeploy",
			"Deployment",
			[]string{"rack3", "rack4"},
		),
	)
	if err != nil {
		panic(err.Error())
	}

	if nodesOut, unschedulableNodes, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(expectedSchedulableNodes, nodesOut) ||
		!unschedulableNodesMatch(unschedulableNodes, expectedUnschedulableNodes) {

		t.Errorf("Predicate output didn't match expectation got %v,\n expected %v\n", nodesOut, expectedSchedulableNodes)
	}
}

func testNoPriorAssignmentTwoOutOfThreeToBeAssigned(t *testing.T) {
	input := getRestrictedCountParsedInput("work1", 2)

	isController := true
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "2",
			},
			OwnerReferences: []metav1.OwnerReference{
				{
					Name:       "mydeploy",
					Kind:       "Deployment",
					Controller: &isController,
				},
			},
			Namespace: "namespace",
		},
	}

	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute2", "work1", "namespace", "pod2")
	createPod(clientSet, "compute3", "work1", "namespace", "pod3")
	createPod(clientSet, "compute3", "work1", "namespace", "pod6")
	createPod(clientSet, "compute3", "work1", "namespace", "pod7")
	createPod(clientSet, "compute4", "work1", "namespace", "pod4")

	compute1 := *createNode(clientSet, "rack1", "compute1")
	compute2 := *createNode(clientSet, "rack1", "compute2")
	compute3 := *createNode(clientSet, "rack2", "compute3")
	compute4 := *createNode(clientSet, "rack3", "compute4")
	compute5 := *createNode(clientSet, "rack3", "compute5")
	nodesIn := v1.NodeList{
		Items: []v1.Node{
			compute1, compute2, compute3, compute4, compute5,
		},
	}

	expectedSchedulableNodes := []v1.Node{
		compute4, compute5,
	}

	expectedUnschedulableNodes := []string{
		"compute1", "compute2", "compute3",
	}

	if nodesOut, unschedulableNodes, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(expectedSchedulableNodes, nodesOut) ||
		!unschedulableNodesMatch(unschedulableNodes, expectedUnschedulableNodes) {

		t.Errorf("Predicate output didn't match expectation got %v,\n expected %v\n", nodesOut, expectedSchedulableNodes)
	}
}

func testFailureDomainFromAssignmentIsNotPresent(t *testing.T) {
	input := getRestrictedCountParsedInput("work1", 2)

	isController := true
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "2",
			},
			OwnerReferences: []metav1.OwnerReference{
				{
					Name:       "mydeploy",
					Kind:       "Deployment",
					Controller: &isController,
				},
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
			*createNode(clientSet, "rack4", "compute6"),
			*createNode(clientSet, "rack4", "compute7"),
			*createNode(clientSet, "rack5", "compute8"),
		},
	}

	_, err := ctrl.assignedFDClient.AssignedFDs("namespace").Create(
		afds.NewAssignedFailureDomain(
			"mydeploy",
			"Deployment",
			[]string{"rack1", "rack5"},
		),
	)
	if err != nil {
		panic(err.Error())
	}

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err == nil {
		t.Error("Predicate didn't return an error")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate filtered nodes")
	}
}

func testRestrictedCountDifferentThanAlreadyAssigned(t *testing.T) {
	input := getRestrictedCountParsedInput("work1", 3)

	isController := true
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "3",
			},
			OwnerReferences: []metav1.OwnerReference{
				{
					Name:       "mydeploy",
					Kind:       "Deployment",
					Controller: &isController,
				},
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
			*createNode(clientSet, "rack4", "compute6"),
			*createNode(clientSet, "rack4", "compute7"),
			*createNode(clientSet, "rack5", "compute8"),
		},
	}

	_, err := ctrl.assignedFDClient.AssignedFDs("namespace").Create(
		afds.NewAssignedFailureDomain(
			"mydeploy",
			"Deployment",
			[]string{"rack1", "rack5"},
		),
	)
	if err != nil {
		panic(err.Error())
	}

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err == nil {
		t.Error("Predicate didn't return an error")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate filtered nodes")
	}
}

func testRestrictedCountEqualToZero(t *testing.T) {
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "0",
			},
			Namespace: "namespace",
		},
	}

	if _, err := ctrl.parseForceWorkloadPredicateInput(&pod); err == nil {
		t.Error("Predicate didn't return an error")
	}
}

func testRestrictedCountNotANumber(t *testing.T) {
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Annotations: map[string]string{
				"restrictFDCountKey": "123asfasdf",
			},
			Namespace: "namespace",
		},
	}

	if _, err := ctrl.parseForceWorkloadPredicateInput(&pod); err == nil {
		t.Error("Predicate didn't return an error")
	}
}

func testPodWithoutLabel(t *testing.T) {
	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: "namespace",
			Labels: map[string]string{
				"enableSchedulingKey": "true",
			},
		},
	}

	if input, err := ctrl.parseForceWorkloadPredicateInput(&pod); err == nil {
		if input.workload != "__namespace" {
			t.Error("Predicate didn't replace workload with namespace")
		}
	}
}

func testOneFailureDomain(t *testing.T) {
	input := getParsedInput("work2")

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"enableSchedulingKey": "true",
				"workloadKey":         "work2",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack1", "compute3"),
		},
	}

	createPod(clientSet, "compute1", "work2", "namespace", "pod1")
	createPod(clientSet, "compute2", "work2", "namespace", "pod2")
	createPod(clientSet, "compute3", "work2", "namespace", "pod3")

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate filtered without annotation")
	}
}

func testTwoDomainsBothAtMinimum(t *testing.T) {
	input := getParsedInput("work1")

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack2", "compute4"),
		},
	}

	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute1", "work1", "namespace", "pod2")
	createPod(clientSet, "compute3", "work1", "namespace", "pod3")
	createPod(clientSet, "compute4", "work1", "namespace", "pod4")

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate output didn't match expectation")
	}
}

func testThreeDomainsTwoViable(t *testing.T) {
	input := getParsedInput("work1")

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack3", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
		},
	}

	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute1", "work1", "namespace", "pod2")
	createPod(clientSet, "compute2", "work1", "namespace", "pod3")
	createPod(clientSet, "compute3", "work1", "namespace", "pod4")
	createPod(clientSet, "compute3", "work1", "namespace", "pod5")
	createPod(clientSet, "compute4", "work1", "namespace", "pod6")
	createPod(clientSet, "compute5", "work1", "namespace", "pod7")

	expectedSchedulableNodes := []v1.Node{
		{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": "rack2",
				},
				Name: "compute3",
			},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": "rack3",
				},
				Name: "compute4",
			},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": "rack3",
				},
				Name: "compute5",
			},
		},
	}

	expectedUnschedulableNodes := []string{
		"compute1",
		"compute2",
	}

	if nodesOut, unschedulableNodes, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(expectedSchedulableNodes, nodesOut) ||
		!unschedulableNodesMatch(unschedulableNodes, expectedUnschedulableNodes) {

		t.Errorf("Predicate output didn't match expectation got %v,\n expected %v\n", nodesOut, expectedSchedulableNodes)
	}
}

func testNodeDoesntHaveFailureDomainLabel(t *testing.T) {
	input := getParsedInput("work1")

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			{
				ObjectMeta: metav1.ObjectMeta{
					Name: "compute4",
				},
			},
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
		},
	}

	createPod(clientSet, "compute1", "work1", "namespace", "pod1")
	createPod(clientSet, "compute1", "work1", "namespace", "pod2")
	createPod(clientSet, "compute3", "work1", "namespace", "pod3")
	createPod(clientSet, "compute4", "work1", "namespace", "pod4")

	if nodesOut, _, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err == nil {
		t.Error("Predicate didn't log failure about node lacking annotation")
	} else if !areEqual(nodesIn.Items, nodesOut) {
		t.Error("Predicate filtered without information about failure domain")
	}
}

func testGlobalWorkloadScheduling(t *testing.T) {
	input := getParsedInput("__global")

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack3", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
		},
	}

	createPod(clientSet, "compute1", "", "namespace", "pod1")
	createPod(clientSet, "compute2", "", "namespace", "pod2")
	createPod(clientSet, "compute3", "", "namespace", "pod3")
	createPod(clientSet, "compute3", "", "namespace", "pod4")
	createPod(clientSet, "compute3", "", "namespace", "pod5")
	createPod(clientSet, "compute4", "", "namespace", "pod6")
	createPod(clientSet, "compute4", "", "namespace", "pod7")
	createPod(clientSet, "compute4", "", "namespace", "pod8")
	createPod(clientSet, "compute5", "", "namespace", "pod9")

	expectedSchedulableNodes := []v1.Node{
		{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": "rack1",
				},
				Name: "compute1",
			},
		},
		{
			ObjectMeta: metav1.ObjectMeta{
				Labels: map[string]string{
					"failureDomainKey": "rack1",
				},
				Name: "compute2",
			},
		},
	}

	expectedUnschedulableNodes := []string{
		"compute3",
		"compute4",
		"compute5",
	}

	if nodesOut, unschedulableNodes, err := ctrl.forceWorkloadFailureDomainScheduling(&pod, &nodesIn, input); err != nil {
		t.Error("Predicate returned error")
	} else if !areEqual(expectedSchedulableNodes, nodesOut) ||
		!unschedulableNodesMatch(unschedulableNodes, expectedUnschedulableNodes) {

		t.Error("Predicate output didn't match expectation")
	}

}

func testHandleForceDomainScheduling(t *testing.T) {
	synchronizeTasks = false

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack3", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
		},
	}

	extenderArgs := schedulerapi.ExtenderArgs{
		Pod:   &pod,
		Nodes: &nodesIn,
	}

	_, err := ctrl.HandleForcedWorkloadFailureDomainScheduling(extenderArgs)
	if err != nil {
		t.Error("Error during checking force workload failure domain scheduling handle: ", err.Error())
	}
}

func testHandleTotalPodSpread(t *testing.T) {
	synchronizeTasks = false

	pod := v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Labels: map[string]string{
				"workloadKey":         "work1",
				"enableSchedulingKey": "true",
			},
			Namespace: "namespace",
		},
	}

	nodesIn := v1.NodeList{
		Items: []v1.Node{
			*createNode(clientSet, "rack1", "compute1"),
			*createNode(clientSet, "rack1", "compute2"),
			*createNode(clientSet, "rack2", "compute3"),
			*createNode(clientSet, "rack3", "compute4"),
			*createNode(clientSet, "rack3", "compute5"),
		},
	}

	extenderArgs := schedulerapi.ExtenderArgs{
		Pod:   &pod,
		Nodes: &nodesIn,
	}

	_, err := ctrl.HandleTotalPodSpread(extenderArgs)
	if err != nil {
		t.Error("Error during checking total pod spread handle: ", err.Error())
	}
}

func TestNoPrioritization(t *testing.T) {

}
