// +build !debug

/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package debug

import (
	"net/http"

	ctrl "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/controller"
)

func GetDebugFunc(c *ctrl.Controller) func(http.ResponseWriter, *http.Request) {
	return func(writer http.ResponseWriter, request *http.Request) {
		writer.WriteHeader(http.StatusForbidden)
	}
}
