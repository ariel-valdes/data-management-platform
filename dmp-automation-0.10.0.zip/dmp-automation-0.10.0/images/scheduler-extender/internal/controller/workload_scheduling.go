/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"errors"
	"sort"
	"strconv"
	"strings"

	"gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/utils"
	afds "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/api"
	v1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

type forceWorkloadInput struct {
	workload         string
	requestedFDCount *uint
}

type nodeFailureDomain struct {
	Node          *v1.Node
	FailureDomain string
}

func isWorkloadGlobal(workload string) bool {
	return workload == "__global"
}

func isWorkloadNamespaceBound(workload string) bool {
	return strings.HasPrefix(workload, "__") && !isWorkloadGlobal(workload)
}

func getNamespaceFromWorkload(workload string) string {
	return workload[2:]
}

func (c *Controller) setWorkload(pod *v1.Pod) string {
	// Precedence here is: label workload (if defined), global (if defined), fallback to namespace
	workload, ok := pod.Labels[c.Config.WorkloadLabelKey]
	if !ok {
		if c.Config.GlobalWorkload {
			workload = "__global"
		} else {
			workload = "__" + pod.Namespace
		}
	}

	return workload
}

func (c *Controller) setFailureDomainCount(pod *v1.Pod) (*uint, error) {
	requestedFDCountRaw, fdCountDefined := pod.Annotations[c.Config.RestrictFailureDomainCountAnnotationKey]
	var requestedFDCount *uint

	// Label defined count should take precedence over default configured
	if fdCountDefined {
		requestedFDCount64, err := strconv.ParseUint(requestedFDCountRaw, 10, 64)
		if err != nil {
			return nil, errors.New("Couldn't parse count number to unsinged number: " + requestedFDCountRaw)
		}
		requestedFDCount = new(uint)
		*requestedFDCount = uint(requestedFDCount64)
		if *requestedFDCount == 0 {
			return nil, errors.New("Restricted failure domain is equal to 0")
		}
	} else if c.Config.DefaultRestrictedCount > 0 {
		requestedFDCount = new(uint)
		*requestedFDCount = uint(c.Config.DefaultRestrictedCount)
	}

	return requestedFDCount, nil
}

func (c *Controller) parseForceWorkloadPredicateInput(pod *v1.Pod) (*forceWorkloadInput, error) {
	requestedFDCount, err := c.setFailureDomainCount(pod)
	if err != nil {
		return &forceWorkloadInput{
			workload:         "",
			requestedFDCount: nil,
		}, err
	}

	workload := c.setWorkload(pod)

	return &forceWorkloadInput{
		workload:         workload,
		requestedFDCount: requestedFDCount,
	}, nil
}

func (c *Controller) forcePodSpreadOverNodes(
	nodeList *v1.NodeList,
	input *forceWorkloadInput) (schedulableNodes []v1.Node, unschedulableNodes map[string]string, err error) {

	nodeNameToBucket, podMinimum, bucketCount, unschedulableNodes, err := c.getCurrentPodSpreadInformation(
		nodeList,
		input.workload,
		nil,
		c.Config.NodeNameLabelKey,
	)
	if err != nil {
		return nodeList.Items, nil, err
	}

	return filterNodesWithNotMinimalPodCount(bucketCount, nodeNameToBucket, podMinimum, unschedulableNodes)
}

func (c *Controller) forceWorkloadFailureDomainScheduling(
	pod *v1.Pod,
	nodeList *v1.NodeList,
	input *forceWorkloadInput,
) (schedulableNodes []v1.Node, unschedulableNodes map[string]string, err error) {

	var assignedFDResource *afds.AssignedFailureDomain
	if input.requestedFDCount != nil {
		assignedFDResource, err = c.getOrAssignFailureDomainsForOwner(*input.requestedFDCount, input.workload, pod, nodeList)
		if err != nil {
			return nodeList.Items, nil, err
		}
	}

	nodeNameToFailureDomain, podMinimum, failureDomainCount, unschedulableNodes, err := c.getCurrentPodSpreadInformation(
		nodeList,
		input.workload,
		assignedFDResource,
		c.Config.FailureDomainLabelKey,
	)
	if err != nil {
		return nodeList.Items, nil, err
	}

	return filterNodesWithNotMinimalPodCount(failureDomainCount, nodeNameToFailureDomain, podMinimum, unschedulableNodes)
}

func (c *Controller) getOrAssignFailureDomainsForOwner(
	requestedFDCount uint,
	workload string,
	pod *v1.Pod,
	nodeList *v1.NodeList,
) (*afds.AssignedFailureDomain, error) {

	var podOwner *metav1.OwnerReference
	var assignedFDResource *afds.AssignedFailureDomain

	for _, owner := range pod.OwnerReferences {
		if *owner.Controller {
			podOwner = &owner
		}
	}

	if podOwner == nil {
		return nil, errors.New("pod has defined restrictions on failure domains, but hasn't got any owner")
	}

	assignedFDResource, err := c.assignedFDClient.AssignedFDs(pod.Namespace).GetByOwner(podOwner.Name, podOwner.Kind)
	if err != nil {
		if apierrors.IsNotFound(err) {
			assignedFDResource, err = c.assignFailureDomainsToOwner(
				podOwner.Name,
				podOwner.Kind,
				nodeList,
				workload,
				pod.Namespace,
				requestedFDCount,
			)

			if err != nil {
				return nil, err
			}
		} else {
			return nil, errors.New("Unexpected error during getting assigned failure domain custom resource: " + err.Error())
		}

		// TODO: check responsiveness of nodes in assigned failure domains
	}

	if len(assignedFDResource.Spec.OwnedFDs) != int(requestedFDCount) {
		return nil, errors.New("Restricted failure domain count is different than already count of assigned failure domains")
	}

	return assignedFDResource, nil
}

func (c *Controller) assignFailureDomainsToOwner(
	ownerName string,
	ownerKind string,
	nodeList *v1.NodeList,
	workload string,
	namespace string,
	requestedFDCount uint,
) (*afds.AssignedFailureDomain, error) {

	_, _, failureDomainCount, _, err := c.getCurrentPodSpreadInformation(
		nodeList,
		workload,
		nil,
		c.Config.FailureDomainLabelKey,
	)
	if err != nil {
		return nil, err
	}

	// TODO: doesn't work, returns "" as second FD
	// Don't schedule if requested FD count is larger than count of all FDs altogether
	if int(requestedFDCount) > len(failureDomainCount) {
		return nil, errors.New("Requested number of failure domains exceeds number of available failure domains")
	}

	assignedFD := make([]string, len(failureDomainCount))
	i := 0
	for fd := range failureDomainCount {
		assignedFD[i] = fd
		i++
	}

	sort.Slice(
		assignedFD,
		func(i int, j int) bool {
			return failureDomainCount[assignedFD[i]] < failureDomainCount[assignedFD[j]]
		},
	)

	assignedFDResource, err := c.assignedFDClient.AssignedFDs(namespace).Create(
		afds.NewAssignedFailureDomain(ownerName, ownerKind, assignedFD[:requestedFDCount]),
	)
	if err != nil {
		return nil, errors.New("Problem with creating assigned failure domains custom resource: " + err.Error())
	}

	return assignedFDResource, nil
}

func (c *Controller) getCurrentPodSpreadInformation(
	nodeList *v1.NodeList,
	workload string,
	assignedFDResource *afds.AssignedFailureDomain,
	nodeLabel string,
) (
	nodeNameToFailureDomain map[string]nodeFailureDomain,
	podMinimum uint,
	failureDomainCount map[string]uint,
	unschedulableNodes map[string]string,
	err error,
) {

	podList, err := c.getListOfPods(workload)
	if err != nil {
		return nil, 0, nil, nil, errors.New("Pod retrieval failed. Reason: " + err.Error())
	}

	nodeNameToFailureDomain, err = mapNodeNameToFailureDomain(nodeList, nodeLabel)
	if err != nil {
		return nil, 0, nil, nil, err
	}

	// Filter by assigned resource if present
	if assignedFDResource != nil {
		unschedulableNodes = make(map[string]string)
		// Node list is left unfiltered because it's unneeded
		filterNodeAndPodListByFailureDomains(
			&nodeNameToFailureDomain,
			podList,
			assignedFDResource.Spec.OwnedFDs,
			unschedulableNodes,
		)
	}

	failureDomainCount = countFailureDomains(nodeNameToFailureDomain, podList)

	if assignedFDResource != nil {
		// Check if all assigned failure domains are in filter result
		for _, fd := range assignedFDResource.Spec.OwnedFDs {
			if _, exist := failureDomainCount[fd]; !exist {
				return nil, 0, nil, nil, errors.New("Assigned failure domain " + fd + " is not present in input node list")
			}
		}
	}

	podMinimum = findPodCountMinimum(failureDomainCount)

	return nodeNameToFailureDomain, podMinimum, failureDomainCount, unschedulableNodes, err
}

func filterNodeAndPodListByFailureDomains(
	nodeNameToFailureDomain *map[string]nodeFailureDomain,
	podList *v1.PodList,
	failureDomains []string,
	unschedulableNodes map[string]string,
) {
	// Filer out nodes and pods that don't belong to assigned FDs
	sort.Strings(failureDomains)

	newPodList := podList.Items[:0]
	for _, pod := range podList.Items {
		podFD := (*nodeNameToFailureDomain)[pod.Spec.NodeName].FailureDomain

		if utils.IsKeyInSortedSlice(podFD, failureDomains) {
			newPodList = append(newPodList, pod)
		}
	}

	podList.Items = newPodList

	newNodeMap := make(map[string]nodeFailureDomain)

	for nodeName, nodeStruct := range *nodeNameToFailureDomain {
		if utils.IsKeyInSortedSlice(nodeStruct.FailureDomain, failureDomains) {
			newNodeMap[nodeName] = nodeStruct
		} else {
			unschedulableNodes[nodeName] = "Node is not in assigned failure domain"
		}
	}

	*nodeNameToFailureDomain = newNodeMap
}

func filterNodesWithNotMinimalPodCount(
	failureDomainCount map[string]uint,
	nodeNameToFailureDomain map[string]nodeFailureDomain,
	podMinimum uint,
	unschedulableNodes map[string]string,
) ([]v1.Node, map[string]string, error) {
	// NOTE: can be optimized by making use of the existing nodeList
	schedulableNodes := make([]v1.Node, 0)

	if unschedulableNodes == nil {
		unschedulableNodes = make(map[string]string)
	}

	for nodeName, nodeStruct := range nodeNameToFailureDomain {
		if failureDomainCount[nodeStruct.FailureDomain] > podMinimum {
			unschedulableNodes[nodeName] = "Node not schedulable, reason: forced workload failure domain scheduling"
		} else {
			schedulableNodes = append(schedulableNodes, *nodeStruct.Node)
		}
	}

	return schedulableNodes, unschedulableNodes, nil
}

func mapNodeNameToFailureDomain(nodeList *v1.NodeList, failureDomainKey string) (map[string]nodeFailureDomain, error) {
	nodeNameToFailureDomain := make(map[string]nodeFailureDomain)

	// Find all failure domains across nodes
	for i, node := range nodeList.Items {
		if failureDomain, ok := node.Labels[failureDomainKey]; ok {
			nodeNameToFailureDomain[node.Name] = nodeFailureDomain{
				Node:          &nodeList.Items[i],
				FailureDomain: failureDomain,
			}

		} else {
			return nil, errors.New("node doesn't have failure domain label; didn't filter any nodes")
		}
	}

	return nodeNameToFailureDomain, nil
}

func countFailureDomains(
	nodeNameToFailureDomain map[string]nodeFailureDomain,
	podList *v1.PodList,
) map[string]uint {

	// Make map failure domain -> pod count
	failureDomainCount := make(map[string]uint)

	for _, nodeStruct := range nodeNameToFailureDomain {
		failureDomainCount[nodeStruct.FailureDomain] = 0
	}

	// Count pods in each failure domain
	for _, scheduledPod := range podList.Items {
		failureDomain := nodeNameToFailureDomain[scheduledPod.Spec.NodeName].FailureDomain
		failureDomainCount[failureDomain]++
	}

	return failureDomainCount
}

func findPodCountMinimum(failureDomainCount map[string]uint) (podMinimum uint) {
	// Find minimum failure domain pod count
	podMinimum = ^uint(0) // max uint
	for _, count := range failureDomainCount {
		if count < podMinimum {
			podMinimum = count
		}
	}

	return
}
