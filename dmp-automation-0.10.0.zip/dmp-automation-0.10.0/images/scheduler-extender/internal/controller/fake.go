/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"bytes"
	"net/http"

	fakeafdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client/fake"
	schedulerconfig "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/config"
	"k8s.io/client-go/kubernetes/fake"
)

// MockResponseWriter is a mock implementation of ResponseWriter for testing request handlers
type MockResponseWriter struct {
	response   *bytes.Buffer
	statusCode *int
}

type MockClosedBuffer struct {
	*bytes.Buffer
}

func NewMockClosedBuffer(buffer []byte) *MockClosedBuffer {
	return &MockClosedBuffer{
		bytes.NewBuffer(buffer),
	}
}

func (buffer MockClosedBuffer) Close() error {
	return nil
}

// NewMockResponseWriter is a constructor for struct MockResponseWriter
func NewMockResponseWriter() MockResponseWriter {
	return MockResponseWriter{
		response:   bytes.NewBuffer(make([]byte, 0, 1024)),
		statusCode: new(int),
	}
}

func NewMockController() *Controller {
	clientSet := fake.NewSimpleClientset()
	assignedFDsClient := fakeafdsclient.NewFakeAssignedFDsResourceClient()
	config := schedulerconfig.GlobalConfiguration{
		FailureDomainLabelKey:                   "failureDomainKey",
		RestrictFailureDomainCountAnnotationKey: "restrictFDCountKey",
		WorkloadLabelKey:                        "workloadKey",
	}

	return NewController(clientSet, assignedFDsClient, config)
}

func (writer MockResponseWriter) Header() http.Header {
	return make(http.Header)
}

func (writer MockResponseWriter) Write(msg []byte) (int, error) {
	return writer.response.Write(msg)
}

func (writer MockResponseWriter) WriteHeader(statusCode int) {
	*writer.statusCode = statusCode
}
