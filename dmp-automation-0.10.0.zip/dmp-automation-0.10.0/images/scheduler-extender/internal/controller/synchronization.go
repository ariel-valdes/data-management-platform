/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"time"

	log "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"
	"gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/utils"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// Mutexes that control kubernetes schedule race. This race is made from two separate races. Each
// workload has independent set of mutexes.
//
// Variable schedulingMutexMap prevents race between multiple threads of the router. Request from
// kubernetes scheduling are parallelized. They cannot however be done in parallel, because number
// of scheduled pods has to be synchronized between threads.
//
// Variable podSchedulerWaitMutexmap prevents race in pod status. That is, it forces extender to
// wait for confirmation of pod schedule before handling next request.
var schedulingMutexMap = make(map[string]chan struct{})
var podSchedulerWaitMutexMap = make(map[string]chan struct{})

const WaitForPodScheduleTimeoutSeconds = 5
const WaitForPodScheduleRetryPeriodMilliseconds = 400

// returns function to defer
func enterSchedulingCriticalSection(workload string) func() {
	schedulingMutex := getSchedulingMutex(workload)
	schedulingMutex <- struct{}{}
	waitForEndOfPodSchedule(workload)
	return func() { <-schedulingMutex }
}

func getSchedulingMutex(workload string) chan struct{} {
	mutex, ok := schedulingMutexMap[workload]
	if !ok {
		mutex = make(chan struct{}, 1)
		schedulingMutexMap[workload] = mutex
	}

	return mutex
}

func getPodSchedulerWaitMutex(workload string) chan struct{} {
	mutex, ok := podSchedulerWaitMutexMap[workload]

	if !ok {
		mutex = make(chan struct{}, 1)
		podSchedulerWaitMutexMap[workload] = mutex
	}

	return mutex
}

func waitForEndOfPodSchedule(workload string) {
	mutex := getPodSchedulerWaitMutex(workload)

	// Block if extender still awaits for last pod's schedule
	mutex <- struct{}{}
	<-mutex
}

func (c *Controller) waitForPodSchedule(name string, workload string, namespace string) {
	podSchedulerWaitMutex := getPodSchedulerWaitMutex(workload)
	podSchedulerWaitMutex <- struct{}{}
	defer func() { <-podSchedulerWaitMutex }()

	start := time.Now()

	// End loop with failure after timeout
	for time.Since(start) < WaitForPodScheduleTimeoutSeconds*time.Second {
		podList, err := c.clientSet.CoreV1().Pods(namespace).List(metav1.ListOptions{
			FieldSelector: "metadata.name==" + name,
		})

		if err != nil || len(podList.Items) < 1 {
			log.Logger.Println(log.LogError, "Kubernetes API error during checking for pod schedule")
			return
		}

		if utils.CheckIfPodIsScheduled(podList.Items[0]) {
			return
		}

		time.Sleep(WaitForPodScheduleRetryPeriodMilliseconds * time.Millisecond)
	}

	log.Logger.Println(log.LogError, "Extender timeout for waiting pod to schedule")
}
