/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"os"
	"syscall"

	log "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"
	afdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client"
	schedulerconfig "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/config"
	v1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes"
	schedulerapi "k8s.io/kubernetes/pkg/scheduler/api"
)

// Right now, this package variable is used for unit tests only
var synchronizeTasks = true

// Controller is responsible for controlling extender logic
type Controller struct {
	clientSet        kubernetes.Interface
	assignedFDClient afdsclient.AssignedFailureDomainClientInterface
	Ossignals        chan os.Signal
	Config           schedulerconfig.GlobalConfiguration
}

// NewController creates new instance of controller
func NewController(
	clientSet kubernetes.Interface,
	assignedFDClient afdsclient.AssignedFailureDomainClientInterface,
	config schedulerconfig.GlobalConfiguration) *Controller {

	return &Controller{
		Ossignals:        make(chan os.Signal, 1),
		Config:           config,
		clientSet:        clientSet,
		assignedFDClient: assignedFDClient,
	}
}

// HandleForcedWorkloadFailureDomainScheduling handles logic for forced workload predicate
func (c *Controller) HandleForcedWorkloadFailureDomainScheduling(
	extenderArgs schedulerapi.ExtenderArgs) (*schedulerapi.ExtenderFilterResult, error) {

	var schedulableNodes []v1.Node
	var unschedulableNodes map[string]string

	input, err := c.parseForceWorkloadPredicateInput(extenderArgs.Pod)
	if err != nil {
		return nil, err
	}

	if synchronizeTasks {
		freeMutex := enterSchedulingCriticalSection(input.workload)
		defer freeMutex()
	}

	schedulableNodes, unschedulableNodes, err = c.forceWorkloadFailureDomainScheduling(
		extenderArgs.Pod,
		extenderArgs.Nodes,
		input,
	)
	if err != nil {
		return nil, err
	}

	if synchronizeTasks {
		go c.waitForPodSchedule(extenderArgs.Pod.Name, input.workload, extenderArgs.Pod.Namespace)
	}

	return &schedulerapi.ExtenderFilterResult{
		Nodes: &v1.NodeList{
			Items: schedulableNodes,
		},
		FailedNodes: unschedulableNodes,
		Error:       "", // I have no idea what this field was supposed to be for
	}, nil
}

// HandleTotalPodSpread handles logic for total pod spread predicate
func (c *Controller) HandleTotalPodSpread(
	extenderArgs schedulerapi.ExtenderArgs) (*schedulerapi.ExtenderFilterResult, error) {

	var schedulableNodes []v1.Node
	var unschedulableNodes map[string]string
	var unschedulableNodesTotal map[string]string

	input, err := c.parseForceWorkloadPredicateInput(extenderArgs.Pod)
	if err != nil {
		return nil, err
	}

	// Block concurrent scheduling of pods
	if synchronizeTasks {
		freeMutex := enterSchedulingCriticalSection(input.workload)
		defer freeMutex()
	}

	// First of do one pass of normal force workload scheduling
	schedulableNodes, unschedulableNodes, err = c.forceWorkloadFailureDomainScheduling(
		extenderArgs.Pod,
		extenderArgs.Nodes,
		input,
	)
	if err != nil {
		return nil, err
	}

	unschedulableNodesTotal = unschedulableNodes
	newNodeList := v1.NodeList{Items: schedulableNodes}

	// Now do second pass but with node name as FD key
	schedulableNodes, unschedulableNodes, err = c.forcePodSpreadOverNodes(&newNodeList, input)
	if err != nil {
		return nil, err
	}

	// Combine unschedulableNodes dict with former to get final one
	for nodeName, reason := range unschedulableNodes {
		unschedulableNodesTotal[nodeName] = reason
	}

	if synchronizeTasks {
		go c.waitForPodSchedule(extenderArgs.Pod.Name, input.workload, extenderArgs.Pod.Namespace)
	}

	return &schedulerapi.ExtenderFilterResult{
		Nodes: &v1.NodeList{
			Items: schedulableNodes,
		},
		FailedNodes: unschedulableNodesTotal,
		Error:       "", // I have no idea what this field was supposed to be for
	}, nil
}

// StartGoroutines starts all controller parallel goroutines
func (c *Controller) StartGoroutines() {
	go c.processSignals()
}

// Process os signals for extender
func (c *Controller) processSignals() {
	for signal := range c.Ossignals {
		switch signal {
		// Configuration reloading
		case syscall.SIGHUP:
			c.Config = schedulerconfig.LoadConfiguration()
			log.Logger.Println(log.LogInfo, "Reloaded config")
		// Application termination
		case syscall.SIGQUIT:
			return
		case syscall.SIGTERM:
			return
		}
	}
}

// HandleNoPrioritization handles logic for zero priority logic
func (c *Controller) HandleNoPrioritization(
	extenderArgs schedulerapi.ExtenderArgs) (*schedulerapi.HostPriorityList, error) {

	return noPrioritization(extenderArgs.Pod, extenderArgs.Nodes)
}

// Defined predicates and priorities
func noPrioritization(_ *v1.Pod, nodes *v1.NodeList) (*schedulerapi.HostPriorityList, error) {
	var priorityList schedulerapi.HostPriorityList = make([]schedulerapi.HostPriority, len(nodes.Items))
	for i, node := range nodes.Items {
		priorityList[i] = schedulerapi.HostPriority{
			Host:  node.Name,
			Score: 0,
		}
	}
	return &priorityList, nil
}
