/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"encoding/json"
	"fmt"
	"net/http"
	"syscall"
	"testing"

	schedulerapi "k8s.io/kubernetes/pkg/scheduler/api"
)

func createRequest(args *schedulerapi.ExtenderArgs) *http.Request {
	if args == nil {
		return &http.Request{
			Body: nil,
		}
	}

	buffer := NewMockClosedBuffer(make([]byte, 0, 1000))
	err := json.NewEncoder(buffer).Encode(args)
	if err != nil {
		panic(fmt.Sprintf("Coudln't encode args: %s", err.Error()))
	}

	return &http.Request{
		Body: buffer,
	}
}

func TestGetPriorityRequestHandleFunc(t *testing.T) {
	handlePriorityRequestSuccessful := func(_ schedulerapi.ExtenderArgs) (*schedulerapi.HostPriorityList, error) {
		return &schedulerapi.HostPriorityList{}, nil
	}

	// Mock request validation
	readRequestBody = func(_ http.ResponseWriter, _ *http.Request, _ *schedulerapi.ExtenderArgs) bool {
		return true
	}

	writer := NewMockResponseWriter()
	request := createRequest(nil)
	GetPriorityRequestHandleFunc(handlePriorityRequestSuccessful)(writer, request)

	if *writer.statusCode != 200 {
		t.Error("Priority request failed simple test case")
	}
}

func TestGetPredicateRequestHandleFunc(t *testing.T) {
	handlePredicateRequestSuccessful := func(_ schedulerapi.ExtenderArgs) (*schedulerapi.ExtenderFilterResult, error) {
		return &schedulerapi.ExtenderFilterResult{}, nil
	}

	// Mock request validation
	readRequestBody = func(_ http.ResponseWriter, _ *http.Request, _ *schedulerapi.ExtenderArgs) bool {
		return true
	}

	writer := NewMockResponseWriter()
	request := createRequest(nil)
	GetPredicateRequestHandleFunc(handlePredicateRequestSuccessful)(writer, request)

	if *writer.statusCode != 200 {
		t.Error("Priority request failed simple test case")
	}
}

func testReadRequestBodyFuncEmptyBody(t *testing.T) {
	args := schedulerapi.ExtenderArgs{}
	writer := NewMockResponseWriter()
	request := createRequest(nil)

	// test correct response for empty body
	readRequestBodyFunc(writer, request, &args)

	if *writer.statusCode != 400 {
		t.Error("Return code was not a 400, when body is missing")
	}
}

func testReadRequestBodyFuncCorruptedBody(t *testing.T) {
	args := schedulerapi.ExtenderArgs{}
	writer := NewMockResponseWriter()
	request := createRequest(&schedulerapi.ExtenderArgs{})

	buffer, ok := request.Body.(*MockClosedBuffer)
	if !ok {
		panic("Body request is not a mock struct")
	}

	buffer.Reset()
	buffer.Write([]byte{123, 53, 12, 54, 123, 22, 1, 2, 4, 5, 123, 4})

	// test correct response for empty body
	readRequestBodyFunc(writer, request, &args)

	if *writer.statusCode != 400 {
		t.Error("Return code was not a 400, when body is corrupted")
	}
}

func TestReadRequestBodyFunc(t *testing.T) {
	testReadRequestBodyFuncEmptyBody(t)
	testReadRequestBodyFuncCorruptedBody(t)
}

func TestGetReloadRequestHandleFunc(t *testing.T) {
	controller := NewMockController()
	controller.Config.Version = "asdas"
	writer := NewMockResponseWriter()
	request := createRequest(nil)

	GetReloadRequestHandleFunc(controller)(writer, request)

	if *writer.statusCode != http.StatusAccepted {
		t.Error("Handle did not return code Accepted")
	}

	select {
	case signal := <-controller.Ossignals:
		if signal != syscall.SIGHUP {
			t.Error("Handle sent signal other than SIGHUP")
		}
	default:
		t.Error("Handler did not send any signal to controller")
	}
}

func TestGetVersionRequestHandleFunc(t *testing.T) {
	controller := NewMockController()
	controller.Config.Version = "asdas"
	writer := NewMockResponseWriter()
	request := createRequest(nil)

	GetVersionRequestHandleFunc(controller)(writer, request)

	switch {
	case *writer.statusCode != http.StatusOK:
		t.Error("Handle did not return 200")
	case writer.response.String() != "asdas":
		t.Error("Handle did not return configured version")
	}
}
