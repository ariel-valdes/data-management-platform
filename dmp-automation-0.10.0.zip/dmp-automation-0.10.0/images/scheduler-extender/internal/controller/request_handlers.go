/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package controller

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"syscall"

	log "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"
	schedulerapi "k8s.io/kubernetes/pkg/scheduler/api"
)

// Ready to be mocked functions
var readRequestBody = readRequestBodyFunc

// Parses extender args; returns false if request is invalid
func readRequestBodyFunc(writer http.ResponseWriter, request *http.Request, args *schedulerapi.ExtenderArgs) bool {
	if request.Body == nil {
		http.Error(writer, "Request body is empty", 400)
		return false
	}

	var buf bytes.Buffer
	body := io.TeeReader(request.Body, &buf)

	if err := json.NewDecoder(body).Decode(args); err != nil {
		http.Error(writer, "Request body is invalid", 400)
		return false
	}

	return true
}

// GetPriorityRequestHandleFunc returns handle function for priotity endpoint
func GetPriorityRequestHandleFunc(
	handlePriorityRequest func(args schedulerapi.ExtenderArgs) (*schedulerapi.HostPriorityList, error),
) func(http.ResponseWriter, *http.Request) {

	return func(writer http.ResponseWriter, request *http.Request) {
		var extenderArgs schedulerapi.ExtenderArgs
		if !readRequestBody(writer, request, &extenderArgs) {
			return
		}

		hostPriorityList, err := handlePriorityRequest(extenderArgs)
		if err != nil {
			log.Logger.Println(log.LogError, "Couldn't prioritize nodes: %s"+err.Error())
		}

		if responseBody, err := json.Marshal(hostPriorityList); err != nil {
			log.Logger.Println(log.LogFatal, "Couldn't create json for response: %s", err.Error())
			panic(err)
		} else {
			writer.Header().Set("Content-Type", "application/json")
			writer.WriteHeader(http.StatusOK)
			_, err := writer.Write(responseBody)
			if err != nil {
				log.Logger.Println(log.LogError, "Couldn't write response: "+err.Error())
			}
		}
	}
}

// GetPredicateRequestHandleFunc returns handle function for predicate endpoint
func GetPredicateRequestHandleFunc(
	handlePredicateRequest func(args schedulerapi.ExtenderArgs,
	) (*schedulerapi.ExtenderFilterResult, error)) func(http.ResponseWriter, *http.Request) {

	return func(writer http.ResponseWriter, request *http.Request) {
		var extenderArgs schedulerapi.ExtenderArgs
		if !readRequestBody(writer, request, &extenderArgs) {
			return
		}

		extenderFilterResult, err := handlePredicateRequest(extenderArgs)
		if err != nil {
			log.Logger.Println(log.LogError, "Couldn't filter nodes: "+err.Error())
		}

		if responseBody, err := json.Marshal(extenderFilterResult); err != nil {
			log.Logger.Println(log.LogFatal, "Couldn't create json for response: "+err.Error())
			panic(err)
		} else {
			writer.Header().Set("Content-Type", "application/json")
			writer.WriteHeader(http.StatusOK)
			_, err := writer.Write(responseBody)
			if err != nil {
				log.Logger.Println(log.LogError, "Couldn't write response: "+err.Error())
			}
		}
	}
}

// GetReloadRequestHandleFunc returns request handle function for configuration reload
func GetReloadRequestHandleFunc(c *Controller) func(http.ResponseWriter, *http.Request) {
	return func(writer http.ResponseWriter, request *http.Request) {
		c.Ossignals <- syscall.SIGHUP
		writer.WriteHeader(http.StatusAccepted)
		_, err := writer.Write([]byte("Accepted"))
		if err != nil {
			log.Logger.Println(log.LogError, "Couldn't write response: "+err.Error())
		}
	}
}

func GetVersionRequestHandleFunc(c *Controller) func(http.ResponseWriter, *http.Request) {
	return func(writer http.ResponseWriter, request *http.Request) {
		writer.WriteHeader(http.StatusOK)
		_, err := writer.Write([]byte(c.Config.Version))
		if err != nil {
			log.Logger.Println(log.LogError, "Couldn't write response: "+err.Error())
		}
	}
}
