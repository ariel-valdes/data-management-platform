/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package utils

import (
	"sort"

	v1 "k8s.io/api/core/v1"
)

func IsKeyInSortedSlice(key string, slice []string) bool {
	i := sort.Search(
		len(slice),
		func(i int) bool { return slice[i] >= key },
	)

	return i < len(slice) && slice[i] == key
}

func CheckIfPodIsScheduled(pod v1.Pod) bool {
	for _, condition := range pod.Status.Conditions {
		if condition.Type == "PodScheduled" {
			return true
		}
	}

	return false
}
