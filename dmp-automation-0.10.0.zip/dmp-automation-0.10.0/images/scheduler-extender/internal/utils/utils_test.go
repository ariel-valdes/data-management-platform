/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package utils

import (
	"testing"

	v1 "k8s.io/api/core/v1"
)

func TestIsKeyInSortedSlice(t *testing.T) {
	testSingleElementSlice(t)

	testMultipleElementSlice(t)
}

func testSingleElementSlice(t *testing.T) {
	slice := []string{"asdasd"}

	if !IsKeyInSortedSlice("asdasd", slice) {
		t.Error("False negative for valid key")
	}

	if IsKeyInSortedSlice("xcvxcv", slice) {
		t.Error("False positive for invalid key")
	}
}

func testMultipleElementSlice(t *testing.T) {
	slice := []string{"assd", "basdcsd", "hxcbfgdfg", "jasfxcvxc", "xcvbhgfh"}

	if !IsKeyInSortedSlice("jasfxcvxc", slice) {
		t.Error("False negative for valid key")
	}

	if IsKeyInSortedSlice("gcbncv,bas", slice) {
		t.Error("False positive for invalid key")
	}
}

func TestCheckIfPodIsScheduled(t *testing.T) {
	negativePod := v1.Pod{
		Status: v1.PodStatus{
			Conditions: []v1.PodCondition{
				{
					Type: "Asfxcvxcv",
				},
				{
					Type: "Asffsdgvxcv",
				},
				{
					Type: "gdfgdffxcvxcv",
				},
			},
		},
	}

	positivePod := v1.Pod{
		Status: v1.PodStatus{
			Conditions: []v1.PodCondition{
				{
					Type: "Asfxcvxcv",
				},
				{
					Type: "Asffsdgvxcv",
				},
				{
					Type: "PodScheduled",
				},
				{
					Type: "gdfgdffxcvxcv",
				},
			},
		},
	}

	if !CheckIfPodIsScheduled(positivePod) {
		t.Error("False negative for valid pod")
	}

	if CheckIfPodIsScheduled(negativePod) {
		t.Error("False positive for invalid pod")
	}
}
