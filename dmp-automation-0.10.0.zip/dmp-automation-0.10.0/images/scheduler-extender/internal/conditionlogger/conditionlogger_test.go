/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package conditionlogger

import (
	"log"
	"os"
	"testing"
)

func TestParseLoggingLevel(t *testing.T) {
	// Bad logging level string
	_, err := ParseLoggingLevel("asdasfxcbghf")
	if err == nil {
		t.Error("Logger didn't return error on bad string")
	}

	_, err = ParseLoggingLevel("")
	if err == nil {
		t.Error("Logger didn't return error on empty")
	}

	levelStrings := [...]string{"debug", "info", "warn", "error", "fatal"}
	correctlevels := [...]Level{LogDebug, LogInfo, LogWarn, LogError, LogFatal}

	for i := 0; i < len(levelStrings); i++ {
		level, err := ParseLoggingLevel(levelStrings[i])
		if err != nil {
			t.Error("Logger returned error on correct string")
		}

		if level != correctlevels[i] {
			t.Error("Logger didn't parse level correctly")
		}
	}
}

func TestGetLevelString(t *testing.T) {
	levels := [...]Level{LogDebug, LogInfo, LogWarn, LogError, LogFatal}
	correctStrings := [...]string{"debug", "info", "warn", "error", "fatal"}

	for i := 0; i < len(levels); i++ {
		level := GetLevelString(levels[i])

		if level != correctStrings[i] {
			t.Error("Logger didn't returned correct strings")
		}
	}
}

func TestModifyLoggerAttributes(t *testing.T) {
	ModifyLoggerAttributes(LogError, "testlogger", os.Stdout, log.Ltime)

	if Logger.Level != LogError {
		t.Error("Logger didn't change its level")
	}
}

func TestIsRightLevel(t *testing.T) {
	ModifyLoggerAttributes(LogError, "testlogger", os.Stdout, log.Ltime)
	if Logger.IsRightLevel(LogInfo) {
		t.Error("Logger didn't omit less severe level")
	}

	if !Logger.IsRightLevel(LogError) {
		t.Error("Logger omitted equal level")
	}

	if !Logger.IsRightLevel(LogFatal) {
		t.Error("Logger omitted more severe level")
	}
}

func TestPrintln(t *testing.T) {
	logged := false

	ModifyLoggerAttributes(LogError, "testlogger", os.Stdout, log.Ltime)

	Logger.println = func(v ...interface{}) {
		logged = true
	}

	Logger.Println(LogInfo, "Hello?")
	if logged {
		t.Error("Logger called printed despite less severe level")
	}

	Logger.Println(LogFatal, "Hello?")
	if !logged {
		t.Error("Logger did not printed despite right severity level")
	}
}
