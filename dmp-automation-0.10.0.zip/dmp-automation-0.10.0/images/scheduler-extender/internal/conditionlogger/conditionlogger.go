/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package conditionlogger

import (
	"errors"
	"io"
	"log"
	"os"
)

type Level int

var Logger *ConditionLogger

const (
	LogDebug Level = 0
	LogInfo  Level = 1
	LogWarn  Level = 2
	LogError Level = 3
	LogFatal Level = 4
)

// ConditionLogger writes if set logging level is appropriate
type ConditionLogger struct {
	log.Logger
	Level   Level
	println func(v ...interface{})
}

var (
	stringToLoggerLevel = map[string]Level{
		"debug": LogDebug,
		"info":  LogInfo,
		"warn":  LogWarn,
		"error": LogError,
		"fatal": LogFatal,
	}

	logLevelString = map[Level]string{
		LogDebug: "debug",
		LogInfo:  "info",
		LogWarn:  "warn",
		LogError: "error",
		LogFatal: "fatal",
	}

	getPrefix = func(level Level) string {
		return " (" + logLevelString[level] + "): "
	}
)

func init() {
	Logger = newConditionLogger(LogWarn, "program", os.Stdout, log.Ltime)
}

func ParseLoggingLevel(text string) (Level, error) {
	level, ok := stringToLoggerLevel[text]
	if ok {
		return level, nil
	}

	return LogDebug, errors.New("Couldn't parse logging level")
}

func GetLevelString(level Level) string {
	return logLevelString[level]
}

func ModifyLoggerAttributes(level Level, loggerName string, writer io.Writer, flags int) {
	Logger = newConditionLogger(level, loggerName, writer, flags)
}

func newConditionLogger(level Level, loggerName string, writer io.Writer, flags int) *ConditionLogger {
	clogger := &ConditionLogger{
		Logger:  *log.New(writer, loggerName, flags),
		Level:   level,
		println: nil,
	}

	clogger.println = clogger.Logger.Println

	return clogger
}

func (logger *ConditionLogger) IsRightLevel(level Level) bool {
	return level >= logger.Level
}

func (logger *ConditionLogger) Println(level Level, v ...interface{}) {
	if logger.IsRightLevel(level) {
		logger.println(getPrefix(level), v)
	}
}

// Unused right now, commented out for linter
// func (logger *ConditionLogger) Fatalln(level Level, v ...interface{}) {
// 	if logger.IsRightLevel(level) {
// 		logger.Logger.Fatalln(getPrefix(level), v)
// 	}
// }

func Fatal(v ...interface{}) {
	log.Fatal(v...)
}

// Unused right now
// func (logger *ConditionLogger) Panicln(level Level, v ...interface{}) {
// 	if logger.IsRightLevel(level) {
// 		logger.Logger.Panicln(getPrefix(level), v)
// 	}
// }
