/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package routing

import (
	"net/http"

	ctrl "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/controller"
	ctrldebug "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/controller/debug-routing"
)

type MuxWithHandleFunc interface {
	HandleFunc(pattern string, handler func(http.ResponseWriter, *http.Request))
}

// Node in routing tree
type route struct {
	resource string
	handle   func(http.ResponseWriter, *http.Request)
	children []route
}

func addRoute(mux MuxWithHandleFunc, r *route, prefix string) {
	var uri string
	if prefix == "/" {
		uri = prefix + r.resource
	} else {
		uri = prefix + "/" + r.resource
	}

	if r.handle != nil {
		mux.HandleFunc(uri, r.handle)
	}

	if r.children != nil {
		for i := range r.children {
			addRoute(mux, &r.children[i], uri)
		}
	}
}

func addRouteTree(mux MuxWithHandleFunc, root *route) {
	addRoute(mux, root, "")
}

// FillRoutes defines routes to http server
func FillRoutes(c *ctrl.Controller, mux MuxWithHandleFunc) {
	addRouteTree(
		mux,
		&route{
			resource: "",
			handle:   nil,
			children: []route{
				{
					resource: "extender",
					handle:   nil,
					children: []route{
						{
							resource: "predicates",
							handle:   nil,
							children: []route{
								{
									resource: "force-workload-failure-zone-scheduling",
									handle:   ctrl.GetPredicateRequestHandleFunc(c.HandleForcedWorkloadFailureDomainScheduling),
									children: nil,
								},
								{
									resource: "force-total-pod-spread",
									handle:   ctrl.GetPredicateRequestHandleFunc(c.HandleTotalPodSpread),
									children: nil,
								},
							},
						},
						{
							resource: "priorities",
							handle:   nil,
							children: []route{
								{
									resource: "no-priority",
									handle:   ctrl.GetPriorityRequestHandleFunc(c.HandleNoPrioritization),
									children: nil,
								},
							},
						},
					},
				},
				{
					resource: "-",
					handle:   nil,
					children: []route{
						{
							resource: "reload",
							handle:   ctrl.GetReloadRequestHandleFunc(c),
							children: nil,
						},
					},
				},
				// Special route for debugging purposes. it is not available in release build
				{
					resource: "-",
					handle:   nil,
					children: []route{
						{
							resource: "debug",
							handle:   ctrldebug.GetDebugFunc(c),
							children: nil,
						},
					},
				},
				{
					resource: "version",
					handle:   ctrl.GetVersionRequestHandleFunc(c),
					children: nil,
				},
			},
		},
	)
}
