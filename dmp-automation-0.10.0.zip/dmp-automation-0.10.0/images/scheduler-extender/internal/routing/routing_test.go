/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package routing

import (
	//"bytes"
	"net/http"
	"testing"

	"k8s.io/client-go/kubernetes/fake"

	ctrl "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/controller"
	fakeafdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client/fake"
	schedulerconfig "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/config"
)

type muxMock struct {
	routes      map[string]func(http.ResponseWriter, *http.Request)
	overwritten bool
}

func newMuxMock() *muxMock {
	return &muxMock{
		routes:      make(map[string]func(http.ResponseWriter, *http.Request)),
		overwritten: false,
	}
}

func (mux *muxMock) HandleFunc(pattern string, handler func(http.ResponseWriter, *http.Request)) {
	if _, ok := mux.routes[pattern]; ok {
		mux.overwritten = true
	}

	mux.routes[pattern] = handler
}

func simpleResponseHandler(http.ResponseWriter, *http.Request) {
}

func newTestController() *ctrl.Controller {
	clientSet := fake.NewSimpleClientset()
	assignedFDsClient := fakeafdsclient.NewFakeAssignedFDsResourceClient()
	config := schedulerconfig.GlobalConfiguration{
		FailureDomainLabelKey:                   "failureDomainKey",
		RestrictFailureDomainCountAnnotationKey: "restrictFDCountKey",
		WorkloadLabelKey:                        "workloadKey",
	}

	return ctrl.NewController(clientSet, assignedFDsClient, config)
}

func TestAddRoute(t *testing.T) {
	mux := newMuxMock()

	simpleRoot := &route{
		resource: "",
		handle:   simpleResponseHandler,
		children: nil,
	}

	// check route without children
	addRoute(mux, simpleRoot, "/")

	f, ok := mux.routes["/"]

	switch {
	case !ok:
		t.Error("Root route not added")
	case f == nil:
		t.Error("Response handler is not set")
	case len(mux.routes) > 1:
		t.Error("More than 1 route was added")
	}
}

func TestFillRoutes(t *testing.T) {
	controller := newTestController()
	mux := newMuxMock()

	FillRoutes(controller, mux)

	f, ok := mux.routes["/version"]

	switch {
	case !ok:
		t.Error("Version route not added")
	case f == nil:
		t.Error("Version route doesn't have a handler")
	}

}
