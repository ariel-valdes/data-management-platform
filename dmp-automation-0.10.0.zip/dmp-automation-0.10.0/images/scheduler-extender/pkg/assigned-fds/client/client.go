/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package client

import (
	log "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"
	afds "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/api"
	apixclient "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/runtime/serializer"
	"k8s.io/client-go/rest"
)

// CREATE CUSTOM CLIENT
type AssignedFailureDomainClientInterface interface {
	AssignedFDs(namespace string) AssignedFailureDomainInterface
}

type AssignedFailureDomainClient struct {
	restClient rest.Interface
}

var (
	schemeGroupVersion = schema.GroupVersion{
		Group:   afds.AssignedFailureDomainCRDSpecGroup,
		Version: afds.AssignedFailureDomainCRDSpecVersion,
	}

	fRESTClientFor = func(config *rest.Config) (rest.Interface, error) {
		return rest.RESTClientFor(config)
	}
)

func NewAssignedFDCRDClient(cfg *rest.Config) (AssignedFailureDomainClientInterface, error) {
	scheme, err := getScheme()
	if err != nil {
		return nil, err
	}

	config := *cfg
	config.GroupVersion = &schemeGroupVersion
	config.APIPath = "/apis"
	config.ContentType = runtime.ContentTypeJSON
	config.NegotiatedSerializer = serializer.DirectCodecFactory{CodecFactory: serializer.NewCodecFactory(scheme)}

	client, err := fRESTClientFor(&config)
	if err != nil {
		return nil, err
	}

	return &AssignedFailureDomainClient{restClient: client}, nil
}

func getScheme() (*runtime.Scheme, error) {
	scheme := runtime.NewScheme()
	schemeBuilder := runtime.NewSchemeBuilder(addKnownTypes)
	if err := schemeBuilder.AddToScheme(scheme); err != nil {
		return nil, err
	}

	return scheme, nil
}

func addKnownTypes(scheme *runtime.Scheme) error {
	scheme.AddKnownTypes(
		schemeGroupVersion,
		&afds.AssignedFailureDomain{},
		&afds.AssignedFailureDomainList{},
	)

	metav1.AddToGroupVersion(scheme, schemeGroupVersion)

	return nil
}

func (c *AssignedFailureDomainClient) AssignedFDs(namespace string) AssignedFailureDomainInterface {
	return &assignedFailureDomainClient{
		client: c.restClient,
		ns:     namespace,
	}
}

type AssignedFailureDomainInterface interface {
	Create(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error)
	Update(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error)
	Delete(name string, options *metav1.DeleteOptions) error
	Get(name string) (*afds.AssignedFailureDomain, error)
	GetByOwner(owner string, ownerKind string) (*afds.AssignedFailureDomain, error)
}

type assignedFailureDomainClient struct {
	client rest.Interface
	ns     string
}

func (c *assignedFailureDomainClient) Create(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error) {
	result := &afds.AssignedFailureDomain{}
	err := c.client.Post().
		Namespace(c.ns).
		Resource(afds.AssignedFailureDomainCRDSpecNamesPlural).
		Body(obj).
		Do().
		Into(result)

	return result, err
}

func (c *assignedFailureDomainClient) Update(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error) {
	result := &afds.AssignedFailureDomain{}
	err := c.client.Put().
		Namespace(c.ns).
		Resource(afds.AssignedFailureDomainCRDSpecNamesPlural).
		Body(obj).
		Do().
		Into(result)

	return result, err
}

func (c *assignedFailureDomainClient) Delete(name string, options *metav1.DeleteOptions) error {
	return c.client.Delete().
		Namespace(c.ns).
		Resource(afds.AssignedFailureDomainCRDSpecNamesPlural).
		Name(name).
		Body(options).
		Do().
		Error()
}

func (c *assignedFailureDomainClient) Get(name string) (*afds.AssignedFailureDomain, error) {
	result := &afds.AssignedFailureDomain{}
	err := c.client.Get().
		Namespace(c.ns).
		Resource(afds.AssignedFailureDomainCRDSpecNamesPlural).
		Name(name).
		Do().
		Into(result)

	return result, err
}

func (c *assignedFailureDomainClient) GetByOwner(
	ownerName string,
	ownerKind string) (*afds.AssignedFailureDomain, error) {
	return c.Get(afds.ConstructAssignedFDName(ownerName, ownerKind))
}

func RegisterAssignedFDCRD(apixClient apixclient.Interface) error {
	crds := apixClient.ApiextensionsV1beta1().CustomResourceDefinitions()
	_, err := crds.Create(&afds.AssignedFailureDomainCRD)
	if err != nil {
		if errors.IsAlreadyExists(err) {
			log.Logger.Println(log.LogDebug, "Custom CRD already exists")
		} else {
			return err
		}
	}

	return nil
}
