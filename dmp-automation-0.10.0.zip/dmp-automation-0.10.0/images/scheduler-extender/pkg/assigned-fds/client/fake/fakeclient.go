/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package assignedfdsclient

import (
	afds "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/api"
	fakedclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
)

// CREATE CUSTOM CLIENT

type AssignedFailureDomainFakeClient struct {
}

func newFakeClient() *AssignedFailureDomainFakeClient {
	return &AssignedFailureDomainFakeClient{}
}

var (
	namespaceClients map[string]*assignedFailureDomainFakeClient
)

func NewFakeAssignedFDsResourceClient() fakedclient.AssignedFailureDomainClientInterface {
	namespaceClients = make(map[string]*assignedFailureDomainFakeClient)
	return newFakeClient()
}

// CRD CLIENT INTERNALS
func (c *AssignedFailureDomainFakeClient) AssignedFDs(namespace string) fakedclient.AssignedFailureDomainInterface {
	var client *assignedFailureDomainFakeClient

	client, exist := namespaceClients[namespace]
	if !exist {
		client = &assignedFailureDomainFakeClient{
			ns:            namespace,
			storedObjects: make(map[string]*afds.AssignedFailureDomain),
		}

		namespaceClients[namespace] = client
	}

	return client
}

type assignedFailureDomainFakeClient struct {
	ns string
	// Maping name -> custom resource
	storedObjects map[string]*afds.AssignedFailureDomain
}

func (c *assignedFailureDomainFakeClient) Create(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error) {
	_, exist := c.storedObjects[obj.ObjectMeta.Name]
	if exist {
		return nil, apierrors.NewAlreadyExists(schema.GroupResource{}, afds.AssignedFailureDomainCRDSpecNamesSingular)
	}

	copy := &afds.AssignedFailureDomain{}
	obj.DeepCopyInto(copy)
	c.storedObjects[obj.ObjectMeta.Name] = copy

	return copy, nil
}

func (c *assignedFailureDomainFakeClient) Update(obj *afds.AssignedFailureDomain) (*afds.AssignedFailureDomain, error) {
	storedObj, exist := c.storedObjects[obj.ObjectMeta.Name]
	if !exist {
		return nil, apierrors.NewNotFound(schema.GroupResource{}, afds.AssignedFailureDomainCRDSpecNamesSingular)
	}

	obj.DeepCopyInto(storedObj)

	return storedObj, nil
}

func (c *assignedFailureDomainFakeClient) Delete(name string, options *metav1.DeleteOptions) error {
	if _, exist := c.storedObjects[name]; !exist {
		return apierrors.NewNotFound(schema.GroupResource{}, afds.AssignedFailureDomainCRDSpecNamesSingular)
	}
	delete(c.storedObjects, name)

	return nil
}

func (c *assignedFailureDomainFakeClient) Get(name string) (*afds.AssignedFailureDomain, error) {
	storedObj, exist := c.storedObjects[name]
	if !exist {
		return nil, apierrors.NewNotFound(schema.GroupResource{}, afds.AssignedFailureDomainCRDSpecNamesSingular)
	}

	return storedObj, nil
}

func (c *assignedFailureDomainFakeClient) GetByOwner(
	ownerName string,
	ownerKind string) (*afds.AssignedFailureDomain, error) {

	return c.Get(afds.ConstructAssignedFDName(ownerName, ownerKind))
}
