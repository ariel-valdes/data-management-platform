/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package client

import (
	// "bytes"
	"io/ioutil"
	"net/http"
	"strings"
	"testing"

	afds "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/api"
	apixclientfake "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset/fake"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/rest"
	fakerest "k8s.io/client-go/rest/fake"
)

// NewAssignedFDCRDClient:
// - save func RESTClientFor to variable
// - save func getScheme to variable

// getScheme:
// - newScheme to variable
// - NewSchemeBuilder to variable
// - AddToScheme to variable

func newFakeRESTClient(cfg *rest.Config) rest.Interface {
	return &fakerest.RESTClient{
		GroupVersion:         *cfg.GroupVersion,
		NegotiatedSerializer: cfg.NegotiatedSerializer,
		VersionedAPIPath:     cfg.APIPath,
		Client: fakerest.CreateHTTPClient(func(req *http.Request) (*http.Response, error) {
			return &http.Response{
				StatusCode: http.StatusOK,
				Body:       ioutil.NopCloser(strings.NewReader("{}")),
			}, nil
		}),
	}
}

func fakeRegisterCRD(t *testing.T) {
	schemaClient := apixclientfake.NewSimpleClientset()

	err := RegisterAssignedFDCRD(schemaClient)
	if err != nil {
		t.Error("Couldn't mock register CRD: ", err.Error())
	}
}

func TestNewAssignedFDCRDClient(t *testing.T) {
	fRESTClientFor = func(config *rest.Config) (rest.Interface, error) {
		return newFakeRESTClient(config), nil
	}

	client, err := NewAssignedFDCRDClient(&rest.Config{})
	if err != nil {
		t.Error("Couldn't create fake interface: ", err.Error())
	}

	fakeRegisterCRD(t)

	c, ok := client.AssignedFDs("namespace").(*assignedFailureDomainClient)
	if !ok {
		t.Error("Cannot specialize interface")
	}

	result, err := c.Create(afds.NewAssignedFailureDomain("owner", "Kind", []string{"rack1", "rack2"}))
	if err != nil || result == nil {
		t.Error("Error creating the resource: ", err.Error())
	}

	result, err = c.Update(afds.NewAssignedFailureDomain("owner", "Kind", []string{"rack1", "rack4"}))
	if err != nil || result == nil {
		t.Error("Error updating the resource: ", err.Error())
	}

	result, err = c.Get("owner-kind")
	if err != nil || result == nil {
		t.Error("Error getting the resource: ", err.Error())
	}

	err = c.Delete("owner-kind", &metav1.DeleteOptions{})
	if err != nil {
		t.Error("Error deleting the resource: ", err.Error())
	}

}
