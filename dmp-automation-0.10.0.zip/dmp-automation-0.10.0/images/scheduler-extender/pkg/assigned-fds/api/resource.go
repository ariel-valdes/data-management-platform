/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package resource

import (
	"strings"

	apix "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1beta1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
)

const (
	AssignedFailureDomainCRDSpecNamesPlural   = "failure-domain-assignments"
	AssignedFailureDomainCRDSpecNamesSingular = "failure-domain-assignment"
	AssignedFailureDomainCRDSpecNamesKind     = "AssignedFailureDomain"
	AssignedFailureDomainCRDSpecGroup         = "dmp.intel.com"
	AssignedFailureDomainCRDSpecVersion       = "v1"
	AssignedFailureDomainCRDObjectName        = AssignedFailureDomainCRDSpecNamesPlural +
		"." + AssignedFailureDomainCRDSpecGroup
)

var (
	AssignedFailureDomainCRD = apix.CustomResourceDefinition{
		ObjectMeta: metav1.ObjectMeta{
			Name: AssignedFailureDomainCRDObjectName,
		},
		Spec: apix.CustomResourceDefinitionSpec{
			Group: AssignedFailureDomainCRDSpecGroup,
			// NOTE: Deprecated, change this after upgrade
			Version: AssignedFailureDomainCRDSpecVersion,
			Names: apix.CustomResourceDefinitionNames{
				Plural:   AssignedFailureDomainCRDSpecNamesPlural,
				Singular: AssignedFailureDomainCRDSpecNamesSingular,
				Kind:     AssignedFailureDomainCRDSpecNamesKind,
			},
			Scope: apix.NamespaceScoped,
		},
	}
)

// CRD
type AssignedFailureDomain struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec AssignedFailureDomainSpec `json:"spec"`
}

type AssignedFailureDomainSpec struct {
	OwnerKind string   `json:"owner_kind"`
	Owner     string   `json:"owner"`
	OwnedFDs  []string `json:"owned_cds"`
}

func ConstructAssignedFDName(ownerName string, ownerKind string) string {
	return ownerName + "-" + strings.ToLower(ownerKind)
}

func NewAssignedFailureDomain(ownerName string, ownerKind string, ownedFds []string) *AssignedFailureDomain {
	return &AssignedFailureDomain{
		ObjectMeta: metav1.ObjectMeta{
			Name: ConstructAssignedFDName(ownerName, ownerKind),
		},
		Spec: AssignedFailureDomainSpec{
			Owner:     ownerName,
			OwnedFDs:  ownedFds,
			OwnerKind: ownerKind,
		},
	}
}

// Implements k8s.io/apimachinery/pkg/runtime.Object
func (in *AssignedFailureDomain) DeepCopyInto(out *AssignedFailureDomain) {
	out.TypeMeta = in.TypeMeta
	out.ObjectMeta = in.ObjectMeta
	out.Spec = AssignedFailureDomainSpec{
		Owner:     in.Spec.Owner,
		OwnedFDs:  in.Spec.OwnedFDs,
		OwnerKind: in.Spec.OwnerKind,
	}
}

func (in *AssignedFailureDomain) DeepCopyObject() runtime.Object {
	out := AssignedFailureDomain{}
	in.DeepCopyInto(&out)

	return &out
}

type AssignedFailureDomainList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata"`
	Items           []AssignedFailureDomain `json:"items"`
}

func (in *AssignedFailureDomainList) DeepCopyObject() runtime.Object {
	out := AssignedFailureDomainList{}
	out.TypeMeta = in.TypeMeta
	out.ListMeta = in.ListMeta

	if in.Items != nil {
		out.Items = make([]AssignedFailureDomain, len(in.Items))
		for i := range in.Items {
			in.Items[i].DeepCopyInto(&out.Items[i])
		}
	}

	return &out
}
