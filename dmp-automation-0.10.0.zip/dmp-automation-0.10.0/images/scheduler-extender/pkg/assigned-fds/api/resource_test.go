/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package resource

import (
	"sort"
	"testing"
)

func TestConstructAssignedFDName(t *testing.T) {
	if name := ConstructAssignedFDName("owner", "Kind"); name != "owner-kind" {
		t.Error("Invalid assigned name")
	}
}

func compareSets(left []string, right []string) bool {
	if left == nil && right != nil {
		return false
	} else if left != nil && right == nil {
		return false
	}

	if len(left) != len(right) {
		return false
	}

	sort.Slice(left, func(i, j int) bool { return left[i] < left[j] })
	sort.Slice(right, func(i, j int) bool { return right[i] < right[j] })

	for i := 0; i < len(left); i++ {
		if left[i] != right[i] {
			return false
		}
	}

	return true
}

func validateAssignedFailureDomain(
	domain *AssignedFailureDomain, name string, owner string, kind string, ownedfds []string) bool {
	return domain != nil &&
		domain.ObjectMeta.Name == name &&
		domain.Spec.Owner == owner &&
		compareSets(ownedfds, domain.Spec.OwnedFDs) &&
		domain.Spec.OwnerKind == kind
}

func TestNewAssignedFailureDomain(t *testing.T) {
	if domain := NewAssignedFailureDomain("owner", "Kinder", []string{"rack1", "rack3"}); !validateAssignedFailureDomain(
		domain, "owner-kinder", "owner", "Kinder", []string{"rack1", "rack3"},
	) {

		t.Error("Constructor for AssignedFailureDomain returned unexpected struct")
	}
}

func TestDeepCopyInto(t *testing.T) {
	out := AssignedFailureDomain{}
	in := NewAssignedFailureDomain("owner", "Kind", []string{"rack1", "rack3"})

	in.DeepCopyInto(&out)

	if !validateAssignedFailureDomain(&out, "owner-kind", "owner", "Kind", []string{"rack1", "rack3"}) {
		t.Error("DeepCopiedObject doesn't meet expectations")
	}
}

func TestDeepCopyObject(t *testing.T) {
	in := NewAssignedFailureDomain("owner", "Kind", []string{"rack1", "rack3"})

	out, ok := in.DeepCopyObject().(*AssignedFailureDomain)

	if !ok || !validateAssignedFailureDomain(out, "owner-kind", "owner", "Kind", []string{"rack1", "rack3"}) {
		t.Error("DeepCopyObject doesn't meet expectations")
	}
}

func TestListDeepCopyObject(t *testing.T) {
	in := AssignedFailureDomainList{
		Items: []AssignedFailureDomain{
			*NewAssignedFailureDomain("owner", "Kind", []string{"rack1", "rack3"}),
			*NewAssignedFailureDomain("owner2", "Kind", []string{"rack1", "rack2"}),
		},
	}

	out, ok := in.DeepCopyObject().(*AssignedFailureDomainList)

	if !ok || len(out.Items) != 2 ||
		!validateAssignedFailureDomain(&out.Items[0], "owner-kind", "owner", "Kind", []string{"rack1", "rack3"}) ||
		!validateAssignedFailureDomain(&out.Items[1], "owner2-kind", "owner2", "Kind", []string{"rack1", "rack2"}) {

		t.Error("AssignedFailureDomainList.DeepCopyObject doesn't meet expectations")
	}
}
