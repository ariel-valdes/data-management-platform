/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package schedulerconfig

import (
	"io/ioutil"
	"log"
	"os"

	clog "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"

	"gopkg.in/yaml.v2"
)

type GlobalConfiguration struct {
	NodeNameLabelKey                        string `yaml:"nodeNameLabelKey"`
	SchedulerName                           string `yaml:"schedulerName"`
	GlobalWorkload                          bool   `yaml:"globalWorkload"`
	DefaultRestrictedCount                  int64  `yaml:"defaultRestrictedCount"`
	RestrictFailureDomainCountAnnotationKey string `yaml:"restrictFDCountKey"`
	WorkloadLabelKey                        string `yaml:"workloadKey"`
	FailureDomainLabelKey                   string `yaml:"failureDomainKey"`
	Address                                 string `yaml:"address"`
	Port                                    string `yaml:"port"`
	LogLevel                                string `yaml:"logLevel"`
	Version                                 string
	Timeout                                 int64 `yaml:"timeout"`
}

const (
	// CertFilePath is a path to certificate file for the extender server
	CertFilePath = "/etc/scheduler-extender/server.crt"
	// KeyFilePath is a private key file path for the extender server
	KeyFilePath = "/etc/scheduler-extender/server.key"

	configFilePath = "/etc/scheduler-extender/config.yaml"
)

var (
	readFile = ioutil.ReadFile

	// LoadConfiguration gets and loads all available configuration
	LoadConfiguration = loadConfiguration
)

func loadConfiguration() GlobalConfiguration {
	config := loadYamlConfiguration()
	config.Version = os.Getenv("SCHEDULER_VERSION")

	if err := loadLoggerConfiguration(&config); err != nil {
		log.Panic(err.Error())
	}

	return config
}

func loadLoggerConfiguration(config *GlobalConfiguration) error {
	logLevel, err := clog.ParseLoggingLevel(config.LogLevel)
	if err != nil {
		return err
	}

	clog.ModifyLoggerAttributes(logLevel, "scheduler-extender", os.Stdout, log.Ltime)

	return nil
}

// Load configuration from yaml file
func loadYamlConfiguration() GlobalConfiguration {
	yamlFile, err := readFile(configFilePath)
	if err != nil {
		log.Panic(err.Error())
	}

	config := GlobalConfiguration{}

	err = yaml.Unmarshal(yamlFile, &config)
	if err != nil {
		log.Panic(err.Error())
	}

	return config
}
