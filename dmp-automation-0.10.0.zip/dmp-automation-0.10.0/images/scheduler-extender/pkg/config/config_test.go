/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package schedulerconfig

import (
	"bytes"
	"log"
	"os"
	"testing"
)

const badLoggingLevel = `---
restrictFDCountKey: "dmp/failure-domain-count"
nodeNameLabelKey: "kubernetes.io/hostname"
workloadKey: "dmp/workload"
failureDomainKey: "failure-domain.beta.kubernetes.io/zone"
address: ""
timeout: 100
port: "8080"
logLevel: "2debug"`

const properFile = `---
restrictFDCountKey: "dmp/failure-domain-count"
nodeNameLabelKey: "kubernetes.io/hostname"
workloadKey: "dmp/workload"
failureDomainKey: "failure-domain.beta.kubernetes.io/zone"
address: ""
timeout: 100
port: "8080"
logLevel: "debug"`

var mockedFile = properFile

const mockVersion = "v1.0alpha"

func checkIfConfig(config GlobalConfiguration) bool {
	return config.NodeNameLabelKey == "kubernetes.io/hostname" &&
		config.RestrictFailureDomainCountAnnotationKey == "dmp/failure-domain-count" &&
		config.WorkloadLabelKey == "dmp/workload" &&
		config.FailureDomainLabelKey == "failure-domain.beta.kubernetes.io/zone" &&
		config.Address == "" &&
		config.Port == "8080" &&
		config.LogLevel == "debug" &&
		config.Version == mockVersion &&
		config.Timeout == 100
}

func mockReadFile(path string) ([]byte, error) {
	return []byte(mockedFile), nil
}

func checkForParseLevel() (panicked bool) {
	var buf bytes.Buffer
	log.SetOutput(&buf)

	panicked = false

	defer func() {
		if r := recover(); r != nil {
			panicked = true
			log.SetOutput(os.Stderr)
		}
	}()

	mockedFile = badLoggingLevel
	loadConfiguration()
	log.SetOutput(os.Stderr)

	return
}

func TestLoadConfiguration(t *testing.T) {
	os.Setenv("SCHEDULER_VERSION", mockVersion)

	readFile = mockReadFile

	config := loadConfiguration()
	if !checkIfConfig(config) {
		t.Error("Config didn't match the expectations")
	}

	if !checkForParseLevel() {
		t.Error("Config didn't panic on bad logging level")
	}
}
