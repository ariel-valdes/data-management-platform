/*
Intel OBL Pre-Release Software (Internal Use)
Copyright © 2019 Intel Corporation

For licensing information, see the file 'LICENSE'
in the root folder of this software module.
*/

package main

import (
	"net/http"
	"time"

	log "gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/conditionlogger"
	"gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/controller"
	"gitlab.devtools.intel.com/intelsds/scheduler-extender/internal/routing"
	afdsclient "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/assigned-fds/client"
	schedulerconfig "gitlab.devtools.intel.com/intelsds/scheduler-extender/pkg/config"
	apiextension "k8s.io/apiextensions-apiserver/pkg/client/clientset/clientset"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
)

func getInClusterConfig() *rest.Config {
	config, err := rest.InClusterConfig()
	if err != nil {
		panic(err.Error())
	}

	return config
}

// Get kubernetes go client
func getK8sClient(clientConfig *rest.Config) kubernetes.Interface {
	clientSet, err := kubernetes.NewForConfig(clientConfig)
	if err != nil {
		panic(err.Error())
	}

	return clientSet
}

func getAPIExtensionClient(clientConfig *rest.Config) *apiextension.Clientset {
	clientSet, err := apiextension.NewForConfig(clientConfig)
	if err != nil {
		panic(err.Error())
	}

	return clientSet
}

func getAssignedFDCRDClinet(clientConfig *rest.Config) afdsclient.AssignedFailureDomainClientInterface {
	clientset, err := afdsclient.NewAssignedFDCRDClient(clientConfig)
	if err != nil {
		panic(err.Error())
	}

	return clientset
}

func main() {
	config := schedulerconfig.LoadConfiguration()

	restConfig := getInClusterConfig()

	kubeClientset := getK8sClient(restConfig)
	apixClientset := getAPIExtensionClient(restConfig)

	err := afdsclient.RegisterAssignedFDCRD(apixClientset)
	if err != nil {
		panic(err.Error())
	}

	// Wait for crd registration
	time.Sleep(5 * time.Second)
	assignedFDClient := getAssignedFDCRDClinet(restConfig)

	ctrl := controller.NewController(kubeClientset, assignedFDClient, config)

	ctrl.StartGoroutines()

	mux := http.NewServeMux()

	routing.FillRoutes(ctrl, mux)

	endpoint := config.Address + ":" + config.Port
	log.Logger.Println(log.LogInfo, "Starting listening on endpoint: "+endpoint)

	if err := http.ListenAndServeTLS(
		endpoint, schedulerconfig.CertFilePath, schedulerconfig.KeyFilePath, mux,
	); err != nil {
		log.Fatal(err)
	}
}
