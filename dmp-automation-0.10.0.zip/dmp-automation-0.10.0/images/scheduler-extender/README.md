DMP scheduler extender
===
This image contains DMP scheduler extender.
Extender is a custom API endpoint plugin that kubernetes scheduler calls during 
scheduling [pipeline](https://github.com/kubernetes/community/blob/master/contributors/devel/sig-scheduling/scheduler.md).
Directory */examples* contains example deployments on separate scheduler and an example pod manifest using that scheduler.

# Predicates
## Force workload failure zone scheduling
uri resource name: ```force-workload-failure-zone-scheduling```

Forces uniform spread of pods from a single workload and namespace over cluster's failure domains. However, it doesn't enforce uniform spread over nodes inside chosen failure domain, instead leaving it to kuberenetes's best effort algorithm.

To accomplish this, extender gathers information about all viable pods.
It uses this information to count number of pods in each of cluster's failure domains. From this calculated statistic it finds a minimum.
In final step it discards any nodes from failure domain's which count was not minimal. 

## Force total pod spread
uri resource name: ```force-total-pod-spread```

This predicate accomplishes the same thing as the previous predicate, but it enforces also 
uniform spread inside a failure domain. This is equivalent to calling the extender twice,
but with failure domain label configured to the node's name label.

# Priorities
## No priority
uri resource name: ```no-priority```

Simple priority that returns 0 for every pod.

# Routes
* **/version** - best used for an alive check
* **/-/reload** - reloads configuration. 
* **/extender/predicates/\<predicate\>** - predicate URI
* **/extender/priorities\<priority\>** - priority URI

# How does extender searches for viable pods

Extender can be configured to search for pods with a limited scope.
From the broadest to smallest scope:
* global - searches all pods that have the same scheduler
* namespace - default if nothing is specified, searches all pods in the namespace with the same  scheduler 
* workload specified - searches all pods from across namespaces with the same workload label and with the same  scheduler

Scopes have the following precedence:
* workload label if pod to be scheduled has one
* global if extender is configured to be use one
* namespace

# Configuration
Configuration can be reloaded by curling "/-/reload" URI or sending SIGHUP to the extender's process

## YAML:
* **workloadKey** - pod's label key that describes its workload and limits search scope
* **restrictFDCountKey** - pod's annotation key that restricts on how many failure domains pod can be scheduled.
* **failureDomainKey** - node's label key that describes its failure domain. 
Has to be defined on all nodes, otherwise predicate logs error.
* **nodeNameLabelKey** - label key that identifies node. Required.
* **address** - extender's ip address. Leave empty if all of container's interfaces are to listen for requests.
* **port** - extender's port
* **logLevel** - log level, possible values: debug, info, warn, error and fatal
* **globalWorkload** - if set to true then it broadens default scope to all namespaces
* **schedulerName** - scheduler name. Only pods that request to be scheduled from this scheduler are considered
* **defaultRestrictedCount** - if nonzero then extender by default assigns specified number of failure domains to pod owner (like daemonset or replication controller)
* **timeout** - sets timeout for extender requests. In seconds. By default not timeout is given.


## ENV:
* **SCHEDULER_VERSION** - extender's version

# Custom resources

## Assigned Failure Domains
Assigned failure domains custom resource is used to assign failure domains to pod controllers. It is necessary for restricting number of failure domains to a controller.

### CRD
```yaml
- apiVersion: apiextensions.k8s.io/v1beta1
  kind: CustomResourceDefinition
  metadata:
    name: failure-domain-assignments.dmp.intel.com
    namespace: ""
    selfLink: /apis/apiextensions.k8s.io/v1beta1/customresourcedefinitions/failure-domain-assignments.dmp.intel.com
  spec:
    group: dmp.intel.com
    names:
      kind: AssignedFailureDomain
      listKind: AssignedFailureDomainList
      plural: failure-domain-assignments
      singular: failure-domain-assignment
    scope: Namespaced
    version: v1
```

### Example instance
```yaml
- apiVersion: dmp.intel.com/v1
  kind: AssignedFailureDomain
  metadata:
    name: nginx-deployment-59b4d8ccdc-replicaset
    namespace: default
    selfLink: /apis/dmp.intel.com/v1/namespaces/default/failure-domain-assignments/nginx-deployment-59b4d8ccdc-replicaset
  spec:
    owned_cds:
    - rack2
    - rack3
    owner: nginx-deployment-59b4d8ccdc
    owner_kind: ReplicaSet
```


# Examples
Example scenarios showing different use-cases for extender

## Basic example 

### extender.yaml
Creates extender with a separate scheduler with necessary privileges. It creates three config maps of which **dmp-scheduler-extender-config** tunes extender. 

### simple-example.yaml
Example deployment, which goal is to schedule single pod with force-workload-failure-zone-scheduling scheduling predicate. Features minimal configuration necessary for working with extender.

## Restricted spread example

### extender.yaml
Creates extender with a separate scheduler with necessary privileges. It creates three config maps of which **dmp-scheduler-extender-config** tunes extender. 

### count-restriction.yaml
Example deployment, which goal is to schedule *deployment* controller's pods over limited count of failure domains. In contrast to the previous example, scheduler references force-total-pod-spread predicate.

# Testing
To run test you must install [golangci-lint](https://github.com/golangci/golangci-lint/).
