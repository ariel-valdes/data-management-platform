#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import argparse
import http.server
import logging
import subprocess
import sys

from prometheus_client.core import CounterMetricFamily, REGISTRY
from prometheus_client.exposition import MetricsHandler

EXECUTION_CMD = ["dmstats", "report"]

LABELS = [
    "device_name",
    "group_id",
    "region_id",
    "object_type",
    "area_id",
    "area_start",
]

COUNTER_PREFIX = "dm"

COUNTERS = [
    "area_size_in_mb",
    "reads_merged_per_sec",
    "writes_merged_per_sec",
    "reads_per_sec",
    "writes_per_sec",
    "read_size_per_sec_in_mb",
    "write_size_per_sec_in_mb",
    "avg_request_size_in_mb",
    "queue_size",
    "utilization_in_percentage",
    "avg_wait_time",
    "avg_read_time",
    "avg_write_time",
]


class DMStatsExporter(object):
    def __init__(self, log_level):
        self.logger = logging.getLogger("DMStatsExporter")
        self.logger.setLevel(log_level)
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(log_level)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
        self._labels = LABELS
        self._counters = COUNTERS
        self._execution_cmd = EXECUTION_CMD
        self.metric_families = {}
        self.logger.info("DMStatsExporter object initialized.")

    def collect(self):
        self.metric_families = {}

        # interface info
        self.get_stats()
        self.logger.debug("Metrics collected: {}".format(self.metric_families))

        for metric in self.metric_families:
            yield self.metric_families[metric]

    def get_stats(self):
        try:
            data = subprocess.check_output(self._execution_cmd).decode()
        except subprocess.CalledProcessError as err:
            self.logger.error(
                "Execution of dmstats report returned {}.".format(err.returncode)
            )
            sys.exit()
        if not data:
            self.logger.warning("There is no device to track.")
            return
        # Remove first line - it's a header
        for line in data.splitlines()[1:]:
            values = line.split()
            labels = self.prepare_labels(values)
            counters = self.prepare_counters(values)
            for counter_name, value in counters:
                self.add_counter_metric(counter_name, "", labels, value)

    def prepare_labels(self, values):
        labels = []
        for label, value in zip(self._labels, values[: len(self._labels)]):
            labels.append((label, value))

        return labels

    def _convert_size(self, size):
        value = float(size[:-1])
        unit = size[-1]
        if unit == "m":
            return value
        elif unit == "t":
            return value * 1024 * 1024
        elif unit == "g":
            return value * 1024
        elif unit == "k":
            return value / 1024
        else:
            self.logger.error("Unsupported unit: {}.".format(unit))
            sys.exit(1)

    def prepare_counters(self, values):
        counters = []
        for counter_name, value in zip(self._counters, values[len(self._labels):]):
            name = "_".join([COUNTER_PREFIX, counter_name])
            try:
                value = float(value)
            except ValueError:
                self.logger.debug(
                    "Converting metric: {} w/ value: {}".format(counter_name, value)
                )
                value = self._convert_size(value)
            counters.append((name, value))

        return counters

    def add_counter_metric(self, name, documentation, labels, value):
        if name not in self.metric_families:
            label_names = [label[0] for label in labels]
            self.metric_families[name] = CounterMetricFamily(
                name, documentation, labels=label_names
            )
        label_values = [label[1] for label in labels]
        self.metric_families[name].add_metric(label_values, value)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", "-p", type=int, help="Port to bind.", default=9420)
    parser.add_argument(
        "--verbosity",
        "-v",
        type=str,
        help="Log level.",
        default="debug",
        choices=["debug", "info"],
    )
    args = parser.parse_args()
    log_level = logging.DEBUG if args.verbosity == "debug" else logging.INFO
    port = args.port
    print("Starting DMStatsExporter - bound port={}".format(port))

    try:
        REGISTRY.register(DMStatsExporter(log_level))
        httpd = http.server.HTTPServer(("", port), MetricsHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.exit()
