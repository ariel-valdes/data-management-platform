#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import argparse
import http.server
import json
import logging
import re
import subprocess
import sys
from typing import NamedTuple, List, Tuple

from prometheus_client.core import GaugeMetricFamily, REGISTRY
from prometheus_client.exposition import MetricsHandler

NAMESPACE = "smart"


def convert_to_name(description):
    name = description.lower()
    name = re.sub(r"[^a-z\s]", "", name)
    name = re.sub(r"\s+", "_", name)
    return name


class MetricTuple(NamedTuple):
    name: str
    value: int
    description: str
    labels: List[Tuple[str, str]]


class ISDCTExporter:
    def __init__(self, logger):
        self._families = {}
        self._logger = logger
        self._logger.info("ISDCTExporter object initialized.")

        self._devices = {
            device["Index"]: device["DevicePath"].split("/")[-1]
            for device in self._call(
                ["isdct", "show", "-o", "json", "-intelssd"]
            ).values()
        }
        self._logger.info("Device list collected.")

        if not self._devices:
            self._logger.error("No devices found.")
            sys.exit(1)

    def get_metrics(self) -> List[MetricTuple]:
        metrics = []

        for index, name in self._devices.items():
            data = self._call(
                ["isdct", "show", "-o", "json", "-smart", "-intelssd", str(index)]
            )
            smart = list(data.values())[0]

            for attr in smart.values():
                desc = attr["Description"]
                metric_name = convert_to_name(desc)
                metric = MetricTuple(
                    metric_name,
                    attr["Raw"],
                    desc,
                    [
                        ("device", name),
                        ("id", attr["ID"]),
                        ("normalized", attr["Normalized"]),
                        ("status", attr["Status"] if "Status" in attr.keys() else None),
                        ("threshold", attr["Threshold"] if "Threshold" in attr.keys() else None),
                        ("worst", attr["Worst"] if "Worst" in attr.keys() else None),
                    ],
                )
                metrics.append(metric)

        return metrics

    def collect(self):
        families = {}
        for metric in self.get_metrics():
            if metric.name not in families:
                label_names = [label[0] for label in metric.labels]
                family = GaugeMetricFamily(
                    f"{NAMESPACE}_{metric.name}", metric.description, labels=label_names
                )
                families[metric.name] = family
            else:
                family = families[metric.name]
            label_values = [str(label[1]) for label in metric.labels]
            family.add_metric(label_values, metric.value)

        for family in families.values():
            yield family

    def _call(self, command):
        try:
            data = subprocess.check_output(command)
            return json.loads(data)
        except subprocess.CalledProcessError as err:
            command_string = " ".join(command)
            self._logger.error(f"`{command_string}` returned {err}.")
            sys.exit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", "-p", type=int, help="Port to bind.", default=9421)
    parser.add_argument(
        "--verbosity",
        "-v",
        type=str,
        help="Log level.",
        default="debug",
        choices=["debug", "info"],
    )
    args = parser.parse_args()
    logger = logging.getLogger("ISDCTExporter")
    log_level = logging.DEBUG if args.verbosity == "debug" else logging.INFO
    logger.setLevel(log_level)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(log_level)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    port = args.port
    print("Starting ISDCTExporter - bound port={}".format(port))
    try:
        REGISTRY.register(ISDCTExporter(logger))
        httpd = http.server.HTTPServer(("", port), MetricsHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.exit()


if __name__ == "__main__":
    main()
