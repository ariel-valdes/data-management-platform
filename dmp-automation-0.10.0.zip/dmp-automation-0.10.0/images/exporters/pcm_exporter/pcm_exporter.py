#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import argparse
import http.server
import logging
import os
import subprocess
import sys
import time

from prometheus_client.core import CounterMetricFamily, REGISTRY
from prometheus_client.exposition import MetricsHandler

LOG_PATH = "/tmp/pcm.log"


class PCMExporter(object):
    def __init__(self, pcm_log_level):
        self.logger = logging.getLogger("PCMExporter")
        self.logger.setLevel(pcm_log_level)
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(pcm_log_level)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
        self.pcm_log_path = LOG_PATH
        self.labels = []
        self.metrics = []
        self.metric_families = {}
        self.fetch_labels_and_metrics()
        self.logger.info("PCMExporter object initialized.")

    def fetch_labels_and_metrics(self):
        if not os.path.exists(self.pcm_log_path):
            self.logger.warning("There is no PCM log file.")
            return
        with open(self.pcm_log_path, "r") as csv_file:
            labels_line = csv_file.readline()
            metrics_line = csv_file.readline()
        self.labels = self.adjust_labels(labels_line.rstrip("\n").split(";")[2:])
        self.metrics = self.adjust_metrics_names(
            metrics_line.rstrip("\n").split(";")[2:]
        )
        self.logger.info("Labels and metrics names fetched.")

    @staticmethod
    def data_processing(values):
        new_values = []
        for value in values:
            new_values.append(float(value.lstrip()))
        return new_values

    @staticmethod
    def adjust_labels(labels):
        new_labels = []
        for label in labels:
            tmp_label = label.replace("SKT", "Socket")
            new_labels.append(tmp_label)
        return new_labels

    @staticmethod
    def adjust_metrics_names(metrics):
        # Remove brackets
        # Use _ instead of whitespace
        # Replace MB/s to MBps and T/s to Tps
        new_metrics = []
        for metric in metrics:
            tmp_metric = metric.lstrip(" ")
            tmp_metric = tmp_metric.replace(".", "")
            tmp_metric = tmp_metric.replace("(", "")
            tmp_metric = tmp_metric.replace(")", "")
            tmp_metric = tmp_metric.replace(" ", "_")
            tmp_metric = tmp_metric.replace("/s", "ps")
            tmp_metric = tmp_metric.replace("Ch", "channel_")
            tmp_metric = "pcm_" + tmp_metric
            new_metrics.append(tmp_metric)

        return new_metrics

    def collect(self):
        if not self.labels or not self.metrics:
            self.fetch_labels_and_metrics()

        self.metric_families = {}

        # interface info
        self.get_stats()
        self.logger.debug("Metrics collected: {}".format(self.metric_families))

        for metric in self.metric_families:
            yield self.metric_families[metric]

    def get_stats(self):
        with open(self.pcm_log_path, "r") as csv_file:
            current_value_line = csv_file.readlines()[-1]

        values = self.data_processing(current_value_line.rstrip("\n").split(";")[2:])
        for value, label, name in zip(values, self.labels, self.metrics):
            self.add_counter_metric(name, "", [("Component", label)], value)

    def add_counter_metric(self, name, documentation, labels, value):
        if name not in self.metric_families:
            label_names = [label[0] for label in labels]
            self.metric_families[name] = CounterMetricFamily(
                name, documentation, labels=label_names
            )
        label_values = [label[1] for label in labels]
        self.metric_families[name].add_metric(label_values, value)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", "-p", type=int, help="Port to bind.", default=9420)
    parser.add_argument(
        "--verbosity",
        "-v",
        type=str,
        help="Log level.",
        default="debug",
        choices=["debug", "info"],
    )
    args = parser.parse_args()
    log_level = logging.DEBUG if args.verbosity == "debug" else logging.INFO
    port = args.port
    print(f"Starting PCMExporter with port={port}")
    subprocess.Popen([f".//pcm-memory.x 10 -csv={LOG_PATH}"], shell=True)
    time.sleep(15)

    try:
        REGISTRY.register(PCMExporter(log_level))
        httpd = http.server.HTTPServer(("", port), MetricsHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.exit()
