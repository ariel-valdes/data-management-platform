# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
import os
import logging

from pcm_exporter.pcm_exporter import PCMExporter


class MyTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = PCMExporter(logging.CRITICAL)
        cls.exporter.pcm_log_path = f"{os.getcwd()}/images/exporters/tests/examples/example_pcm_output.txt"

    def test_labels_formatting(self):
        expected = ["Socket0", "Socket0", "Socket0", "Socket0", "Socket0", "Socket0",
                    "Socket0", "Socket0", "Socket0", "Socket0", "Socket0", "Socket0",
                    "Socket0", "Socket0", "Socket0", "Socket0", "Socket1", "Socket1",
                    "Socket1", "Socket1", "Socket1", "Socket1", "Socket1", "Socket1",
                    "Socket1", "Socket1", "Socket1", "Socket1", "Socket1", "Socket1",
                    "Socket1", "Socket1", "System", "System", "System"]
        self.assertListEqual(expected, self.exporter.labels)

    def test_metrics_formatting(self):
        self.maxDiff = None
        expected = ["pcm_channel_0Read", "pcm_channel_0Write", "pcm_channel_1Read", "pcm_channel_1Write",
                    "pcm_channel_2Read", "pcm_channel_2Write", "pcm_channel_3Read", "pcm_channel_3Write",
                    "pcm_channel_4Read", "pcm_channel_4Write", "pcm_channel_5Read", "pcm_channel_5Write",
                    "pcm_Mem_Read_MBps", "pcm_Mem_Write_MBps", "pcm_P_Write_Tps", "pcm_Memory_MBps",
                    "pcm_channel_0Read", "pcm_channel_0Write", "pcm_channel_1Read", "pcm_channel_1Write",
                    "pcm_channel_2Read", "pcm_channel_2Write", "pcm_channel_3Read", "pcm_channel_3Write",
                    "pcm_channel_4Read", "pcm_channel_4Write", "pcm_channel_5Read", "pcm_channel_5Write",
                    "pcm_Mem_Read_MBps", "pcm_Mem_Write_MBps", "pcm_P_Write_Tps", "pcm_Memory_MBps", "pcm_Read",
                    "pcm_Write", "pcm_Memory"]
        self.assertListEqual(expected, self.exporter.metrics)

    def test_stats(self):
        with open(self.exporter.pcm_log_path, "r") as csv_file:
            current_value_line = csv_file.readlines()[-1]
        values = self.exporter.data_processing(current_value_line.rstrip("\n").split(";")[2:])
        expected = [13.72, 10.77, 14.15, 11.20, 15.12, 12.52, 13.31, 10.79, 13.23,
                    10.57, 13.28, 10.66, 82.81, 66.52, 76196, 149.33, 16.40, 13.83,
                    16.65, 14.17, 16.52, 14.06, 15.43, 13.09, 15.88, 13.58, 15.75,
                    13.44, 96.63, 82.17, 76195, 178.80, 179.44, 148.69, 328.13]
        self.assertListEqual(expected, values)

    def test_collect_quantity(self):
        quantity = len(list(self.exporter.collect()))
        self.assertEqual(19, quantity)


if __name__ == '__main__':
    unittest.main()
