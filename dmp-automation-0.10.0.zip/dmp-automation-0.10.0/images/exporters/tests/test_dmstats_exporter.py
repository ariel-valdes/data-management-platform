# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
from unittest.mock import patch
import os
from logging import CRITICAL
import subprocess

from dmstats_exporter.dmstats_exporter import DMStatsExporter


class MyTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_root = f"{os.getcwd()}/images/exporters/tests"
        with open(f'{test_root}/examples/example_dmstats_output.txt', 'rb') as f:
            cls.dmstats_output_raw = f.read()
        with open(f'{test_root}/examples/example_dmstats_output.txt', 'r') as f:
            cls.dmstats_output = f.read()
        cls.exporter = DMStatsExporter(CRITICAL)

    @patch("subprocess.check_output")
    def test_collect(self, subprocess_mock):
        subprocess_mock.return_value = self.dmstats_output_raw

        result = len(list(self.exporter.collect()))
        self.assertEqual(13, result)

    @patch("subprocess.check_output")
    def test_prepare_labels(self, subprocess_mock):
        subprocess_mock.return_value = self.dmstats_output_raw
        values = self.dmstats_output.split("\n")[1].split()
        result = self.exporter.prepare_labels(values)
        expected = [('device_name', 'ubuntu--vg-root'), ('group_id', '-'),
                    ('region_id', '0'), ('object_type', 'area'),
                    ('area_id', '0'), ('area_start', '0')]
        self.assertEqual(expected, result)

    @patch("subprocess.check_output")
    def test_prepare_counters(self, subprocess_mock):
        subprocess_mock.return_value = self.dmstats_output_raw
        values = self.dmstats_output.split("\n")[1].split()
        result = self.exporter.prepare_counters(values)
        expected = [('dm_area_size_in_mb', 570081.28),
                    ('dm_reads_merged_per_sec', 0.0),
                    ('dm_writes_merged_per_sec', 0.0),
                    ('dm_reads_per_sec', 0.0),
                    ('dm_writes_per_sec', 294649856.0),
                    ('dm_read_size_per_sec_in_mb', 0.0),
                    ('dm_write_size_per_sec_in_mb', 1.32),
                    ('dm_avg_request_size_in_mb', 0.00439453125),
                    ('dm_queue_size', 1.26),
                    ('dm_utilization_in_percentage', 1.2),
                    ('dm_avg_wait_time', 4.48),
                    ('dm_avg_read_time', 0.0),
                    ('dm_avg_write_time', 4.48)]

        self.assertEqual(expected, result)

    @patch("subprocess.check_output")
    def test_dmstats_error(self, subprocess_mock):
        subprocess_mock.side_effect = subprocess.CalledProcessError(0, None)
        with self.assertRaises(SystemExit):
            DMStatsExporter(CRITICAL).get_stats()

    @patch("subprocess.check_output")
    def test_get_stats_empty_data(self, subprocess_mock):
        subprocess_mock.return_value = "".encode()
        self.assertIsNone(self.exporter.get_stats())

    @patch("subprocess.check_output")
    def test_convert_size_error(self, subprocess_mock):
        subprocess_mock.side_effect = subprocess.CalledProcessError(0, None)
        with self.assertRaises(SystemExit):
            DMStatsExporter(CRITICAL)._convert_size("10x")


if __name__ == '__main__':
    unittest.main()
