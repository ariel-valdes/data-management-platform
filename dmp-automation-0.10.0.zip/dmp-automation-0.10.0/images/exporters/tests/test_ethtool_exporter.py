# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import os
import unittest
import logging
import subprocess

from unittest.mock import patch
from ethtool_exporter.ethtool_exporter import EthtoolExporter


class MyTestCase(unittest.TestCase):

    def setUp(self):
        self.maxDiff = None
        test_root = f"{os.getcwd()}/images/exporters/tests"
        with open(f'{test_root}/examples/example_ethtool_output.txt', 'rb') as f:
            self.ethtool_output = f.read()

        self.interfaces = ['enp3s0']

    @patch("subprocess.check_output", )
    @patch("ethtool_exporter.ethtool_exporter.EthtoolExporter._get_physical_interfaces")
    def test_collect(self, interfaces_mock, ethtool_mock):
        interfaces_mock.return_value = self.interfaces
        ethtool_mock.return_value = self.ethtool_output

        test_output = [
            ("ethtool_rx_packets", 170190),
            ("ethtool_tx_packets", 80177),
            ("ethtool_rx_bytes", 176780456),
            ("ethtool_tx_bytes", 9610545),
            ("ethtool_rx_broadcast", 5460),
            ("ethtool_tx_broadcast", 4),
            ("ethtool_rx_multicast", 4729),
            ("ethtool_tx_multicast", 62),
            ("ethtool_rx_errors", 0),
            ("ethtool_tx_errors", 0)
        ]
        self.exporter = EthtoolExporter(regex_path=None, log_level=logging.CRITICAL)
        self.exporter.get_ethtool_stats("enp3s0")

        self.assertListEqual(test_output, self.exporter.metrics)

    @patch("subprocess.check_output")
    @patch("ethtool_exporter.ethtool_exporter.EthtoolExporter._get_physical_interfaces")
    def test_collect_quantity(self, interfaces_mock, ethtool_mock):
        interfaces_mock.return_value = self.interfaces
        ethtool_mock.return_value = self.ethtool_output
        expected = len(list(EthtoolExporter(regex_path=None, log_level=logging.CRITICAL).collect()))
        self.assertEqual(10, expected)

    @patch("os.readlink")
    @patch("os.path.islink")
    @patch("os.listdir")
    def test_get_physical_interfaces(self, os_listdir_mock, islink_mock, os_readlink_mock):
        os_listdir_mock.return_value = ["docker0", "enp0s31f6", "lo", "enp3s0"]
        islink_mock.return_value = True
        os_readlink_mock.side_effect = [["virtual"], [""], ["virtual"], [""]]
        exporter = EthtoolExporter(regex_path=None, log_level=logging.CRITICAL)
        self.assertTrue(os_listdir_mock.called)
        self.assertEqual(["enp0s31f6", "enp3s0"], exporter.interfaces)

    @patch("subprocess.check_output")
    def test_ethtool_error(self, subprocess_mock):
        subprocess_mock.side_effect = subprocess.CalledProcessError(1, "a")
        with self.assertRaises(SystemExit):
            EthtoolExporter(regex_path=None, log_level=logging.CRITICAL).get_ethtool_stats("enp3s0")


if __name__ == '__main__':
    unittest.main()
