# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.

import unittest
import os
import subprocess
from unittest.mock import patch, Mock
import logging
from isdct_exporter.isdct_exporter import ISDCTExporter, MetricTuple


class MyTestCase(unittest.TestCase):
    def setUp(self):
        self.maxDiff = None
        test_root = f"{os.getcwd()}/images/exporters/tests"
        with open(f'{test_root}/examples/example_isdct_intelssd_output.txt', 'r') as f:
            self.isdct_intedssd_output = f.read().encode()
        with open(f'{test_root}/examples/example_isdct_output.txt', 'r') as f:
            self.isdct_output = f.read().encode()

    @patch("subprocess.check_output")
    def test_number_of_metrics(self, subprocess_mock):
        subprocess_mock.side_effect = [self.isdct_intedssd_output, self.isdct_output]
        exporter = ISDCTExporter(Mock())
        result = len(list(exporter.collect()))
        self.assertEqual(24, result)

    @patch("subprocess.check_output")
    def test_isdct_error(self, subprocess_mock):
        subprocess_mock.side_effect = subprocess.CalledProcessError(0, None)
        with self.assertRaises(SystemExit):
            ISDCTExporter(Mock())

    @patch("subprocess.check_output")
    def test_get_metrics(self, subprocess_mock):
        subprocess_mock.side_effect = [self.isdct_intedssd_output, self.isdct_output]
        result = ISDCTExporter(logging.getLogger("logger")).get_metrics()[0]
        expected = MetricTuple(
            "vendor_specific",
            0,
            "Vendor Specific", [
                ("device", "sg0"),
                ("id", "05"),
                ("normalized", 100),
                ("status", 50),
                ("threshold", 0),
                ("worst", 100),
            ]
        )
        self.assertEqual(expected, result)


if __name__ == '__main__':
    unittest.main()
