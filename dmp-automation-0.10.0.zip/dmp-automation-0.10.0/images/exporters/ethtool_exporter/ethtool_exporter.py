#!/usr/bin/env python3

# Intel OBL Pre-Release Software (Internal Use)
# Copyright © 2019 Intel Corporation
#
# For licensing information, see the file 'LICENSE'
# in the root folder of this software module.


import argparse
import http.server
import logging
import os
import re
import subprocess
import sys

from prometheus_client.core import CounterMetricFamily, REGISTRY
from prometheus_client.exposition import MetricsHandler


class EthtoolExporter(object):
    def __init__(self, regex_path, log_level):
        self.logger = logging.getLogger("EthtoolExporter")
        self.logger.setLevel(log_level)
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(log_level)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.metrics = []
        self.interfaces = self._get_physical_interfaces()
        self.logger.info(
            "Found out {} physical interface(s): {}.".format(
                len(self.interfaces), self.interfaces
            )
        )
        regex_rules = r"""\W*(
                    (rx|tx)_(packets|bytes|broadcast|multicast|errors)
                )
            """
        if regex_path:
            with open(regex_path, "r") as regex_file:
                regex_rules = regex_file.read()
        self.logger.info("Following regex rules are used: {}".format(regex_rules))
        self.regex_rules = re.compile(regex_rules, re.VERBOSE)

    def collect(self):
        self.metrics = []
        for interface in self.interfaces:
            self.get_ethtool_stats(interface)

        self.logger.info(
            "Found out {} metrics that match regex rule.".format(len(self.metrics))
        )
        for cmf_tuple in self.metrics:
            cmf = CounterMetricFamily(cmf_tuple[0], "", labels=["interface"])
            cmf.add_metric([interface], cmf_tuple[1])
            yield cmf

    def get_ethtool_stats(self, interface):
        self.logger.info("Computing information from interface {}.".format(interface))
        try:
            data = subprocess.check_output(["ethtool", "-S", interface]).decode()
        except subprocess.CalledProcessError as err_info:
            self.logger.error(
                "Ethtool returned {} for interface {}".format(err_info, interface)
            )
            sys.exit(1)
        counter = 0
        for line in data.splitlines():
            if self.regex_rules.match(line):
                counter += 1
                name, value = line.split(":")
                value = int(value)
                cmf_tuple = ("ethtool_" + name.strip(), value)
                self.logger.debug("Metric {} = {}.".format(name.strip(), value))
                self.metrics.append(cmf_tuple)
        self.logger.debug(
            "Found {} metrics for interface {}.".format(counter, interface)
        )

    @staticmethod
    def _get_physical_interfaces():
        # https://serverfault.com/a/833577/393474
        net_path = "/sys/class/net"
        interface_list = []
        for interface_name in os.listdir(net_path):
            path = os.path.join(net_path, interface_name)
            if os.path.islink(path) and "virtual" not in os.readlink(path):
                interface_list.append(interface_name)

        return interface_list


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", "-p", type=int, help="Port to bind.", default=9417)
    parser.add_argument(
        "--verbosity",
        "-v",
        type=str,
        help="Log level.",
        default="debug",
        choices=["debug", "info"],
    )
    parser.add_argument(
        "--regex_path", type=str, default=None, help="Path to file with regex rules."
    )
    args = parser.parse_args()
    log_level = logging.DEBUG if args.verbosity == "debug" else logging.INFO
    port = args.port
    regex_path = args.regex_path
    print(
        "Starting EthtoolExporter with port={} and regex_path={}".format(
            port, regex_path
        )
    )
    try:
        REGISTRY.register(EthtoolExporter(regex_path, log_level))
        httpd = http.server.HTTPServer(("", port), MetricsHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.exit(1)
