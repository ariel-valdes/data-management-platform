See image-builder role

