# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

# Bucket of features definition
- Functionality #1 – Utility node, Baremetal provisioning, OCP w/ Calico CNI
- Functionality #2 – Linbit and its integration with OCP
- Functionality #3 – MinIO workload, tracked in dmp-workload repo
- Functionality #4 – Calico SDN support
- Functionality #5 – Monitoring, Logging and infrastructure storage
- Functionality #6 – Cassandra workload, tracked in dmp-workload repo
- Functionality #7 – MariaDB workload, tracked in dmp-workload repo
- Functionality #8 – Kafka workload, tracked in dmp-workload repo
- Functionality #9 – RSD integration

## [v0.9.1] - 2019-09-12
 ## Functionality 10 ##
 ### Added ###
   - RS6-3238 - Get rid of Command injection from pcm_exporter.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3239 - Get rid of Command injection from get_version.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3241 - Get rid of Command injection from dmp_runnner.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3242 - Get rid of a Path Traversal from dmp_runner.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3243 - Get rid of a Path Traversal from yml-generate.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3246 - Get rid of potential DoS by Sleep from pcm_exporter. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3247 - Get rid of potential header injection from get_version.py. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
   - RS6-3074 - [IGT] Added generation of single rack switch inventory [MR-871](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/871)
   - RS6-3076 - Log playbook versions after run [MR-860](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/860)
 ### Fixed ###
   - RS6-3235 - Fix problem with scaling-up, missing connection local. [MR-892](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/892)
 ### Changed ###
   - RS6-3245 - [IGT] Remove hardcoded password from tests [MR-885](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/885)
   - RS6-2742 - [IGT] All configuration errors are being reported at once [MR-852](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/852)
   - RS6-3075 - [IGT] Switch variables are now generated accounting for all possible hosts [MR-869](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/869)
 ## Functionality 1 ##
 ### Added ###
   - RS6-2941 - Add test which chekcs pods communication [MR-844](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/844)
   - RS6-2503 - Add test to check if container registry is working in HA [MR-855](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/855)
 ### Changed ###
   - RS6-3195 - Make Storage nodes schedulable by default. [MR-883](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/883)
 ## Functionality 5 ##
 ### Added ###
   - RS6-3149 - Added tests for isdct exporter [MR-870](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/870)
   - RS6-3051 - Add test for checking dmsg logs [MR-881](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/881)
   - RS6-3052 - Add test for checking journalctl logs [MR-881](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/881)
   - RS6-3053 - Add test for checking container logs [MR-881](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/881)
   - RS6-3054 - Add test for checking audit logs [MR-881](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/881)
   - RS6-3006 - Added prometheus helper, added new test "test_check_prometheus_gather_cpu_mem_metrics" in "cluster_ocp_monitoring" directory. [MR-815](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/815)
 ## Functionality 2 ##
 ### Fixed ###
   - RS6-3129 - dmstats calling wrong binary [MR-891](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/891)
 ### Added ###
   - RS6-2674 - Added test_create_linstor_volume_api() [MR-861](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/861)
   - RS6-2625 - Add test to check if Cluster Wide Volume Manager manages designated devices [MR-699](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/699)

## [v0.9.0] - 2019-09-04
 ## Functionality 1 ##
 ### Fixed ###
   - RS6-3131 - After OFED installation NVMEoF is not working [MR-863](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/863)
   - RS6-3071 - Cumulus-Switch role requires synchronize code base for IGT and for HW test [MR-843](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/843)
   - RS6-2758 - Fix Idm User permissions [MR-689](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/689)
   - RS6-3020 - NodeProblemDetector rules shall be configured only on ansible node [MR-806](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/806)
   - RS6-3021 - Generating htpasswd for OCP provides to OCP installation failure [MR-806](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/806)
   - RS6-2836 - Restart dynflow [MR-718](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/718)
   - RS6-2873 - Role idrac-host does not wait for idrac boot after reboot [MR-791](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/791)
   - RS6-3008 - Fix vlan separation test [MR-800](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/800)
   - RS6-3115 - Openshfit linstor fails because of nonexistant .kube/config [MR-862](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/862)
   - RS6-2888 - Improve process of bastion installation. [MR-735](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/735)
   - RS6-2889 - Change hosts in iDRAC configuration role. [MR-735](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/735)
   - RS6-2937 - Cannot login to openshift; 500 error [MR-764](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/764)
   - RS6-2811 - Reboot after MLX install [MR-751](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/751)
   - RS6-3019 - Cannot to login to oc during cluster_ocp_installation due to missing url [MR-824](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/824)
   - RS6-2838 - root/.kube/config not present on utility node [MR-758](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/758)
   - RS6-1852 - Fix for raid1 test. Create redfish helper. [MR-728](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/728)
   - RS6-1976 - Don't check for bastion_users presence any more. Instead, verify user prerequisites. [MR-830](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/830)
   - RS6-2812 - Fix timezone task. [MR-740](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/740)
 ### Added ###
   - RS6-2802 - Prepare Calico node role (thumbdrive provisioning) [MR-737](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/737)
   - RS6-2825 - Prepare Calico node role (network provisioning) [MR-737](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/737)
   - RS6-2826 - Template MGMT/MGMT AGR switch config [MR-737](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/737)
   - RS6-2827 - Template TOR switch config [MR-737](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/737)
   - RS6-2828 - Template Spine switch config [MR-737](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/737)
   - RS6-2824 - ZTP-server role [MR-817](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/817)
   - RS6-1830 - QoS is set on data plane network [MR-813](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/813)
   - RS6-1872 - Support for RedHat OpenShift Container Plaftorm Enterprise 3.11 [MR-476](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/476)
   - RS6-2440 - Switches shall synchronize time with utility node [MR-766](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/766)
   - RS6-2880 - Add validation check to playbooks [MR-747](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/747)
   - RS6-2535 - Add test checking bgp configuration [MR-724](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/724)
   - RS6-2676 - Merge dmp-images with dmp-automation [MR-677](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/677)
   - RS6-2920 - Core test bundle for pre_deployment checks [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2920 - Core test bundle for verification of bastion_deploy playbook execution correctness [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2920 - Essential test set for verification of cluster_provisioning playbook execution correctness [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2920 - Essential test bundle for verification of cluster_configuration playbook execution correctness [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2920 - Essential test bundle for verification of cluster_ocp_installation playbook execution correctness [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2386 - Test for checking satellite hostgroups [MR-616](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/616)
   - RS6-2912 - Missing ndctl package on compute nodes. [MR-801](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/801)
   - RS6-2985 - ipa client connection to idm test [MR-802](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/802)
   - RS6-2938 - Configure OOB_ACCESS on master nodes. [MR-778](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/778)
   - RS6-2931 - Add test that checks quantities of subscriptions before cluster provisioning [MR-759](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/759)
   - RS6-2933 - Add test that checks quantities of subscriptions after cluster provisioning [MR-759](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/759)
   - RS6-2751 - Add support for storage nodes scale up [MR-730](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/730)
   - RS6-1880 - Add support for compute nodes scale up [MR-730](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/730)
   - RS6-2939 - Check if "service network" is advertised with Anycast functionality test [MR-819](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/819)
   - RS6-2913 - Add apache pass configuration test [MR-798](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/798)
   - RS6-2712 - Add tests to check IPA Client [MR-760](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/760)
   - RS6-2867 - Add tests to check if IdM Server is deployed [MR-767](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/767)
   - RS6-2928 - Added test for checking nvmeof drivers status [MR-779](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/779)
   - RS6-2841 - Check if RedHat IdM network bridge is created and configured [MR-781](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/781)
 ### Changed ###
   - RS6-2926 - OpenSCAP 0.1.45 [MR-757](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/757)
   - RS6-3007 - Fix bgp test [MR-792](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/792)
   - RS6-2372 - Removed logic that checked quantities [MR-759](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/759)
   - RS6-2645 - Remove configuration labels necessary for custom scheduler extender for better compability with operators [MR-758](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/758)
 ## Functionality 10 ##
 ### Added ###
   - RS6-2927 - Apply OpenSCAP on the nodes [MR-777](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/777)
   - RS6-3066 - IGT Set DiscoveryLLDP [MR-846](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/846)
   - RS6-3029 - [IGT] Prepare coverage reports [MR-840](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/840)
   - RS6-2936 - [IGT] CLI is now available everywhere in the system [MR-762](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/762)
   - RS6-3031 - [IGT] Date and place of inventory generation is being logged in ~/.dmp.log [MR-835](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/835)
   - RS6-2632 - IGT refactoring part 1 [MR-818](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/818)
   - RS6-2744 - IGT should show diff between new and existing inventory. [MR-755](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/755)
   - RS6-2740 - [IGT] Added a CLI which allows more granual control of tool behavior [MR-739](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/739)
   - RS6-2935 - IGT shall generate initialize inventory for switch provisioning. [MR-787](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/787)
   - RS6-2896 - [IGT] Add a directory for validation tests' output [MR-763](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/763)
 ### Fixed ###
   - RS6-3046 - IGT does not generate OMe vm IP address [MR-846](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/846)
   - RS6-2919 - DMP cluster doesn't have a way to access to out-of-band. [MR-864](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/864)
   - RS6-2992 - Fix route file. [MR-864](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/864)
   - RS6-3122 - Fix crashing prometheus operator. [MR-864](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/864)
 ### Changed ###
   - RS6-2866 - Update deploy_scenario [MR-734](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/734)
   - RS6-2887 - Improve process of python3 installation. [MR-735](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/735)
   - RS6-2885 - [IGT] Hosts now use bastion as the BMC gateway [MR-748](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/748)
   - RS6-2743 - [IGT] All nodes now use the same PXE BIOS NIC [MR-746](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/746)
   - RS6-3087 - [IGT] Remove authorized_keys from config [MR-834](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/834)
 ## Functionality 2 ##
 ### Added ###
   - RS6-2892 - Add support for storage nodes with single data NIC. [MR-741](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/741)
   - RS6-2724 - Check if remote storage is exposed via NIC present in PCIe subsystem of the same processor socket as NVMe device [MR-794](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/794)
   - RS6-2920 - Basic tests set for verification of linstor_deploy playbook execution correctness [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
   - RS6-2748 - Linstor AAA and HTTPS [MR-726](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/726)
   - RS6-2732 - Test if linstor is correctly deployed as oc containers [MR-845](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/845)
   - RS6-2519 - NVMeoF policy for Node Problem Detector [MR-769](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/769)
   - RS6-2932 - Adding new test to cover requirment - linstor controller can handle 6 concurrent operations [MR-847](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/847)
 ### Fixed ###
   - RS6-3034 - Linstor QoS missing on NVMe initiators [MR-828](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/828)
   - RS6-3035 - Linstor NVMe target would not obey assigned preffered NIC [MR-828](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/828)
   - RS6-3036 - Linstor would attampt to use LVM volume names exceeding 128 chars [MR-828](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/828)
   - RS6-3037 - Adds a workaround for hung nvme disconnect  [MR-857](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/857)
   - RS6-3011 - Fix test_linstor_nodes_online - invalid nodes were checked [MR-808](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/808)
 ## Functionality 5 ##
 ### Added ###
   - RS6-3056 - Add unit tests for exporters [MR-841](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/841)
   - RS6-2789 - Export SMART metrics to Prometheus [MR-803](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/803)
   - RS6-1462 - Change log_level on all Prometheus Exporters. [MR-755](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/755)
   - RS6-1463 - Extend data retention for metrics to 7 days. [MR-755](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/755)
   - RS6-2652 - Default node-exporter isn't configured to provide necessary metrics for alerting. [MR-755](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/755)
   - RS6-2658 - Integrate blackbox exporter. [MR-755](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/755)
   - RS6-1433 - Liveness Probe for Fluentd Mux [MR-797](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/797)
   - RS6-2787 - Logging stack shall collect BMC logs. [MR-797](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/797)
   - RS6-2711 - Deploy fluentd proxy for switches logs [MR-797](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/797)
 ### Changed ###
   - RS6-2543 - Install Kibana on top of OpenShift 3.11 [MR-664](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/664)
   - RS6-2542 - Install ElasticSearch on top of OpenShift 3.11 [MR-664](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/664)
   - RS6-2544 - Install fluentd on top of OpenShift 3.11 [MR-664](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/664)
 ### Fixed ###
   - RS6-2895 - Fix variable name for prometheus storage class. [MR-744](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/744)
 ## Functionality 4 ##
 ### Added ###
   - RS6-2920 - single tests for calico component [MR-754](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/754)
 ## Functionality 3 ##
 ### Added ###
   - RS6-1844 - MinIO Cluster HTTPS [MR-756](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/756)
 ### Changed ###
   - RS6-3058 - New versions of minio operator and cluster [MR-833](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/833)
 ### Fixed ###
   - RS6-2973 - Incorrect free space on minio cluster [MR-833](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/833)


## [v0.8.0] - 2019-07-30
 ## Functionality 1 ##
 ### Fixed ###
   - RS6-2779 - ocp_installation fails during adding user to target group. [MR-703](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/703)
   - RS6-2340 - Check variables for Satellite - IdM integration [MR-497](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/497)
   - RS6-2356 - First Satellite repo synchronization should be done by default during Satellite installation [MR-505](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/505)
   - RS6-2758 Fix Idm User permissions [MR-689](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/689)
   - RS6-2279 - bastion_purge playbook does not setup correctly etc/resolv.conf [MR-501](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/501)
   - RS6-2778 - Fix Satellite domain creation [MR-696](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/696)
   - RS6-2527 - IPA should synchronized to external NTP server [MR-656](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/656)
   - RS6-2574 - Ipa-server doesn't start after reboot [MR-656](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/656)
   - RS6-2365 - Packages version for ipa-client and nss-pam-ldapd is not set. [MR-656](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/656)
   - RS6-2360 - Pre-pull calico related docker images [MR-471](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/471)
   - RS6-2836 Restart dynflow [MR-718](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/718)
   - RS6-2376 - Satellite critical bug fix [MR-679](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/679)
   - RS6-2592 - ZEROCONF Route is enabled on all nodes [MR-653](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/653)
   - RS6-2426 - Create IDM client workdir failed [MR-551](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/551)
   - RS6-2430 - Installation fails when cluster_configuration is performed. [MR-551](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/551)
   - RS6-2520 - Install package smartmontools on each node during cluster provisioning [MR-631](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/631)
   - RS6-2577 - Add information regarding NIC model in inventory group vars [MR-631](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/631)
   - RS6-2582 - Adjust process of installation to mlnx ofed in version 4.6 [MR-631](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/631)
   - RS6-2568 - Fix problem with failing domain. [MR-619](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/619)
   - RS6-2137 - Missing bridge-utils package after purge [MR-488](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/488)
   - RS6-2578 - Enable iptables [MR-661](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/661)
   - RS6-2440 - Switches cannot synchronize time with bastion node. [MR-573](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/573)
   - RS6-2367 - Incorrect permission for grub2/shim.efi [MR-514](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/514)
   - RS6-2415 - python-docker installation problems [MR-540](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/540)
   - RS6-2357 - iDRAC9-Satellite support over redfish [MR-543](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/543)
 ### Added ###
   - RS6-2518 - Add node problem detector to OCP [MR-654](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/654)
   - RS6-2614 - BFD support in Calico [MR-647](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/647)
   - RS6-2737 - Enable OpenSCAP [MR-680](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/680)
   - RS6-1871 - iDRAC integration with  IdM [MR-706](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/706)
   - RS6-1873 - IdM integration with external authorization endpoints [MR-492](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/492)
   - RS6-2734 - Improve Satellite configuration [MR-675](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/675)
   - RS6-2368 - RedHat 7.6 [MR-496](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/496)
   - RS-1872 - Support for RedHat OpenShift Container Plaftorm Enterprise 3.11 [MR-476](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/476)
   - RS6-1814 - Satelitte integration with Docker [MR-532](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/532)
   - RS6-2428 - Remove redudant check on filters. [MR-551](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/551)
   - RS6-2640 - Add custom scheduler to automation [MR-707](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/707)
   - RS6-1875 - Extension for OpenShift scheduler [MR-707](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/707)
   - RS6-2319 - Adding IGT extra info [MR-575](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/575)
   - RS6-2447 - Merge redfish_user and bmc_user variables into oob_user. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2458 - Add sumcheck for rheliso, mlnx_iso and ome.qcow2. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2456 - Rename external_ntpd_servers into external_ntp_servers. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2455 - IGT host_timezone and switch_timezone instead of timezone. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2454 - IGT shall generate reverse_pxe based on net_pxe variable. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2448 - Rename default_user and password into local_admin_user and password. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2449 - Rename daas_bot_pub_key into local_admin_pubkey. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2450 - Rename linstor_linbit_ into linstor_. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2451 - Rename openshift_oreg_auth_ into openshift_registry_auth_. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2453 - ansible_user shall be generated from local_admin_user variable. [MR-583](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/583)
   - RS6-2331 - Added cluster-wide time zone configuration. [MR-548](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/548)
 ### Changed ###
   - RS6-1827 - Nodes are using ECN [MR-508](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/508)
   - RS6-2731 - Simplify OCP inventory generation [MR-628](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/628)
   - RS6-2505 - Rename openshift_authorization_username into openshift_auth_username. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2452 - Remove bastion_users. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2506 - Rename satellite_location into cluster_physical_location. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2507 - dmp_domain instead of domain and prefix_domain. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2749 - Change protocol for https in custom scheduler [MR-707](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/707)
 ### Added  ###
   -  RS6-2676 - Merge dmp-images with dmp-automation [MR-677](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/677)
 ## Functionality 2 ##
 ### Added ###
   - RS6-2514 - Add dmpbalancer [MR-604](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/604)
   - RS6-1876 - Linstor local volumes for control plane services [MR-433](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/433)
   - RS6-2364 - Patch external-provisioner to make it work in OCP 3.11 and make use of image-builder [MR-536](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/536)
   - RS6-2727 - Added tiering support in dmpbalancer [MR-704](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/704)
   - RS6-1841 - Linstor Local Storageclasses [MR-388](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/388)
   - RS6-1842 - Linstor NVMeoF Storageclasses [MR-388](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/388)
   - RS6-2480 - Enforce linstor pkgs versions  [MR-526](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/526)
   - RS6-2429 - Prepare a logic that will collect information about numa_nodes before Linstor configuration. [MR-578](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/578)
   - RS6-2770 - Linstor Container limits  [MR-692](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/692)
   - RS6-2710 - Linstor QoS and Liveness probe [MR-669](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/669)
   - RS6-2760 - QoS config added to diskless pools [MR-690](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/690)
   - RS6-2728 - Label Storagepools/classes with storage tier [MR-674](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/674)
   - RS6-2485 - MinIO Operator and Cluster [MR-612](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/612)
 ### Fixed ###
   -  RS6-2604 - Change imagePullPolicy to IfNotPresent in linstor-csi [MR-711](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/711)
   - RS6-2478 - Fixes Linstor storageClass doesn't work with current CSI [MR-590](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/590)
   - RS6-2791 - Linstor controller port blocked [MR-705](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/705)
   - RS6-2487 - Idempotent linstor restarts [MR-621](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/621)
 ### Changed ###
   - RS6-2530 - Update CSI to v0.6.4[MR-609](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/609)
   - RS6-2481 - Linstor Cluster v0.9.11 [MR-593](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/593)
   - RS6-2531 - Linstor version 0.9.12 [MR-610](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/610)
   - RS6-2563 - Contenerized Linstor Satellite [MR-637](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/637)
   - RS6-2564 - Contenerized Linstor Controller [MR-637](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/637)
   - RS6-2591 - Linstor CLI replacement with API  [MR-637](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/637)
   - RS6-2760 - Moved contoller URI protocol to default var [MR-690](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/690)
   - RS6-2760 - QoS default value changed to 200Mbps [MR-690](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/690)
 ## Functionality 3 ##
 ### Fixed ###
   - RS6-2792 - Playbook openshift-operators fails during execution. [MR-703](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/703)
   -  RS-2608 - Image builder role is not idempotent [MR-693](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/693)
   -  RS-2605 - Missing linstror-csi images in docker-registry [MR-693](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/693)
 ### Added ###
   - RS6-2572 - MinIO Cluster Role [MR-613](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/613)
 ## Functionality 4 ##
 ### Added/ ###
   - RS6-2575 Added calicoctl links [MR-623](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/623)
 ### Added ###
   - RS6-2238 - Move RX TX tweaks for NICS into ifcfg file. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2457 - Improve configuration on data NIC. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
 ### Fixed ###
   - RS6-2290 - Removes vars override from playbook [MR-500](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/500)
 ## Functionality 5 ##
 ### Added ###
   - RS6-1876 - Logging and monitoring using local storage managed by Linstor [MR-433](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/433)
   - RS6-2540 - Install Prometheus on top of OpenShift 3.11 [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
   - RS6-2541 - Install Grafana on top of OpenShift 3.11 [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
   - RS7-2657 - Integrate ipmitool exporter [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
   - RS6-2656 - Integrate pcm exporter [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
   - RS6-2655 - Integrate ethtool exporter [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
   - RS6-2654 - Integrate dmstat exporter [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
 ### Fixed ###
   - RS6-2414 - Unable to build docker image dmstats-exporter [MR-646](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/646)
 ## Functionality 10 ##
 ### Added ###
   - RS6-2312 - Unit tests for inv_host.py [MR-507](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/507)
   - RS6-2313 - Unit tests for inv_interface.py [MR-507](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/507)
   - RS6-1893 - Ansible role for building images. [MR-397](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/397)
   - RS6-2517 - Set ansible_connection=local in inventory for bastion node. [MR-602](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/602)
   - RS6-2589 - Expose NIC information for bastion nodes [MR-667](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/667)
   - RS6-2286 - Prepare a short README [MR-467](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/467)
   - RS6-2580 - Add groups for switches [MR-685](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/685)
   - RS6-2738 - Add method to collect mac address of interface via redfish. [MR-683](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/683)
   - RS6-2742 - Prepare hw_configuration for Dell BoM cluster. [MR-683](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/683)
   - RS6-2480 - [IGT] There is a group containing exclusively hosts for each rack [MR-722](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/722)
   - RS6-2580 - [IGT] Add switches to rack groups [MR-708](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/708)
   - RS6-2835 - [IGT] Generates model information about switches [MR-725](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/725)
   - RS6-2311 - Unit-tests for igt_config.py [MR-534](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/534)
   - RS6-2309 - Adding support for multiporcessing [MR-534](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/534)
   - RS6-2316 - Redfish unittests [MR-539](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/539)
   - RS6-2314 - Prepare unit tests for inv_rack.py [MR-521](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/521)
   - RS6-2315 - Prepare unit tests for inventory_generator.py [MR-521](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/521)
   - RS6-2317 - Prepare unit tests for igt_utils.py [MR-521](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/521)
 ### Fixed ###
   - RS6-1569 - Fixes cluster_ocp_taints playbook fails [MR-535](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/535)
   - RS6-1570 - Fixes cluster_ocp_taints playbook is not idempotent [MR-535](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/535)
   - RS6-2343 - Fix serve_if [MR-525](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/525)
   - RS6-2600 - Fix PXE gateway [MR-662](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/662)
   - RS6-2383 - Incorrect logic to setting up addr on bmc access if [MR-534](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/534)
   - RS6-2512 - Fix edge-cases for image builder role [MR-603](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/603)
   - RS6-2416 - Wrong bastion_name in IGT [MR-543](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/543)
   - RS6-2351 - Hardcoded ansible_user [MR-521](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/521)
   - RS6-2352 - Change ipmi to redfish mode [MR-521](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/521)
 ### Changed ###
   - RS6-2703 - [IGT] Remove Combined linstor_role [MR-668](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/668)
   - RS6-2675 - Make inventory output directory configurable [MR-672](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/672)
   - RS6-2813 - [IGT] Doesn't require being ran as root and warns when it's missing permissions [MR-716](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/716)
   - RS6-2839 - [IGT] Python is now installed from repositories instead of being manually compiled [MR-721](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/721)
   - RS6-2782 - Adjust layouts of ocp_infra and ocp_masters to current dmp version. [MR-697](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/697)
   - RS6-2127 - Removing oc_modules [MR-605](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/605)


## [build-v0.7.0-2] - 2019-05-23
## Functionality #1 ##
### Added ###
   - RS6-1819 - Satellite is managing nodes packages [MR-414](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/414)
   - RS6-1773 - Hypervisor Node role [MR-350](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/350)
   - RS6-2191 - IdM is signing certs [MR-431](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/431)
   - RS6-2192 - IdM is able to sign wildcard CSR [MR-431](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/431)
   - RS6-1869 - Provisioned nodes are enrolled in IdM [MR-431](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/431)
   - RS6-1870 - OCP integration with IdM - users [MR-431](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/431)
   - RS6-1812 - Ansible role to deploy OMe [MR-366](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/366)
   - RS6-1815 - Satellite integration with libvirt [MR-366](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/366)
   - RS6-2293 - OpenShift core installer role is not validating variables correctly [MR-469](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/469)
   - RS6-1811 - RedHat IdM integration [MR-360](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/360)
   - RS6-1882 - Role/Task for user/group creation in IdM [MR-363](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/363)
   - RS6-2190 - Satellite external authentication [MR-460](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/460)
   - RS6-2202 - Satellite should use signed certificates [MR-442](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/442)
   - RS6-1820 - Satelitte is able to provision nodes [MR-480](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/480)
   - RS6-2036 - Too many variables defining RHEL release [MR-411](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/411)
   - RS6-1821 - Utility playbook for bastion oob access  [MR-378](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/378)
   - RS6-1824 - Deny root SSH access [MR-376](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/376)
   - RS6-1825 - SSH works only one PXE network [MR-383](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/383)
### Changed ###
   - RS6-2278 - Always prepare routing tables and outgoing rules for dataplane NICs [MR-464](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/464)
### Fixed ###
   - RS6-2216 - Dont run account creation on BM purge [MR-455](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/455)
   - RS6-2194 - Satellite purge is not working [MR-448](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/448)
   - RS6-2200 - Bastion node role should enable repositories RedHat way [MR-440](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/440)
   - RS6-2208 - Added bastion purge playbook [MR-451](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/451)
   - RS6-2035 - Missing katello-host-tools package [MR-414](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/414)
   - RS6-2294 - Copying certificates to master nodes fails due to insufficient permissions [MR-468](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/468)
   - RS6-2162 - Hypervision role deployment even though ome_deployment is set to False [MR-432](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/432)
   - RS6-2163 - Wrong roles order in bastion_deploy playbook [MR-432](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/432)
   - RS6-2165 - Disabling PEERDNS on public interface [MR-432](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/432)
   - RS6-2189 - Do not delete setuptools package [MR-432](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/432)
   - RS6-2280 - Idm-server installation fails with code 123 [MR-470](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/470)
   - RS6-2289 - idm-client role is failing with idm_dns variable undefined [MR-470](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/470)
   - RS6-2120 - Node provisioned successfully despite of snippet failure [MR-419](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/419)
   - RS6-2206 - Move Bastion NAT role [MR-449](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/449)
   - RS6-2136 - NAT execution placement [MR-423](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/423)
   - RS6-2193 - Broken OCP purge and missing release notes [MR-435](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/435)
   - RS6-2199 - OCP repository should be enabled only temporary [MR-439](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/439)
   - RS6-2203 - Short Description [MR-444](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/444)
   - RS6-2209 - Simplyfy RHEL version variable [MR-453](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/453)
   - RS6-2204 - Reduce number of IDM variables [MR-445](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/445)
   - RS6-2255 - Remove multipath from Calico [MR-461](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/461)
   - RS6-2230 - Remove unused Mellanox driver variable [MR-457](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/457)
   - RS6-2195 - Purge tasks should check is service available [MR-447](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/447)
   - RS6-2213 - Set correct mode for /opt/intel [MR-462](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/462)
   - RS6-2022 - Wrong version of vmlinuz and/or initrd.img available via tftp [MR-410](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/410)
   - RS6-2330 - bastion_deploy and bastion_purge playbooks shall check value of perform [MR-483](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/483)
   - RS6-2153 - Fix problem with updating hostgroup [MR-424](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/424)
   - RS6-2268 - Unable to Generate CSR in Bastion-Deploy playbook due to old version pyopenssl package [MR-xxx](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/xxx)
## Functionality #2 ##
### Added ###
  - RS6-1839 - Linstor local disks [MR-362](https://gitlab.devtools.intel.com/intelsdsdmp-automation/merge_requests/360)
  - RS6-1840 - Linstor w/NVMe support [MR-459](https://gitlab.devtools.intel.com/intelsdsdmp-automation/merge_requests/459)
### Changed ###
  - RS6-1839 - Linstor v0.9.2 [MR-362](https://gitlab.devtools.intel.com/intelsdsdmp-automation/merge_requests/360)
## Others ##
### Added ###
   - RS6-1406 - Merge workloads repo [MR-346](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/346)
   - RS6-1832 - Network Provisioning Tool [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
   - RS6-1781 - Elaborate a logic to fetch information from iDRACs. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-1782 - Elaborate a logic to fetch information from Switches. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-1783 - Elaborate a logic to generate ansible inventory. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-2168 - Configure bmc_access interface on basiton host. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-2281 - Prepare a logic for setting correct default pxe device via redfish. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-2283 - Prepare a logic for setting static configuration of OOB interface via redifsh. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
   - RS6-2285 - Prepare a logic for performing local actions on bastion node. [MR-429](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/429)
### Fixed ###
   - RS6-2087 - Missing 'if' attribute in example inventory [MR-484](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/484)
   - RS6-2324 - IGT shall generate bastion_pxe_ip variable instead of bastion.net_info.pxe.ip in all.yml [MR-477](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/477)
   - RS6-2135 - ome_vm_bridge_name does not have default value [MR-481](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/481)
   - RS6-2138 - Restart bridge {{ ome_vm_bridge_name }} fails [MR-481](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/481)


## [0.6.2] - 2019-04-15
## Functionality #1 ##
### Added ###
 - RS6-1946 Check internet connection on Bastion [MR-375](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/375)
### Fixed ###
 - RS6-2020 - DNS configuration tasks are not included to satellite configuration flow [MR-391](https://gitlab.devtools.intel.com/intelsds/dmp-automationmerge_requests/391)
 - RS6-1977 - Error evaluating conditional statement [MR-389](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/389)
 - RS6-1943 - BUG Named dynamic configuration is not removed [MR-386](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/386)
 - RS6-1574 - BUG The LVM Logical Volumes for Pulp and Mongo  persists after purge [MR-386](https://gitlab.devtools.intel.com/intelsds/dmp-automationmerge_requests/386)
 - RS6-1575 - BUG Purge of bastion should delete postgres data [MR-386](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/386)
 - RS6-1953 - BUG DHCP server configuration is not purged [MR-386](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/386)
 - RS6-1559 - Fixes lack of required directory for ftp [MR-348](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/348)
 - RS6-1994 - Satellite role tasks haven't got names [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
 - RS6-1961 - Missing PXE loader [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
 - RS6-1978 - RHEL release is not set [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
 - RS6-1945 - Unable to provision nodes (lack of reverse DNS entry for Bastion node) [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automationmerge_requests/367)
 - RS6-1954 - PTR record is not set for bastion [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
 - RS6-1558 - Unable to publish content view [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/367)
 - RS6-1995 - Exclude possibility of overlapping provisioning and discovery networks [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automationmerge_requests/367)
 - RS6-1996 - Lack of technical documentation for Satellite Server role [MR-367](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests367)
## Functionality #5 ##
### Fixed ###
 - RS6-1566 - BUG Crashing node exporter [MR-379](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/379)
 - RS6-1580 - Fix for "Prometheus-node-exporter pods are crushing" [MR-345](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/345)


## [0.6.1] - 2019-04-05
## Functionality #1 ##
### Fixed ###
 - RS6-1928 - Check redfish System location only during redfish based provisioning [MR-365](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/365)
 - RS6-1919 - Configure Satellite (configure network) [MR-370](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/370)
 - RS6-1556 - Set LANG variable to en_US_UTF-8 during satelitte installation [MR-371](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/371)

## [0.6.0] - 2019-03-28
## Functionality #1 ##
### Added ###
 - RS6-484 - Openshift deployment automation on virtual environment [PR-308](https://github.intel.com/intelsds/daas-automation/pull/308)
### Changed ###
 - RS6-1804 - Calico NAT outgoing as a separate parameter [MR-359](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/359)
 - RS6-1800 - MLNX QoS as an option [MR-357](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/357)
### Fixed ###
 - RS6-1554 - OCP package name is incorrect [MR-339](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/339)
 - RS6-1557 - GlusterFS installation fails missing docker tags [MR-343](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/343)
 - RS6-1561 - Failed to deploy OpenShift (unrecognized 'openshift_hostname' variable) [MR-343](https://gitlab.devtools.intel.com/intelsds/daas-automationmerge_requests/343)
 - RS6-1579 - Dmp partition table is not assigned to our Hostgroup [MR-342](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/342)
 - RS6-1578 - Hostgroups are not properly configured [MR-342](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/342)
 - RS6-1576 - Satellite 6.4 BM provision does not work [MR-342](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/342)
 - RS6-1774 - Default route is not set after node provisioning. [MR-351](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/351)
## Functionality #2 ##
### Fixed ###
 - RS6-1573 - Linstor deployment fails because of lacking drbdmanage package [MR-349](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests349)
 - RS6-1577 - Linstor deployment fails on templating override.conf file [MR-349](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/349)
 - RS6-1582 - Linstor deployment fails on creating nodes [MR-349](https://gitlab.devtools.intel.com/intelsds/dmp-automation/merge_requests/349)
## Functionality #4 ##
### Fixed ###
 - RS6-1562 - Fix calicoctl version doesn't match the version of calico [MR-347](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/347)
## Functionality #5 ##
### Added ###
 - RS6-682: System logs (Selinux logs) [PR-313](https://github.intel.com/intelsds/daas-automation/pull/313)
 - RS6-1224: Add calico monitoring [PR-304](https://github.intel.com/intelsds/daas-automation/pull/304)
 - RS6-1395: Linstor version 0.7.5. [PR-317](https://github.intel.com/intelsds/daas-automation/pull/317)
 - RS6-1396: Linstor only-register-nodes mode [PR-317](https://github.intel.com/intelsds/daas-automation/pull/317)
 - RS6-683 - Switch logs [PR-310](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/310)
 - RS-1443 - Make DMStats exporter disabled by default. [MR-328](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/328)
 - RS-1444 - Make PCMexporter disabled by default. [MR-328](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/328)
### Changed ###
 - RS-1445 - Investigate redundant types of metrics in node exporter and disable them. [MR-328](https://gitlab.devtools.intel.com/intelsds/daas-automationmerge_requests/328)
### Fixed ###
- RS6-1580 - Fix for "Prometheus-node-exporter pods are crushing" [MR-345](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/345)
## Functionality #9 ##
### Added ###
- RS6-1480 - QoS BLK script. [PR-323](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/323)
### Fixed ###
  - RS6-1583 - Linstor deployment fails because of undefined 'rsd_podm_credentials' variable [PR-xxx](https://github.intel.com/intelsds/daas-automation/pull/xxx)
  - RS6-1568 - RSD role removed. [MR-341](https://gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests/341)
## Others ##
### Added ###
 - RS6-1429 - Added reno tool and tox configuration to generate changelog [PR-319](https://github.intel.com/intelsds/daas-automation/pull/319)
### Fixed ###
 - RS6-1555 -  Update readme to latest release 0.6.0 and fix missing parts [MR-340](https:/gitlab.devtools.intel.com/intelsds/daas-automation/merge_requests340)


## [0.5.0] - 2019-01-04
### Functionality #2
#### Changed
- RS6-1390: Linstor version 0.7.3. [PR-314](https://github.intel.com/intelsds/daas-automation/pull/314)
- RS6-1407: Streamline elastic API calls [PR-318](https://github.intel.com/intelsds/daas-automation/pull/318)
### Functionality #9
#### Added
- RS6-596: Initial PR for RSD support. [PR-314](https://github.intel.com/intelsds/daas-automation/pull/314)


## [0.4.0] - 2018-11-30
### Functionality #1
#### Added
- RS6-914:  Added core entries domains to force IP address in node dnsmasq [PR-249](https://github.intel.com/intelsds/daas-automation/pull/249)
- RS6-1283: Add missing packages to each node during installation [PR-305](https://github.intel.com/intelsds/daas-automation/pull/305)
- RS6-1183:  Added Mellanox NIC QOS configuration [PR-281](https://github.intel.com/intelsds/daas-automation/pull/281)

#### Changed
- RS6-917: Automation for OCP installation changed from version 3.7 to 3.10 [PR-251](https://github.intel.com/intelsds/daas-automation/pull/251)
- RS6-999: Flatten code structure [PR-234](https://github.intel.com/intelsds/daas-automation/pull/234)
- RS6-946: Tweak TCP stack [PR-244](https://github.intel.com/intelsds/daas-automation/pull/244)
- RS6-976: Upgrade Satellite 6.2 to 6.4 [PR-232](https://github.intel.com/intelsds/daas-automation/pull/232)
- RS6-912: Increase rx/tx queue buffers for data and pxe networks [PR-263](https://github.intel.com/intelsds/daas-automation/pull/263)
- RS6-1228: Enable Multi NIC traffic [PR-282](https://github.intel.com/intelsds/daas-automation/pull/282)
#### Fixed
- RS6-995: Refresh tox config to work correctly with ansible-lint [PR-252](https://github.intel.com/intelsds/daas-automation/pull/252)
- RS6-983: Fix tox to work correctly with CI after repository clean [PR-250](https://github.intel.com/intelsds/daas-automation/pull/250)
- RS6-1003: Find templates in subdirectories and fix docs [PR-258](https://github.intel.com/intelsds/daas-automation/pull/258)
### Functionality #2
#### Added
- RS6-662: Linstor StorageClass tests [PR-261](https://github.intel.com/intelsds/daas-automation/pull/261)
- RS6-1270: Add ability to configure JVM opts for Linstor Satellite and Controller [PR-303](https://github.intel.com/intelsds/daas-automation/pull/303)
#### Changed
- RS6-1300: Linstor version 0.6.5 [PR-287](https://github.intel.com/intelsds/daas-automation/pull/287)
  - linstor-client: 0.6.2
  - linstor-satellite: 0.6.5
  - linstor-controller: 0.6.5
  - linstor-flexvolume: 0.7.4
  - linstor-external-provisioner: 0.7.8
### Functionality #4
#### Fixed
- RS6-1286: Improve OFED installation [PR-306](https://jira01.devtools.intel.com/browse/RS6-1286)
### Functionality #5
#### Added
- RS6-605: Make data retention in Prometheus configurable. [PR-248](https://github.intel.com/intelsds/daas-automation/pull/248)
- RS6-977: Support for OCP 3.10. [PR-248](https://github.intel.com/intelsds/daas-automation/pull/248)
- RS6-1169: Make metadata size of physical volumes configurable. [PR-273](https://github.intel.com/intelsds/daas-automation/pull/273)
- RS6-916: Prepare overall system health dashboard in Grafana. [PR-269](https://github.intel.com/intelsds/daas-automation/pull/269)
- RS6-1216: Configure Prometheus to auto-detect new MinIO clusters. [PR-286](https://github.intel.com/intelsds/daas-automation/pull/286)
- RS6-979: Deploy Grafana via OCP 3.10. [PR-248](https://github.intel.com/intelsds/daas-automation/pull/248)
- RS6-981: Merge playbooks for deploying and removing OCP Monitoring. [PR-248](https://github.intel.com/intelsds/daas-automation/pull/248)
- RS6-982: Deploy exporter in loop. [PR-248](https://github.intel.com/intelsds/daas-automation/pull/248)
- RS6-1231: Logging MUX configurable (and increased by default) buffer size. [PR-292](https://github.intel.com/intelsds/daas-automation/pull/292)
- RS6-1264: Prepare prometheus ipmi-exporter template. [PR-300](https://github.intel.com/intelsds/daas-automation/pull/300)
- RS6-1265: Prepare Grafana dashboard to expose ipmi metrics. [PR-300](https://github.intel.com/intelsds/daas-automation/pull/300)
- RS6-1255: DBus events should be available in logging stack [PR-297](https://github.intel.com/intelsds/daas-automation/pull/297)
- RS6-1284: Improve Monitoring. [PR-302](https://github.intel.com/intelsds/daas-automation/pull/302)
- RS6-1295: Extend white list of metrics for Ethtool exporter. [PR-397](https://github.intel.com/intelsds/daas-automation/pull/307)

## [0.3.4] - 2018-09-13
### Functionality #1
#### Removed
- RS6-734: Remove unused defaults variables in Ansible roles [PR-198](https://github.intel.com/intelsds/daas-automation/pull/198)
- RS6-761: Remove unused variables in Ansible group_vars [PR-204](https://github.intel.com/intelsds/daas-automation/pull/204)
- RS6-844: Refactor existing solutions for CI/TeamCity [PR-217](https://github.intel.com/intelsds/daas-automation/pull/217)
- RS6-871: Add some features to tox configuration [PR-219](https://github.intel.com/intelsds/daas-automation/pull/219)
- RS6-878: Remove unused openshift_log_file var [PR-220](https://github.intel.com/intelsds/daas-automation/pull/220)
- RS6-886: Prepare ansible-lint to work correctly with TeamCity [PR-222](https://github.intel.com/intelsds/daas-automation/pull/222)
- RS6-904: Remove useless functionality tox [PR-224](https://github.intel.com/intelsds/daas-automation/pull/224)
- RS6-922: Prepare readme for repository [PR-228](https://github.intel.com/intelsds/daas-automation/pull/228)
#### Changed
- RS6-771: Change empty keys in sample Ansible group_vars of daas_automation repository [PR-208](https://github.intel.com/intelsds/daas-automation/pull/208)
- RS6-921: Improve Redfish power management [PR-227](https://github.intel.com/intelsds/daas-automation/pull/227)
#### Fixed
- RS6-963: Automation fails on changing pv for docker registry [PR-242](https://github.intel.com/intelsds/daas-automation/pull/242)
- RS6-975: Fixes incorrect VG creation tasks location [PR-243](https://github.intel.com/intelsds/daas-automation/pull/243)
  - moves tasks to `clustom-lvm-layout-node role` from `disks-partitioning`
  - moves hardcoded `vg_` prefix for volume groups from role to inventory (requires changes in inventory)
  - changes example inventory to reflect above fixes
  - removes partitioning of NVMe drives on storage nodes in example inventory
### Functionality #2
#### Fixed
- RS6-647: fix linstor-qos.service unit [PR-191](https://github.intel.com/intelsds/daas-automation/pull/191)
#### Changed
- RS6-845: Linstor version 0.5.0 [PR-218](https://github.intel.com/intelsds/daas-automation/pull/218)
  - linstor-client: 0.5.0
  - linstor-satellite: 0.5.0
  - linstor-controller: 0.5.0
  - linstor-flexvolume: 0.7.3 - stays the same as in previous release
  - linstor-external-provisioner: 0.7.5 - stays the same as in previous release
### Functionality #4
#### Fixed
- RS6-841: fix lack of Calico host endpoints for BGP full-mesh configuration [PR-215](https://github.intel.com/intelsds/daas-automation/pull/215)
- RS6-835: Fix MLNX OFED Fails to Install in 0.3.3 [PR-231](https://github.intel.com/intelsds/daas-automation/pull/231)
  - Installation of OFED drivers are turned off for daas-automation 0.3.4 release [PR-237](https://github.intel.com/intelsds/daas-automation/pull/237)
  - OFED drivers will be installed on RHEL 7.5, please see [mellanox node docs][mellanox_node_docs]
### Functionality #5
#### Fixed
- RS6-604: Rename variables names in Monitoring roles. [PR-193](https://github.intel.com/intelsds/daas-automation/pull/193)
- RS6-842: fixes typo in taint toleration manifest [PR-216](https://github.intel.com/intelsds/daas-automation/pull/216)
### Others
- RS6-940: Simulate data path on VLAN [PR-221](https://github.intel.com/intelsds/daas-automation/pull/221)

## [0.3.3] - 2018-07-30
### Functionality #1
#### Fixed
- RS6-603: Automation fails on configuration phase of OCP cluster
- Taint strategy for Control Plane Nodes(Infra, Master and Storage Nodes)
### Functionality #2
#### Added
- Add QoS service for Linstor resources
#### Changed
- Changed default values for XFS partitioning (SU: 128k and SW: 1)
- Enable Linstor external provisioner in HA configuration
- Update version of Linbit binaries
  - linstor-client: 0.2.2
  - linstor-server: 0.2.5
  - linstor-flexvolume: 0.7.3
  - linstor-external-provisioner: 0.7.5
### Functionality #4
#### Changed
- Install Mallanox proprietary drivers used for RoCEv2.
  - This requires change in inventory: user must provide path to OFED ISO in `all` group vars to use this role.
### Functionality #5
#### Added
- Add support for 3 new prometheus exporters (dmstats, ethtool, pcm).
#### Fixed
- RS6-602: Automation fails on changing reclaimPolicy on Pv for docker registry
### Others
- Add a playbook for generating CSV with information about SSD FW upgradability.
- Add a playbook for updating SSDs FW
- RS6-542: Add a script to check Ansible, pep8 and yaml syntax
- RS6-610: Add a script to find unused variables or empty values of keys

## [0.3.2] - 2018-07-16
### Functionality #1
#### Changed
- Change OCP cluster node IPs from PXE to data
  - No additional variables are required.
- Cleanup OpenShift installation roles, installation is split to multiple playbooks per functionality (in required order of execution):
  1. OCP base playbook: cluster_ocp_installation.yml
  2. Deployment of GlusterFS: cluster_ocp_glusterfs.yml
  3. Logging EFK stack deployment: cluster_ocp_logging.yml
  4. Monitoring Prometheus deployment: cluster_ocp_monitoring.yml
#### Fixed
- Configurable first boot timeout with parameter (resolves `RS6-518`)
  - First boot timeout parameter is `boot_timeout`
- Minor typo fixes in `power_ctrl_cluster` task set
  - No additional variables are required.
- Reconfigured OCP scheduler and fix node labels
  - No additional variables are required.
- RS6-511: Disable normal pod scheduling on storage nodes
#### Removed
- Remove unused roles for DNSmasq and Libvirt
  - No additional variables are required.
### Functionality #2
#### Changed
- Use Data network IP instead of domain name for communication within Linstor client and server
  - No additional variables are required.
### Functionality #4
#### Changed
- ASN and Peers are optional. Possible to configure node-to-node mesh via variable
  - Additional variable for node-to-node mesh configuration
### Functionality #5
#### Added
- Added deployment of Prometheus using Openshift-ansible playbook to monitoring role
  - Variables changed: grafana_namespace -> monitoring_namespace; added: prometheus_pvc_size
- New playbook deploying infra storage GluserFS: cluster_ocp_glusterfs.yml
- New playbook deploying logging EFK stack: cluster_ocp_logging.yml
- New playbook deploying monitoring Prometheus: cluster_ocp_monitoring.yml
#### Changed
- GlusterFS role and registry moveout from NFS to GlusterFS.
  - Additional parameters required related to GlusterFS. There is new group [`ocp_glusterfs`][sample_gluster]
- Separate role for EFK stack
  - Additional parameters placed in the role `defaults` file.

## [0.3.1] - 2018-06-29
### Functionality #1
#### Changed
- Network inventory layout changes, in bgp_info structure per node host_vars
  - This requires changes in inventory, please see sample inventory and [network documentation][network_doc]
### Functionality #2
#### Changed
- Advanced and configurable storage partitioning in new layout of inventory structure storage_info
  - This requires changes in inventory, please see sample inventory and [storage documentation][storage_doc]
### Functionality #5
#### Added
- GlusterFS for Prometheus
  - Requires: glusterfs storageclass which is created by ocp ansible in version min. 3.7.5
  - Requires changes in inventory, add new group_vars ocp_glusterfs as in [sample inventory][sample_gluster]
- Grafana dashboard and node exporter for Prometheus
  - New playbook in ansible/playbooks/cluster_ocp_monitoring.yml
#### Changed
- Enable to install EFK stack by default in cluster_ocp_installation.yml playbook
- EFK stack uses GlusterFS as storage backend

## [0.3.0] - 2018-06-11
### Added
- Add deployment of Prometheus monitoring stack in OCP installer
- Add configuration for GlusterFS and EFK stack and disable installation

## [0.2.1] - 2018-06-11
### Changed
- Adjust ansible DMP automation code to use newest linstor-client CLI syntax v0.2.0
  - DMP v.0.2.1 will not be backward compatible with linstor-client CLI v.0.1.X
- Update version of Linbit binaries
  - linstor-client: 0.2.0
  - linstor-server: 0.2.2
  - linstor-flexvolume: 0.7.1
  - linstor-external-provisioner: 0.7.1

## [0.2.0] - 2018-05-23
### Added
- Integrate linstor-external-provisioner and linstor-flex-capable-node in
linstor_deploy.yml playbook.
- Added automated storage class generation from storge node inventory file
- Added rack number to storage pool creation, so that each storage pool will be
created on two storage servers for redundancy.

### Changed
- Updated version of LinBit Linstor External Provisioner to version v0.6.0.
- Updated version of LinBit Linstor Flex Volume Driver to version v0.6.3.
- Configure Linstor to use Data Network for DRBD node creation.
- Create diskless storage pool per OpenShift node and attach those diskless
storage pools to Data Network interface on master, infra and minion nodes.

### Fixed
- Idempotent creation of diskless storage pool.
- Fixed purge action on drbd-cluster-member and linstor-external-provisioner
roles.

### Removed
- Nothing

## [0.1.2] - 2018-05-18
### Added
- Mount RHEL iso image on bastion deploy.
- Add Content View creation and filters for RPMs, requires to publish
the content view after all repositories have been synced.
- Bastion_deploy playbook sets the SELinux to permissive mode.

### Changed
- Cleanup OCP roles in ansible/playbooks/cluster_ocp_configuration.
- Python-netaddr needs to be installed before running bastion_deploy playbook.

### Fixed
- RS6-435 OCP installation failing due to pinning RHEL to 7.4 - by content view
creation and blacklisting newer packages.
- Not reproducible: RS6-429 daas user is required to install OCP cluster.
- Fixed purge action on cluster_ocp_installation playbook.

### Removed
- Empty roles and documentation files.

## [0.1.1] - 2018-04-28
### Added
- RS6-433: Lock RHEL repositories to 7.4.
- RS6-433: Pin RHEL 7.4 on node in provisioning template.
- Validation of storage_info.

### Changed
- installation.yml to add specific package versions as a temporary workaround
to be able to install Satellite on bastion node.

### Fixed
- RS6-415: Fix for OCP installation - proper path to ansible filters.
- RS6-421 & RS6-422: Change dns server to localhost and config for pxe and bmc
interface.
- RS6-428: Installation of ruby-rkerberos in supported version.
- RS6-434: force to update /etc/sudoers.d/ files.
- RS6-416: Bastion DNS name resolution.
- RS6-430: add the search domain in /etc/resolv.conf.
- RS6-432: Install kmod-drbd in proper version.

## [0.1.0] - 2018-04-24
### Added
- Guidelines on how to bootstrap the bastion node, and deploy the cluster
using ansible automation.
- DRBD cluster deployment is working as tech preview.

### Fixed
- RS6-415: OCP installation failing due to missing oo_version_gte_3_5_or_1_5
filter
- RS6-428: Bastion: rubygem-smart_proxy_discovery is not installing due to
missing dependencies
- RS6-421: External DNS server is used after bastion deployment.
- RS6-422: Configure BMC interface during bastion provisioning

[v0.9.1]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.9.0...v0.9.1
[v0.9.0]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.8.0...v0.9.0
[v0.8.0]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/build-v0.7.0-2...v0.8.0
[build-v0.7.0-2]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.6.2...build-v0.7.0-2
[0.6.2]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.6.1...v0.6.2
[0.6.1]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.6.0...v0.6.1
[0.6.0]: https://gitlab.devtools.intel.com/intelsds/dmp-automation/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.intel.com/intelsds/daas-automation/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.intel.com/intelsds/daas-automation/compare/v0.3.4...v0.4.0
[0.3.4]: https://github.intel.com/intelsds/daas-automation/compare/v0.3.3...v0.3.4
[0.3.3]: https://github.intel.com/intelsds/daas-automation/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.intel.com/intelsds/daas-automation/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.intel.com/intelsds/daas-automation/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.intel.com/intelsds/daas-automation/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.intel.com/intelsds/daas-automation/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.intel.com/intelsds/daas-automation/compare/v0.1.2...v0.2.0
[0.1.2]: https://github.intel.com/intelsds/daas-automation/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.intel.com/intelsds/daas-automation/compare/v0.1.0...v0.1.1
[storage_doc]: https://github.intel.com/intelsds/daas-automation/blob/master/ansible/docs/node_storage_info.md
[network_doc]: https://github.intel.com/intelsds/daas-automation/blob/master/ansible/docs/node_network_info.md
[sample_gluster]: https://github.intel.com/intelsds/daas-automation/blob/master/ansible/inventory/group_vars/ocp_glusterfs.yml
[mellanox_node_docs]: https://github.intel.com/intelsds/daas-automation/blob/master/ansible/roles/mellanox-node/README.md
